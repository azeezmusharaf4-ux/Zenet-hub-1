import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { AccountListing, CategoryType, UserProfile } from '../types';
import { isAuthorizedOwner } from '../lib/authorizedOwners';
import { X, Save, Image, Plus, Trash2, Check, ShieldCheck, Sparkles, AlertCircle, Key, Lock, Eye, EyeOff, Edit, PlusCircle, Layers, RefreshCw, CheckCircle2, ShieldAlert, AlertTriangle, Copy } from 'lucide-react';
import { db, storage, sanitizeFirestorePayload } from '../lib/firebase';
import { doc, setDoc, updateDoc, collection, getDocs, getDoc, deleteDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { processAndCompressImage } from '../lib/imageUtils';
import { copyToClipboard } from '../utils/clipboard';
import { safeApiFetch } from '../utils/api';

interface EditListingModalProps {
  listing: AccountListing;
  onClose: () => void;
  onSuccess: (updated: Partial<AccountListing>) => void;
  user?: User | null;
  userProfile?: UserProfile | null;
  isOwner?: boolean;
}

interface DuplicateGroup {
  identifier: string;
  items: any[];
  keepItem: any;
  removeItems: any[];
}

export const EditListingModal: React.FC<EditListingModalProps> = ({
  listing,
  onClose,
  onSuccess,
  user,
  userProfile,
  isOwner
}) => {
  // Determine if active user is authorized Admin or website Owner
  const isAuthorizedAdmin = Boolean(
    isOwner ||
    userProfile?.role === 'owner' ||
    userProfile?.role === 'admin' ||
    user?.email?.toLowerCase() === 'azeezmusharaf4@gmail.com' ||
    isAuthorizedOwner(user, userProfile)
  );

  const isUserOwner = isAuthorizedAdmin;

  const creatorId = listing.creatorId || listing.createdBy || listing.sellerId || listing.owner_id;
  const creatorEmail = (listing.creatorEmail || listing.sellerEmail || '').toLowerCase();
  const currentEmail = (user?.email || '').toLowerCase();
  const isProductCreator = Boolean(user && (creatorId === user.uid || (!!currentEmail && !!creatorEmail && creatorEmail === currentEmail)));

  const canManageStock = Boolean(
    isAuthorizedAdmin || isProductCreator
  );

  const [title, setTitle] = useState(listing.title);
  const [category, setCategory] = useState<CategoryType>(listing.category);
  const [price, setPrice] = useState<string>(String(listing.price));
  const [followers, setFollowers] = useState(listing.followers || '');
  const [accountAge, setAccountAge] = useState(listing.accountAge || '');
  const pva = Boolean(listing.pva);
  const twoFactor = Boolean(listing.twoFactor);
  const monetized = Boolean(listing.monetized);
  const [warrantyDays, setWarrantyDays] = useState<number>(listing.warrantyDays || 7);
  const [country, setCountry] = useState(listing.country || 'Nigeria');
  const [niche, setNiche] = useState(listing.niche || 'General');
  const [description, setDescription] = useState(listing.description);
  const status = listing.status || 'active';
  const [imageUrl, setImageUrl] = useState(listing.imageUrl || '');
  const [images, setImages] = useState<string[]>(
    listing.images && listing.images.length > 0 ? listing.images : (listing.imageUrl ? [listing.imageUrl] : [])
  );
  const [newImageUrl, setNewImageUrl] = useState('');

  // Digital Product Details input fields for adding or editing single stock items (initialized blank)
  const [accountEmail, setAccountEmail] = useState('');
  const [accountPassword, setAccountPassword] = useState('');
  const [recoveryInfo, setRecoveryInfo] = useState('');
  const [twoFactorSecretKey, setTwoFactorSecretKey] = useState('');
  const [twoFactorBackupCodes, setTwoFactorBackupCodes] = useState('');
  const [backupCodes, setBackupCodes] = useState('');
  const [additionalInstructions, setAdditionalInstructions] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Multi-stock inventory state
  const [inventoryAccounts, setInventoryAccounts] = useState<any[]>([]);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [stockItemStatus, setStockItemStatus] = useState<'Available' | 'Sold'>('Available');
  const [stockItemToDelete, setStockItemToDelete] = useState<{ item: any; index: number } | null>(null);
  const [isDeletingStockItem, setIsDeletingStockItem] = useState(false);
  const [deletedAccountIds, setDeletedAccountIds] = useState<string[]>([]);
  const [loadingInventory, setLoadingInventory] = useState(false);
  const [stockFilterTab, setStockFilterTab] = useState<'all' | 'available' | 'sold'>('available');
  const [customFields, setCustomFields] = useState<{ id: string; label: string; value: string }[]>([]);

  const handleAddCustomField = (presetLabel?: string) => {
    setCustomFields(prev => [
      ...prev,
      {
        id: 'cf_' + Math.random().toString(36).substr(2, 7),
        label: presetLabel || '',
        value: ''
      }
    ]);
  };

  const handleUpdateCustomField = (id: string, field: 'label' | 'value', text: string) => {
    setCustomFields(prev => prev.map(cf => cf.id === id ? { ...cf, [field]: text } : cf));
  };

  const handleRemoveCustomField = (id: string) => {
    setCustomFields(prev => prev.filter(cf => cf.id !== id));
  };

  // Custom non-blocking iframe-safe notification and password reveal states
  const [revealedPasswords, setRevealedPasswords] = useState<Record<string, boolean>>({});
  const [confirmDeleteIdx, setConfirmDeleteIdx] = useState<number | null>(null);
  const [modalNotification, setModalNotification] = useState<{ type: 'success' | 'error' | 'warning'; message: string } | null>(null);

  const triggerNotification = (type: 'success' | 'error' | 'warning', message: string) => {
    setModalNotification({ type, message });
    setTimeout(() => {
      setModalNotification(prev => prev?.message === message ? null : prev);
    }, 6000);
  };

  // Duplicate stock cleanup modal states
  const [showDuplicateCleanupModal, setShowDuplicateCleanupModal] = useState(false);
  const [duplicateGroups, setDuplicateGroups] = useState<DuplicateGroup[]>([]);
  const [isCleaningDuplicates, setIsCleaningDuplicates] = useState(false);
  const [cleanSuccessMessage, setCleanSuccessMessage] = useState('');

  // Normalize login / email / username identifier
  const getAccountIdentifier = (item: { accountEmail?: string; delivery_value?: string; [key: string]: any }): string => {
    let raw = (item.accountEmail || item.delivery_value || '').trim();
    if (raw.includes('|')) {
      raw = raw.split('|')[0].trim();
    } else if (raw.includes(':') && !raw.startsWith('http')) {
      raw = raw.split(':')[0].trim();
    }
    return raw.toLowerCase();
  };

  // Group inventory items by identifier to detect duplicates
  const findDuplicateGroups = (items: any[]): DuplicateGroup[] => {
    const map = new Map<string, any[]>();
    for (const item of items) {
      const ident = getAccountIdentifier(item);
      if (!ident) continue;
      if (!map.has(ident)) {
        map.set(ident, []);
      }
      map.get(ident)!.push(item);
    }

    const groups: DuplicateGroup[] = [];
    map.forEach((itemList, ident) => {
      if (itemList.length > 1) {
        // Keep sold item if present, else keep item with password or most complete info or oldest existing item
        let keepItem = itemList.find(i => (i.status || '').toLowerCase() === 'sold');
        if (!keepItem) {
          keepItem = itemList.find(i => (i.accountPassword && i.accountPassword.trim().length > 0) || i.twoFactorSecretKey) || itemList[0];
        }
        const removeItems = itemList.filter(i => i.id !== keepItem.id);
        groups.push({
          identifier: ident,
          items: itemList,
          keepItem,
          removeItems
        });
      }
    });

    return groups;
  };

  useEffect(() => {
    async function loadInventory() {
      setLoadingInventory(true);
      try {
        const colRef = collection(db, 'listings', listing.id, 'inventory');
        const snap = await getDocs(colRef);
        let items: any[] = [];
        if (!snap.empty) {
          items = await Promise.all(snap.docs.map(async (inventoryDoc) => {
            const itemData = inventoryDoc.data();
            let secureData: any = {};
            try {
              const secureRef = doc(db, 'listings', listing.id, 'inventory', inventoryDoc.id, 'secure', 'details');
              const secureSnap = await getDoc(secureRef);
              if (secureSnap.exists()) {
                secureData = secureSnap.data();
              }
            } catch (err) {
              console.warn('Failed to load secure info for', inventoryDoc.id, err);
            }
            const rawStatus = (itemData.status || '').toLowerCase();
            const normalizedStatus = (rawStatus === 'sold' || itemData.status === 'Sold') ? 'Sold' : 'Available';
            return {
              id: inventoryDoc.id,
              status: normalizedStatus,
              accountEmail: secureData.accountEmail || itemData.accountEmail || '',
              accountPassword: secureData.accountPassword || itemData.accountPassword || '',
              recoveryInfo: secureData.recoveryInfo || secureData.notes || itemData.recoveryInfo || '',
              twoFactorSecretKey: secureData.twoFactorSecretKey || itemData.twoFactorSecretKey || '',
              twoFactorBackupCodes: secureData.twoFactorBackupCodes || secureData.backupCodes || itemData.twoFactorBackupCodes || '',
              backupCodes: secureData.twoFactorBackupCodes || secureData.backupCodes || itemData.backupCodes || '',
              additionalInstructions: secureData.additionalInstructions || itemData.additionalInstructions || '',
              delivery_value: secureData.accountEmail || itemData.accountEmail || '',
              soldTo: itemData.soldTo || null,
              orderId: itemData.orderId || null,
              soldAt: itemData.soldAt || null
            };
          }));
        } else if (Array.isArray(listing.inventory) && listing.inventory.length > 0) {
          items = listing.inventory.map((item, idx) => {
            const rawStatus = (item.status || '').toLowerCase();
            const normalizedStatus = (rawStatus === 'sold' || item.status === 'Sold') ? 'Sold' : 'Available';
            return {
              id: item.id || `inv_${idx + 1}`,
              status: normalizedStatus,
              accountEmail: item.accountEmail || '',
              accountPassword: item.accountPassword || '',
              recoveryInfo: item.recoveryInfo || item.notes || '',
              twoFactorSecretKey: item.twoFactorSecretKey || '',
              twoFactorBackupCodes: item.twoFactorBackupCodes || item.backupCodes || '',
              backupCodes: item.backupCodes || item.twoFactorBackupCodes || '',
              additionalInstructions: item.additionalInstructions || '',
              delivery_value: item.accountEmail || '',
              soldTo: item.soldTo || null,
              orderId: item.orderId || null,
              soldAt: item.soldAt || null
            };
          });
        } else if (listing.digitalProductDetails?.accountEmail) {
          items = [{
            id: 'inv_1',
            status: 'Available',
            accountEmail: listing.digitalProductDetails.accountEmail || '',
            accountPassword: listing.digitalProductDetails.accountPassword || '',
            recoveryInfo: listing.digitalProductDetails.recoveryInfo || '',
            twoFactorSecretKey: listing.digitalProductDetails.twoFactorSecretKey || '',
            twoFactorBackupCodes: listing.digitalProductDetails.twoFactorBackupCodes || listing.digitalProductDetails.backupCodes || '',
            backupCodes: listing.digitalProductDetails.backupCodes || '',
            additionalInstructions: listing.digitalProductDetails.additionalInstructions || '',
            delivery_value: listing.digitalProductDetails.accountEmail || '',
            soldTo: null,
            orderId: null,
            soldAt: null
          }];
        }
        setInventoryAccounts(items);
      } catch (err) {
        console.error('Failed to load inventory:', err);
      } finally {
        setLoadingInventory(false);
      }
    }
    loadInventory();
  }, [listing.id]);


  const handleAddAccountToInventory = async () => {
    if (!accountEmail.trim()) {
      triggerNotification('error', 'Please provide an Email or Username or Delivery Code for the stock item.');
      return;
    }

    const normEmail = getAccountIdentifier({ accountEmail });
    
    // Check for duplicate login/email identifier in existing stock list
    const duplicateFound = inventoryAccounts.some((item, idx) => {
      if (editingIndex !== null && idx === editingIndex) return false;
      return getAccountIdentifier(item) === normEmail;
    });

    if (duplicateFound) {
      triggerNotification('error', `Duplicate Prevented: Account "${accountEmail.trim()}" is already in this product's inventory. Duplicate accounts cannot be added.`);
      return;
    }

    const deliveryFields: { label: string; value: string }[] = [];
    if (accountEmail.trim()) deliveryFields.push({ label: 'Gmail/Login', value: accountEmail.trim() });
    if (accountPassword.trim()) deliveryFields.push({ label: 'Password', value: accountPassword.trim() });
    if (recoveryInfo.trim()) deliveryFields.push({ label: 'Recovery Info', value: recoveryInfo.trim() });
    if (twoFactorSecretKey.trim()) deliveryFields.push({ label: 'Two-Factor Authenticator', value: twoFactorSecretKey.trim() });
    if (twoFactorBackupCodes.trim()) deliveryFields.push({ label: '2FA Backup Codes', value: twoFactorBackupCodes.trim() });
    customFields.forEach(cf => {
      if (cf.label.trim() && cf.value.trim()) {
        deliveryFields.push({ label: cf.label.trim(), value: cf.value.trim() });
      }
    });
    if (additionalInstructions.trim()) deliveryFields.push({ label: 'Additional Instructions', value: additionalInstructions.trim() });

    const targetStatus = editingIndex !== null ? (stockItemStatus === 'Sold' ? 'Sold' : 'Available') : 'Available';
    const isReleasedToAvailable = targetStatus === 'Available';
    const existingAcc = editingIndex !== null ? inventoryAccounts[editingIndex] : null;

    const currentAccount: Record<string, any> = {
      ...(existingAcc || {}),
      id: existingAcc?.id || ('inv_' + Math.random().toString(36).substr(2, 9)),
      accountEmail: accountEmail.trim(),
      accountPassword: accountPassword.trim(),
      recoveryInfo: recoveryInfo.trim(),
      twoFactorSecretKey: twoFactorSecretKey.trim(),
      twoFactorBackupCodes: twoFactorBackupCodes.trim(),
      backupCodes: twoFactorBackupCodes.trim() || twoFactorSecretKey.trim(),
      additionalInstructions: additionalInstructions.trim(),
      delivery_value: accountEmail.trim() + (accountPassword.trim() ? ` | ${accountPassword.trim()}` : ''),
      deliveryFields,
      customFields,
      status: targetStatus,
      soldTo: isReleasedToAvailable ? null : (existingAcc?.soldTo || null),
      orderId: isReleasedToAvailable ? null : (existingAcc?.orderId || null),
      soldAt: isReleasedToAvailable ? null : (existingAcc?.soldAt || null)
    };

    customFields.forEach(cf => {
      if (cf.label.trim() && cf.value.trim()) {
        currentAccount[cf.label.trim()] = cf.value.trim();
      }
    });

    let nextInventory: any[];
    if (editingIndex !== null) {
      nextInventory = [...inventoryAccounts];
      nextInventory[editingIndex] = currentAccount;
      handleCancelStockEdit();
    } else {
      nextInventory = [...inventoryAccounts, currentAccount];
      handleCancelStockEdit();
    }
    setInventoryAccounts(nextInventory);

    // Instant real-time database sync via server-side authorization and Firestore
    try {
      const unusedCount = nextInventory.filter(acc => (acc.status || '').toLowerCase() !== 'sold').length;

      // Server-side call for security & role authorization
      try {
        const token = user ? await user.getIdToken() : '';
        await safeApiFetch(`/api/admin/listings/${listing.id}/inventory/${currentAccount.id}`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify({
            ...currentAccount,
            status: targetStatus
          })
        });
      } catch (serverErr) {
        console.warn('Server stock update call notice:', serverErr);
      }

      const itemRef = doc(db, 'listings', listing.id, 'inventory', currentAccount.id);
      const secureRef = doc(db, 'listings', listing.id, 'inventory', currentAccount.id, 'secure', 'details');

      await setDoc(itemRef, {
        id: currentAccount.id,
        status: currentAccount.status,
        soldTo: currentAccount.soldTo || null,
        orderId: currentAccount.orderId || null,
        soldAt: currentAccount.soldAt || null,
        updatedAt: new Date().toISOString()
      }, { merge: true });

      await setDoc(secureRef, {
        ...currentAccount,
        id: currentAccount.id,
        accountEmail: currentAccount.accountEmail || '',
        accountPassword: currentAccount.accountPassword || '',
        notes: currentAccount.recoveryInfo || '',
        recoveryInfo: currentAccount.recoveryInfo || '',
        twoFactorSecretKey: currentAccount.twoFactorSecretKey || '',
        twoFactorBackupCodes: currentAccount.twoFactorBackupCodes || '',
        additionalInstructions: currentAccount.additionalInstructions || '',
        deliveryFields: currentAccount.deliveryFields,
        updatedAt: new Date().toISOString()
      }, { merge: true });

      const cleanedInventoryForDoc = nextInventory.map(item => ({
        ...item,
        id: item.id,
        status: item.status || 'Available',
        accountEmail: item.accountEmail || '',
        recoveryInfo: item.recoveryInfo || '',
        additionalInstructions: item.additionalInstructions || '',
        twoFactorSecretKey: item.twoFactorSecretKey || '',
        twoFactorBackupCodes: item.twoFactorBackupCodes || item.backupCodes || '',
        backupCodes: item.backupCodes || item.twoFactorBackupCodes || '',
        deliveryFields: item.deliveryFields,
        soldTo: item.soldTo || null,
        orderId: item.orderId || null,
        soldAt: item.soldAt || null
      }));

      await updateDoc(doc(db, 'listings', listing.id), {
        stock: unusedCount,
        stockCount: unusedCount,
        status: unusedCount > 0 ? (status === 'reserved' ? 'reserved' : 'active') : 'sold',
        inventory: cleanedInventoryForDoc
      });

      if (onSuccess) {
        onSuccess({
          stock: unusedCount,
          stockCount: unusedCount,
          status: unusedCount > 0 ? (status === 'reserved' ? 'reserved' : 'active') : 'sold',
          inventory: cleanedInventoryForDoc
        });
      }
    } catch (autoErr) {
      console.warn('Auto-save single stock notice:', autoErr);
    }

    triggerNotification('success', `Saved stock item to database! (Total stock: ${nextInventory.filter(i => (i.status||'').toLowerCase() !== 'sold').length})`);
  };

  const handleCancelStockEdit = () => {
    setEditingIndex(null);
    setAccountEmail('');
    setAccountPassword('');
    setRecoveryInfo('');
    setTwoFactorSecretKey('');
    setTwoFactorBackupCodes('');
    setBackupCodes('');
    setAdditionalInstructions('');
    setCustomFields([]);
    setStockItemStatus('Available');
  };

  const handleEditAccountLocal = (index: number) => {
    const acc = inventoryAccounts[index];
    if (!acc) return;
    setEditingIndex(index);
    setAccountEmail(acc.accountEmail || acc.delivery_value || '');
    setAccountPassword(acc.accountPassword || '');
    setRecoveryInfo(acc.recoveryInfo || '');
    setTwoFactorSecretKey(acc.twoFactorSecretKey || '');
    setTwoFactorBackupCodes(acc.twoFactorBackupCodes || acc.backupCodes || '');
    setBackupCodes(acc.twoFactorBackupCodes || acc.backupCodes || '');
    setAdditionalInstructions(acc.additionalInstructions || '');
    setCustomFields(Array.isArray(acc.customFields) ? acc.customFields : []);

    // Explicitly set the stockItemStatus from database without automatically releasing sold items
    const isItemSold = (acc.status || '').toLowerCase() === 'sold';
    setStockItemStatus(isItemSold ? 'Sold' : 'Available');
  };

  const handleConfirmDeleteStockItem = async (acc: any, index: number) => {
    if (!acc) return;
    if (!isAuthorizedAdmin && !canManageStock) {
      triggerNotification('error', 'Access Denied: Only authorized Admins can delete stock.');
      setStockItemToDelete(null);
      return;
    }

    setIsDeletingStockItem(true);
    const itemId = acc.id;
    const remaining = inventoryAccounts.filter((_, idx) => idx !== index);

    try {
      // 1. Call server-side API with authentication token
      const token = user ? await user.getIdToken() : '';
      if (listing.id && itemId) {
        try {
          await safeApiFetch(`/api/admin/listings/${listing.id}/inventory/${itemId}`, {
            method: 'DELETE',
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
        } catch (serverErr) {
          console.warn('Server delete call notice, falling back to direct db delete:', serverErr);
        }

        // 2. Direct Firestore fallback/sync to ensure instantaneous zero-latency UI update
        try {
          const secureRef = doc(db, 'listings', listing.id, 'inventory', itemId, 'secure', 'details');
          await deleteDoc(secureRef);
        } catch {}

        try {
          const itemRef = doc(db, 'listings', listing.id, 'inventory', itemId);
          await deleteDoc(itemRef);
        } catch {}

        const unusedCount = remaining.filter(item => (item.status || '').toLowerCase() !== 'sold').length;
        const cleanedInventoryForDoc = remaining.map(item => ({
          ...item,
          id: item.id,
          status: item.status || 'Available',
          accountEmail: item.accountEmail || '',
          recoveryInfo: item.recoveryInfo || '',
          additionalInstructions: item.additionalInstructions || '',
          twoFactorSecretKey: item.twoFactorSecretKey || '',
          twoFactorBackupCodes: item.twoFactorBackupCodes || item.backupCodes || '',
          backupCodes: item.backupCodes || item.twoFactorBackupCodes || '',
          deliveryFields: item.deliveryFields,
          soldTo: item.soldTo || null,
          orderId: item.orderId || null,
          soldAt: item.soldAt || null
        }));

        await updateDoc(doc(db, 'listings', listing.id), {
          stock: unusedCount,
          stockCount: unusedCount,
          status: unusedCount > 0 ? (status === 'reserved' ? 'reserved' : 'active') : 'sold',
          inventory: cleanedInventoryForDoc
        });

        if (onSuccess) {
          onSuccess({
            stock: unusedCount,
            stockCount: unusedCount,
            status: unusedCount > 0 ? (status === 'reserved' ? 'reserved' : 'active') : 'sold',
            inventory: cleanedInventoryForDoc
          });
        }
      }

      setInventoryAccounts(remaining);
      if (itemId) {
        setDeletedAccountIds(prev => [...prev, itemId]);
      }
      if (editingIndex === index) {
        handleCancelStockEdit();
      } else if (editingIndex !== null && editingIndex > index) {
        setEditingIndex(editingIndex - 1);
      }

      triggerNotification('success', 'Stock item deleted successfully.');
    } catch (err: any) {
      console.error('Failed to delete stock item:', err);
      triggerNotification('error', `Failed to delete stock item: ${err.message || 'Unknown error'}`);
    } finally {
      setIsDeletingStockItem(false);
      setStockItemToDelete(null);
    }
  };

  // Trigger duplicate detection and open Owner Preview Modal
  const handleScanDuplicates = () => {
    if (!canManageStock) {
      triggerNotification('error', 'Access Denied: You do not have permission to perform duplicate cleanup.');
      return;
    }
    const groups = findDuplicateGroups(inventoryAccounts);
    if (groups.length === 0) {
      triggerNotification('success', `No duplicates found! All ${inventoryAccounts.length} stock items in this product have unique login/email identifiers.`);
      return;
    }
    setDuplicateGroups(groups);
    setShowDuplicateCleanupModal(true);
  };

  // Permanently delete duplicate records from Firestore
  const handleExecuteDuplicateCleanup = async () => {
    if (!canManageStock) {
      triggerNotification('error', 'Access Denied: You are not authorized to clean duplicate stock.');
      return;
    }
    setIsCleaningDuplicates(true);
    try {
      const removeIds: string[] = [];
      duplicateGroups.forEach(g => {
        g.removeItems.forEach(r => {
          if (r.id) removeIds.push(r.id);
        });
      });

      const removeSet = new Set(removeIds);
      const updatedInventory = inventoryAccounts.filter(item => !removeSet.has(item.id));

      // 1. Delete duplicate documents permanently from Firestore subcollection
      for (const delId of removeIds) {
        try {
          const secureRef = doc(db, 'listings', listing.id, 'inventory', delId, 'secure', 'details');
          await deleteDoc(secureRef);
        } catch (e) {
          console.warn('Direct delete secure duplicate notice:', delId, e);
        }
        try {
          const itemRef = doc(db, 'listings', listing.id, 'inventory', delId);
          await deleteDoc(itemRef);
        } catch (e) {
          console.warn('Direct delete duplicate item doc notice:', delId, e);
        }
      }

      // 2. Recalculate stock and update parent listing document in Firestore
      const unusedCount = updatedInventory.filter(item => (item.status || '').toLowerCase() !== 'sold').length;
      const cleanedInventoryForDoc = updatedInventory.map(item => ({
        id: item.id,
        status: item.status || 'Available',
        accountEmail: item.accountEmail || '',
        recoveryInfo: item.recoveryInfo || item.notes || '',
        additionalInstructions: item.additionalInstructions || '',
        twoFactorSecretKey: item.twoFactorSecretKey || '',
        twoFactorBackupCodes: item.twoFactorBackupCodes || item.backupCodes || '',
        backupCodes: item.backupCodes || item.twoFactorBackupCodes || '',
        soldTo: item.soldTo || null,
        orderId: item.orderId || null,
        soldAt: item.soldAt || null
      }));

      await updateDoc(doc(db, 'listings', listing.id), {
        stock: unusedCount,
        stockCount: unusedCount,
        status: unusedCount > 0 ? (status === 'reserved' ? 'reserved' : 'active') : 'sold',
        inventory: cleanedInventoryForDoc
      });

      // 3. Update local state
      setInventoryAccounts(updatedInventory);
      setDeletedAccountIds(prev => [...prev, ...removeIds]);

      if (onSuccess) {
        onSuccess({
          stock: unusedCount,
          stockCount: unusedCount,
          status: unusedCount > 0 ? (status === 'reserved' ? 'reserved' : 'active') : 'sold',
          inventory: cleanedInventoryForDoc
        });
      }

      const totalRemoved = removeIds.length;
      setShowDuplicateCleanupModal(false);
      setCleanSuccessMessage(`Cleaned ${totalRemoved} duplicate stock records. Kept 1 copy for each unique account (${updatedInventory.length} total remaining).`);
      setTimeout(() => setCleanSuccessMessage(''), 8000);
    } catch (cleanErr: any) {
      console.error('Error executing duplicate cleanup:', cleanErr);
      triggerNotification('error', `Cleanup failed: ${cleanErr?.message || 'Please try again.'}`);
    } finally {
      setIsCleaningDuplicates(false);
    }
  };

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);

  // Check if any core listing fields differ from initial listing prop
  const hasUnsavedChanges = Boolean(
    title.trim() !== listing.title.trim() ||
    category !== listing.category ||
    price !== String(listing.price) ||
    followers.trim() !== (listing.followers || '').trim() ||
    accountAge.trim() !== (listing.accountAge || '').trim() ||
    warrantyDays !== (listing.warrantyDays || 7) ||
    country.trim() !== (listing.country || 'Nigeria').trim() ||
    niche.trim() !== (listing.niche || 'General').trim() ||
    description.trim() !== (listing.description || '').trim() ||
    deletedAccountIds.length > 0
  );

  const handleRequestClose = () => {
    if (hasUnsavedChanges) {
      setShowCancelConfirm(true);
    } else {
      onClose();
    }
  };

  // Sample image presets by category
  const defaultCategoryImages: Record<CategoryType, string[]> = {
    Facebook: [
      'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80'
    ],
    TikTok: [
      'https://images.unsplash.com/photo-1611605698335-8b1569810432?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1598550476439-6847785fcea6?auto=format&fit=crop&w=800&q=80'
    ],
    Instagram: [
      'https://images.unsplash.com/photo-1611262588024-d12430b98920?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80'
    ],
    Gmail: [
      'https://images.unsplash.com/photo-1596526131083-e8c633c948d2?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80'
    ],
    'Twitter/X': [
      'https://images.unsplash.com/photo-1611605698323-b1e992d37a8c?auto=format&fit=crop&w=800&q=80'
    ],
    Telegram: [
      'https://images.unsplash.com/photo-1614680376593-902f749f705c?auto=format&fit=crop&w=800&q=80'
    ],
    Discord: [
      'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?auto=format&fit=crop&w=800&q=80'
    ],
    Reddit: [
      'https://images.unsplash.com/photo-1614680376408-81e91ffe3db7?auto=format&fit=crop&w=800&q=80'
    ],
    Snapchat: [
      'https://images.unsplash.com/photo-1611162616475-46b635cb6868?auto=format&fit=crop&w=800&q=80'
    ],
    LinkedIn: [
      'https://images.unsplash.com/photo-1611944212129-29977ae1398c?auto=format&fit=crop&w=800&q=80'
    ],
    Pinterest: [
      'https://images.unsplash.com/photo-1611162618071-b39a2ec055fb?auto=format&fit=crop&w=800&q=80'
    ],
    Threads: [
      'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&w=800&q=80'
    ],
    WhatsApp: [
      'https://images.unsplash.com/photo-1614680376593-902f749f705c?auto=format&fit=crop&w=800&q=80'
    ],
    YouTube: [
      'https://images.unsplash.com/photo-1611162616475-46b635cb6868?auto=format&fit=crop&w=800&q=80'
    ],
    All: [
      'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&w=800&q=80'
    ],
    Other: [
      'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80'
    ]
  };

  const handleAddImage = (urlToAdd?: string) => {
    const target = (urlToAdd || newImageUrl).trim();
    if (!target) return;
    if (images.includes(target)) {
      setNewImageUrl('');
      return;
    }
    const updated = [...images, target];
    setImages(updated);
    if (!imageUrl) {
      setImageUrl(target);
    }
    setNewImageUrl('');
  };

  const handleRemoveImage = (indexToRemove: number) => {
    const updated = images.filter((_, idx) => idx !== indexToRemove);
    setImages(updated);
    if (updated.length > 0) {
      setImageUrl(updated[0]);
    } else {
      setImageUrl('');
    }
  };

  const [uploadingImage, setUploadingImage] = useState(false);
  const [imageUploadError, setImageUploadError] = useState('');

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploadingImage(true);
    setImageUploadError('');

    try {
      for (const file of Array.from(files) as File[]) {
        if (!file.type.startsWith('image/')) continue;

        // 1. Instant compressed preview (< 30ms)
        const compressedDataUrl = await processAndCompressImage(file, {
          maxWidth: 800,
          maxHeight: 800,
          quality: 0.82
        });

        // Show immediately in gallery
        handleAddImage(compressedDataUrl);

        // 2. Background storage upload with timeout
        try {
          const response = await fetch(compressedDataUrl);
          const blob = await response.blob();
          const cleanName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_');
          const fileRef = ref(storage, `product-images/${listing.id}/${Date.now()}_${cleanName}`);
          
          const uploadPromise = uploadBytes(fileRef, blob).then((snap) => getDownloadURL(snap.ref));
          const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 3000));
          const downloadUrl = await Promise.race([uploadPromise, timeoutPromise]);

          if (downloadUrl && typeof downloadUrl === 'string') {
            setImages((prev) => prev.map((img) => (img === compressedDataUrl ? downloadUrl : img)));
            setImageUrl((prev) => (prev === compressedDataUrl ? downloadUrl : prev));
          }
        } catch (storageErr) {
          console.warn('Storage sync fallback to compressed image:', storageErr);
        }
      }
    } catch (err: any) {
      console.error('Image upload error:', err);
      setImageUploadError(err.message || 'Failed to process image. Please try again.');
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canManageStock) {
      setError('Permission Denied: Admins can only edit products that they personally created.');
      return;
    }
    if (!title.trim() || !price || Number(price) <= 0) {
      setError('Please provide a valid listing title and positive price.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      // Build inventory list from current inventory state, applying editingIndex changes if user was editing an existing item
      let finalInventory = [...inventoryAccounts];
      if (editingIndex !== null && accountEmail.trim()) {
        const existingItem = inventoryAccounts[editingIndex];
        const accountId = existingItem.id;
        const deliveryFields: { label: string; value: string }[] = [];
        if (accountEmail.trim()) deliveryFields.push({ label: 'Gmail/Login', value: accountEmail.trim() });
        if (accountPassword.trim()) deliveryFields.push({ label: 'Password', value: accountPassword.trim() });
        if (recoveryInfo.trim()) deliveryFields.push({ label: 'Recovery Info', value: recoveryInfo.trim() });
        if (twoFactorSecretKey.trim()) deliveryFields.push({ label: 'Two-Factor Authenticator', value: twoFactorSecretKey.trim() });
        if (twoFactorBackupCodes.trim()) deliveryFields.push({ label: '2FA Backup Codes', value: twoFactorBackupCodes.trim() });
        customFields.forEach(cf => {
          if (cf.label.trim() && cf.value.trim()) {
            deliveryFields.push({ label: cf.label.trim(), value: cf.value.trim() });
          }
        });
        if (additionalInstructions.trim()) deliveryFields.push({ label: 'Additional Instructions', value: additionalInstructions.trim() });

        const updatedAcc: Record<string, any> = {
          ...existingItem,
          id: accountId,
          accountEmail: accountEmail.trim(),
          accountPassword: accountPassword.trim(),
          recoveryInfo: recoveryInfo.trim(),
          twoFactorSecretKey: twoFactorSecretKey.trim(),
          twoFactorBackupCodes: twoFactorBackupCodes.trim(),
          backupCodes: twoFactorBackupCodes.trim() || twoFactorSecretKey.trim(),
          additionalInstructions: additionalInstructions.trim(),
          delivery_value: accountEmail.trim() + (accountPassword.trim() ? ` | ${accountPassword.trim()}` : ''),
          deliveryFields,
          customFields,
          status: existingItem.status || 'Available',
          soldTo: existingItem.soldTo || null,
          orderId: existingItem.orderId || null,
          soldAt: existingItem.soldAt || null
        };

        customFields.forEach(cf => {
          if (cf.label.trim() && cf.value.trim()) {
            updatedAcc[cf.label.trim()] = cf.value.trim();
          }
        });

        finalInventory[editingIndex] = updatedAcc;
      }

      // Normalize all statuses to strictly 'Available' or 'Sold'
      finalInventory = finalInventory.map(item => {
        const isSold = (item.status || '').toLowerCase() === 'sold' || item.status === 'Sold';
        return {
          ...item,
          status: isSold ? 'Sold' : 'Available'
        };
      });

      // Calculate stock using ONLY available inventory:
      // stockCount = inventory.filter(acc => acc.status === 'Available').length
      const stockCount = finalInventory.filter(acc => acc.status === 'Available').length;

      // 1. Process deletions and clean up unreferenced subcollections
      const finalItemIds = new Set(finalInventory.map(item => item.id));
      try {
        const existingSubSnap = await getDocs(collection(db, 'listings', listing.id, 'inventory'));
        for (const subDoc of existingSubSnap.docs) {
          if (!finalItemIds.has(subDoc.id) || deletedAccountIds.includes(subDoc.id)) {
            try {
              const secureRef = doc(db, 'listings', listing.id, 'inventory', subDoc.id, 'secure', 'details');
              await deleteDoc(secureRef);
            } catch {}
            try {
              await deleteDoc(subDoc.ref);
            } catch {}
          }
        }
      } catch (colErr) {
        console.warn('Subcollection cleanup warning:', colErr);
      }

      for (const delId of deletedAccountIds) {
        if (delId) {
          try {
            const secureRef = doc(db, 'listings', listing.id, 'inventory', delId, 'secure', 'details');
            await deleteDoc(secureRef);
            const itemRef = doc(db, 'listings', listing.id, 'inventory', delId);
            await deleteDoc(itemRef);
          } catch (delErr) {
            console.error('Error deleting inventory item:', delId, delErr);
          }
        }
      }

      // 2. Save active inventory accounts into subcollection
      for (const item of finalInventory) {
        const itemId = item.id || 'inv_' + Math.random().toString(36).substr(2, 9);
        const itemRef = doc(db, 'listings', listing.id, 'inventory', itemId);
        const secureRef = doc(db, 'listings', listing.id, 'inventory', itemId, 'secure', 'details');

        // Save public/meta item document
        await setDoc(itemRef, {
          id: itemId,
          status: item.status, // 'Available' or 'Sold'
          soldTo: item.soldTo || null,
          orderId: item.orderId || null,
          soldAt: item.soldAt || null,
          updatedAt: new Date().toISOString()
        }, { merge: true });

        // Save secure item details preserving all configured dynamic fields
        await setDoc(secureRef, {
          ...item,
          id: itemId,
          accountEmail: item.accountEmail || '',
          accountPassword: item.accountPassword || '',
          notes: item.recoveryInfo || item.notes || '',
          recoveryInfo: item.recoveryInfo || item.notes || '',
          twoFactorSecretKey: item.twoFactorSecretKey || '',
          twoFactorBackupCodes: item.twoFactorBackupCodes || item.backupCodes || '',
          backupCodes: item.twoFactorBackupCodes || item.backupCodes || '',
          additionalInstructions: item.additionalInstructions || '',
          deliveryFields: Array.isArray(item.deliveryFields) ? item.deliveryFields : undefined,
          updatedAt: new Date().toISOString()
        }, { merge: true });
      }

      // 3. Clean inventory array for parent listing doc preserving all fields
      const inventoryForDoc = finalInventory.map(item => ({
        ...item,
        id: item.id,
        status: item.status, // 'Available' or 'Sold'
        accountEmail: item.accountEmail || '',
        recoveryInfo: item.recoveryInfo || item.notes || '',
        additionalInstructions: item.additionalInstructions || '',
        twoFactorSecretKey: item.twoFactorSecretKey || '',
        twoFactorBackupCodes: item.twoFactorBackupCodes || item.backupCodes || '',
        backupCodes: item.backupCodes || item.twoFactorBackupCodes || '',
        deliveryFields: Array.isArray(item.deliveryFields) ? item.deliveryFields : undefined,
        soldTo: item.soldTo || null,
        orderId: item.orderId || null,
        soldAt: item.soldAt || null
      }));

      const mainImg = imageUrl.trim() || (images.length > 0 ? images[0] : defaultCategoryImages[category][0]);

      // Fallback single-stock details for backwards compatibility
      const firstAvailable = finalInventory.find(acc => acc.status === 'Available') || finalInventory[0];
      const mainDigitalDetails = firstAvailable ? {
        ...firstAvailable,
        accountEmail: firstAvailable.accountEmail || '',
        accountPassword: firstAvailable.accountPassword || '',
        recoveryInfo: firstAvailable.recoveryInfo || '',
        twoFactorSecretKey: firstAvailable.twoFactorSecretKey || '',
        twoFactorBackupCodes: firstAvailable.twoFactorBackupCodes || firstAvailable.backupCodes || '',
        backupCodes: firstAvailable.backupCodes || '',
        additionalInstructions: firstAvailable.additionalInstructions || '',
        deliveryFields: Array.isArray(firstAvailable.deliveryFields) ? firstAvailable.deliveryFields : undefined
      } : {
        accountEmail: '',
        accountPassword: '',
        recoveryInfo: '',
        twoFactorSecretKey: '',
        twoFactorBackupCodes: '',
        backupCodes: '',
        additionalInstructions: ''
      };

      const updatedData = sanitizeFirestorePayload({
        title: title.trim(),
        category,
        price: Number(price) || 0,
        followers: followers.trim() || 'N/A',
        accountAge: accountAge.trim() || 'Aged',
        pva: Boolean(pva),
        twoFactor: Boolean(twoFactor),
        monetized: Boolean(monetized),
        warrantyDays: Number(warrantyDays) || 7,
        country: country.trim() || 'Nigeria',
        niche: niche.trim() || 'General',
        description: description.trim(),
        status: listing.approvalStatus === 'pending' ? 'reserved' : (stockCount > 0 ? 'active' : 'sold'),
        approvalStatus: listing.approvalStatus || (isUserOwner ? 'approved' : 'pending'),
        featured: Boolean(listing.featured),
        imageUrl: mainImg,
        images: images.length > 0 ? images : [mainImg],
        badges: [pva ? 'PVA Verified' : '', twoFactor ? '2FA Enabled' : '', monetized ? 'Monetized' : ''].filter(Boolean),
        stock: stockCount,
        stockCount: stockCount,
        inventory: inventoryForDoc,
        digitalProductDetails: mainDigitalDetails,
        sellerId: listing.sellerId,
        owner_id: listing.owner_id || listing.sellerId
      });

      // Real-time update/upsert in Firestore
      const listingRef = doc(db, 'listings', listing.id);
      await setDoc(listingRef, updatedData, { merge: true });

      const fullUpdated: AccountListing = {
        ...listing,
        ...updatedData,
        id: listing.id
      } as AccountListing;

      onSuccess(fullUpdated);
      onClose();
    } catch (err: any) {
      console.error('Update listing error:', err);
      setError(err.message || 'Failed to update listing in Firestore.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto">
      <div 
        className="bg-white border border-[#EBE7F7] rounded-2xl sm:rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl my-auto relative animate-in fade-in zoom-in-95 duration-200 text-[#0F172A] flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-white px-4 sm:px-6 py-3.5 sm:py-4 border-b border-[#EBE7F7] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-[#EDE9FE] border border-[#DDD6FE] flex items-center justify-center text-[#5B4DF5]">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-[#0F172A] text-base sm:text-lg">Edit Account Listing</h2>
              <span className="text-xs text-[#64748B] font-mono">Ref ID: {listing.id}</span>
            </div>
          </div>
          <button
            type="button"
            onClick={handleRequestClose}
            className="p-2 text-[#64748B] hover:text-[#0F172A] bg-[#F8F7FD] hover:bg-[#F2EFFC] border border-[#EBE7F7] rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-5 overflow-y-auto flex-1 text-xs sm:text-sm bg-white">
          {modalNotification && (
            <div className={`p-3 border rounded-2xl text-xs flex items-center gap-2 animate-in fade-in duration-300 ${
              modalNotification.type === 'error'
                ? 'bg-rose-50 border-rose-200 text-rose-700'
                : modalNotification.type === 'warning'
                ? 'bg-amber-50 border-amber-200 text-amber-800'
                : 'bg-[#EDE9FE] border-[#DDD6FE] text-[#5B4DF5]'
            }`}>
              <AlertCircle className={`w-4 h-4 shrink-0 ${
                modalNotification.type === 'error'
                  ? 'text-rose-500'
                  : modalNotification.type === 'warning'
                  ? 'text-amber-500'
                  : 'text-[#5B4DF5]'
              }`} />
              <span className="font-medium">{modalNotification.message}</span>
            </div>
          )}

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{error}</span>
            </div>
          )}

          {/* Listing Title */}
          <div>
            <label className="block text-xs font-extrabold uppercase text-[#64748B] mb-1">
              Listing Title *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Aged 2019 Facebook Account (5K Friends, Active Feed, PVA)"
              className="w-full bg-[#F8F7FD] text-[#0F172A] p-3 rounded-2xl border border-[#EBE7F7] focus:outline-none focus:border-[#5B4DF5] focus:bg-white text-xs sm:text-sm"
              required
            />
          </div>

          {/* Category & Price */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-extrabold uppercase text-[#64748B] mb-1">
                Category *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as CategoryType)}
                className="w-full bg-[#F8F7FD] text-[#0F172A] p-3 rounded-2xl border border-[#EBE7F7] focus:outline-none focus:border-[#5B4DF5] focus:bg-white text-xs sm:text-sm"
              >
                <option value="Facebook">Facebook Account</option>
                <option value="TikTok">TikTok Account</option>
                <option value="Instagram">Instagram Account</option>
                <option value="Gmail">Gmail / Google PVA</option>
                <option value="Other">Other Verified Account</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-extrabold uppercase text-[#64748B] mb-1">
                Price (NGN ₦) *
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#5B4DF5] font-extrabold">₦</span>
                <input
                  type="number"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="95000"
                  className="w-full bg-[#F8F7FD] text-[#0F172A] pl-8 pr-3 py-3 rounded-2xl border border-[#EBE7F7] focus:outline-none focus:border-[#5B4DF5] focus:bg-white text-xs sm:text-sm font-mono font-bold"
                  required
                />
              </div>
            </div>
          </div>

          {/* Followers & Account Age */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-extrabold uppercase text-[#64748B] mb-1">
                Followers / Friends Count
              </label>
              <input
                type="text"
                value={followers}
                onChange={(e) => setFollowers(e.target.value)}
                placeholder="e.g. 15.4K Followers, 4,800 Friends"
                className="w-full bg-[#F8F7FD] text-[#0F172A] p-3 rounded-2xl border border-[#EBE7F7] focus:outline-none focus:border-[#5B4DF5] focus:bg-white text-xs sm:text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-extrabold uppercase text-[#64748B] mb-1">
                Account Age
              </label>
              <input
                type="text"
                value={accountAge}
                onChange={(e) => setAccountAge(e.target.value)}
                placeholder="e.g. 4 Years Old (Creation 2020)"
                className="w-full bg-[#F8F7FD] text-[#0F172A] p-3 rounded-2xl border border-[#EBE7F7] focus:outline-none focus:border-[#5B4DF5] focus:bg-white text-xs sm:text-sm"
              />
            </div>
          </div>

          {/* Secure Digital Product Details Section (Multi-Stock Inventory Manager) */}
          <div className="bg-[#F8F7FD] border border-[#EBE7F7] p-4 sm:p-5 rounded-3xl space-y-4 shadow-xs relative overflow-hidden">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#EBE7F7] pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-[#EDE9FE] border border-[#DDD6FE] flex items-center justify-center text-[#5B4DF5]">
                  <Key className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-[#0F172A] text-sm flex items-center gap-2">
                    Product Stock / Inventory
                    <span className="bg-white text-[#5B4DF5] border border-[#DDD6FE] text-[10px] px-2 py-0.5 rounded-full uppercase font-bold flex items-center gap-1 shadow-2xs">
                      <Lock className="w-3 h-3 text-[#5B4DF5]" /> Private Escrow
                    </span>
                  </h3>
                  <p className="text-[11px] text-[#64748B]">
                    Each stock item is unique and sold only once to one customer.
                  </p>
                </div>
              </div>

              {/* Stock Count Indicators */}
              <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
                <div className="px-3 py-1 bg-white border border-[#DDD6FE] rounded-xl text-[#5B4DF5] text-xs font-black flex items-center gap-1.5 shadow-2xs">
                  <span className="w-2 h-2 rounded-full bg-[#5B4DF5] animate-pulse" />
                  <span>Available: {inventoryAccounts.filter(i => (i.status || '').toLowerCase() !== 'sold').length}</span>
                </div>
                {inventoryAccounts.some(i => (i.status || '').toLowerCase() === 'sold') && (
                  <div className="px-2.5 py-1 bg-white border border-rose-200 rounded-xl text-rose-600 text-xs font-bold flex items-center gap-1 shadow-2xs">
                    <span>Sold: {inventoryAccounts.filter(i => (i.status || '').toLowerCase() === 'sold').length}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Privacy Alert Banner */}
            <div className="bg-white border border-[#EBE7F7] p-3 rounded-2xl flex items-start gap-2.5 text-xs text-[#64748B] shadow-2xs">
              <ShieldCheck className="w-4 h-4 text-[#5B4DF5] shrink-0 mt-0.5" />
              <p className="text-[11px] leading-relaxed">
                <strong className="text-[#0F172A] font-bold">Confidential & Encrypted:</strong> Details stored here remain private. They are never rendered publicly on product pages or search results, and are automatically revealed <span className="text-[#5B4DF5] font-bold">ONLY to the buyer</span> after payment.
              </p>
            </div>

            {/* Existing Stock Items List */}
            {loadingInventory ? (
              <div className="py-4 text-center text-[#64748B] text-xs flex items-center justify-center gap-2">
                <span className="w-4 h-4 border-2 border-[#5B4DF5] border-t-transparent rounded-full animate-spin"></span>
                <span>Loading active inventory stock...</span>
              </div>
            ) : (
              inventoryAccounts.length > 0 && (
                <div className="space-y-2 mb-4 bg-white p-3.5 rounded-2xl border border-[#EBE7F7] shadow-2xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <span className="text-[11px] uppercase font-black text-[#0F172A] tracking-wider">
                      Stock Inventory ({inventoryAccounts.length} Total)
                    </span>
                    
                    {/* Stock filter tab */}
                    <div className="flex items-center gap-1 bg-[#F8F7FD] p-0.5 rounded-lg border border-[#EBE7F7] text-[10px] font-bold">
                      <button
                        type="button"
                        onClick={() => setStockFilterTab('available')}
                        className={`px-2 py-0.5 rounded transition cursor-pointer ${
                          stockFilterTab === 'available'
                            ? 'bg-[#5B4DF5] text-white shadow-xs'
                            : 'text-[#64748B] hover:text-[#0F172A]'
                        }`}
                      >
                        Available ({inventoryAccounts.filter(i => (i.status || '').toLowerCase() !== 'sold').length})
                      </button>
                      <button
                        type="button"
                        onClick={() => setStockFilterTab('sold')}
                        className={`px-2 py-0.5 rounded transition cursor-pointer ${
                          stockFilterTab === 'sold'
                            ? 'bg-rose-600 text-white shadow-xs'
                            : 'text-[#64748B] hover:text-[#0F172A]'
                        }`}
                      >
                        Sold ({inventoryAccounts.filter(i => (i.status || '').toLowerCase() === 'sold').length})
                      </button>
                      <button
                        type="button"
                        onClick={() => setStockFilterTab('all')}
                        className={`px-2 py-0.5 rounded transition cursor-pointer ${
                          stockFilterTab === 'all'
                            ? 'bg-[#5B4DF5] text-white shadow-xs'
                            : 'text-[#64748B] hover:text-[#0F172A]'
                        }`}
                      >
                        All ({inventoryAccounts.length})
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-2 max-h-56 overflow-y-auto pr-1">
                    {inventoryAccounts
                      .filter(item => {
                        const isSold = (item.status || '').toLowerCase() === 'sold';
                        if (stockFilterTab === 'available') return !isSold;
                        if (stockFilterTab === 'sold') return isSold;
                        return true;
                      })
                      .map((item, idx) => {
                        const originalIdx = inventoryAccounts.findIndex(i => i.id === item.id);
                        const isSold = (item.status || '').toLowerCase() === 'sold';
                        return (
                          <div 
                            key={item.id}
                            onClick={() => {
                              handleEditAccountLocal(originalIdx);
                            }}
                            className={`p-2.5 rounded-xl flex items-center justify-between gap-3 text-xs border transition ${
                              isSold
                                ? 'bg-rose-50 border-rose-200 opacity-90'
                                : 'bg-[#F8F7FD] border-[#EBE7F7] hover:border-[#5B4DF5]/40 cursor-pointer hover:bg-white'
                            }`}
                            title="Click to edit details"
                          >
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className={`text-[10px] font-black px-2 py-0.5 rounded-md border ${
                                  isSold
                                    ? 'bg-rose-100 text-rose-700 border-rose-200'
                                    : 'bg-[#EDE9FE] text-[#5B4DF5] border-[#DDD6FE]'
                                }`}>
                                  Item #{originalIdx + 1}
                                </span>
                                <span 
                                  className="text-[#0F172A] font-mono font-medium truncate max-w-[220px] select-all hover:text-[#5B4DF5] flex items-center gap-1 cursor-text"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    const val = item.accountEmail || item.delivery_value || '';
                                    if (val) {
                                      copyToClipboard(val);
                                      triggerNotification('success', `Copied Login/Email: ${val}`);
                                    }
                                  }}
                                  title="Click to select/copy Login/Email"
                                >
                                  <span>{item.accountEmail || item.delivery_value || 'Stock Item'}</span>
                                  <Copy className="w-3 h-3 text-[#64748B] hover:text-[#5B4DF5] shrink-0 cursor-pointer" />
                                </span>
                                {item.accountPassword && (
                                  <span className="text-[#64748B] font-mono text-[11px] flex items-center gap-1 bg-white px-1.5 py-0.5 rounded border border-[#EBE7F7]">
                                    <span>• pass:</span>
                                    <span 
                                      className="text-[#0F172A] font-extrabold select-all hover:text-[#5B4DF5] flex items-center gap-1 cursor-text"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        if (revealedPasswords[item.id]) {
                                          copyToClipboard(item.accountPassword);
                                          triggerNotification('success', 'Copied password to clipboard!');
                                        } else {
                                          setRevealedPasswords(prev => ({ ...prev, [item.id]: true }));
                                          copyToClipboard(item.accountPassword);
                                          triggerNotification('success', 'Password revealed and copied!');
                                        }
                                      }}
                                      title="Click to reveal & copy password"
                                    >
                                      <span>{revealedPasswords[item.id] ? item.accountPassword : '••••••'}</span>
                                      <Copy className="w-2.5 h-2.5 text-[#64748B] hover:text-[#5B4DF5] shrink-0 cursor-pointer" />
                                    </span>
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setRevealedPasswords(prev => ({ ...prev, [item.id]: !prev[item.id] }));
                                      }}
                                      className="text-[#64748B] hover:text-[#0F172A] transition cursor-pointer p-0.5"
                                    >
                                      {revealedPasswords[item.id] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                                    </button>
                                  </span>
                                )}
                                {isSold && (
                                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-rose-100 text-rose-700 border border-rose-200">
                                    Sold {item.soldTo ? `to ${item.soldTo.substring(0, 8)}...` : ''}
                                  </span>
                                )}
                                {!isSold && (
                                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-[#EDE9FE] text-[#5B4DF5] border border-[#DDD6FE]">
                                    Available
                                  </span>
                                )}
                                {editingIndex === originalIdx && (
                                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300 animate-pulse">
                                    Editing
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-1.5 shrink-0" onClick={(e) => e.stopPropagation()}>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleEditAccountLocal(originalIdx);
                                }}
                                className="p-1.5 text-[#64748B] hover:text-[#0F172A] hover:bg-[#EDE9FE] rounded-lg transition cursor-pointer"
                                title="Edit Stock Item"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setStockItemToDelete({ item, index: originalIdx });
                                }}
                                className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                                title="Delete Stock Item"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
              )
            )}

            {/* Stock Credentials Form */}
            <div className="bg-white p-3.5 rounded-2xl border border-[#EBE7F7] space-y-3.5 shadow-2xs">
              <span className="text-[10px] uppercase font-bold text-[#5B4DF5] tracking-wider block">
                {editingIndex !== null ? `Edit Stock Item #${editingIndex + 1}` : 'Enter Single Stock Item Details'}
              </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[#0F172A] text-xs font-bold mb-1">Stock Item Login / Email / Code *</label>
                    <input
                      type="text"
                      placeholder="e.g. CODE-001 or account@gmail.com"
                      value={accountEmail}
                      onChange={(e) => setAccountEmail(e.target.value)}
                      className="w-full bg-[#F8F7FD] text-[#0F172A] text-xs p-2.5 rounded-xl border border-[#EBE7F7] focus:outline-none focus:border-[#5B4DF5] focus:bg-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[#0F172A] text-xs font-bold mb-1">Account Password (If applicable)</label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        placeholder="e.g. AccountPass123!"
                        value={accountPassword}
                        onChange={(e) => setAccountPassword(e.target.value)}
                        className="w-full bg-[#F8F7FD] text-[#0F172A] text-xs p-2.5 pr-9 rounded-xl border border-[#EBE7F7] focus:outline-none focus:border-[#5B4DF5] focus:bg-white font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-2.5 top-2.5 text-[#64748B] hover:text-[#0F172A] transition cursor-pointer"
                        title={showPassword ? 'Hide Password' : 'Show Password'}
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Dynamic Custom Delivery Fields */}
                <div className="space-y-2 pt-1 border-t border-[#EBE7F7]">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="text-[#0F172A] text-xs font-bold flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-[#5B4DF5]" />
                      <span>Custom Delivery Fields (Optional)</span>
                    </label>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleAddCustomField('Recovery Email')}
                        className="text-[10px] font-bold bg-[#EDE9FE] text-[#5B4DF5] hover:bg-[#DDD6FE] px-2 py-0.5 rounded-lg transition cursor-pointer"
                      >
                        + Recovery Email
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAddCustomField('Gmail Recovery Password')}
                        className="text-[10px] font-bold bg-[#EDE9FE] text-[#5B4DF5] hover:bg-[#DDD6FE] px-2 py-0.5 rounded-lg transition cursor-pointer"
                      >
                        + Recovery Password
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAddCustomField('Two-Factor Authenticator')}
                        className="text-[10px] font-bold bg-[#EDE9FE] text-[#5B4DF5] hover:bg-[#DDD6FE] px-2 py-0.5 rounded-lg transition cursor-pointer"
                      >
                        + 2FA / TOTP
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAddCustomField()}
                        className="text-[10px] font-bold bg-[#F1F0FB] text-[#475569] hover:bg-[#EBE7F7] px-2 py-0.5 rounded-lg transition cursor-pointer border border-[#E2E8F0]"
                      >
                        + Custom Field
                      </button>
                    </div>
                  </div>

                  {customFields.map((cf) => (
                    <div key={cf.id} className="flex items-center gap-2 bg-[#F8F7FD] p-2 rounded-xl border border-[#EBE7F7]">
                      <input
                        type="text"
                        placeholder="Field Name (e.g. Recovery Email)"
                        value={cf.label}
                        onChange={(e) => handleUpdateCustomField(cf.id, 'label', e.target.value)}
                        className="w-1/3 sm:w-2/5 bg-white text-[#0F172A] text-xs p-2 rounded-lg border border-[#EBE7F7] focus:outline-none focus:border-[#5B4DF5]"
                      />
                      <input
                        type="text"
                        placeholder="Delivery Value"
                        value={cf.value}
                        onChange={(e) => handleUpdateCustomField(cf.id, 'value', e.target.value)}
                        className="flex-1 bg-white text-[#0F172A] text-xs p-2 rounded-lg border border-[#EBE7F7] focus:outline-none focus:border-[#5B4DF5] font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => handleRemoveCustomField(cf.id)}
                        className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                        title="Remove Field"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Availability / Release State Selector when editing */}
                {editingIndex !== null && (
                  <div className="bg-[#F8F7FD] p-3 rounded-xl border border-[#EBE7F7] space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="block text-[#0F172A] text-xs font-bold">
                        Stock Availability / Status
                      </label>
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-md border ${
                        stockItemStatus === 'Sold'
                          ? 'bg-rose-100 text-rose-700 border-rose-200'
                          : 'bg-emerald-100 text-emerald-700 border-emerald-200'
                      }`}>
                        Current: {stockItemStatus}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setStockItemStatus('Available')}
                        className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                          stockItemStatus === 'Available'
                            ? 'bg-emerald-50 border-emerald-400 text-emerald-700 shadow-2xs font-black'
                            : 'bg-white border-[#EBE7F7] text-[#64748B] hover:text-[#0F172A]'
                        }`}
                      >
                        <span className="w-2 h-2 rounded-full bg-emerald-500" />
                        <span>Available (In Stock)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setStockItemStatus('Sold')}
                        className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                          stockItemStatus === 'Sold'
                            ? 'bg-rose-50 border-rose-400 text-rose-700 shadow-2xs font-black'
                            : 'bg-white border-[#EBE7F7] text-[#64748B] hover:text-[#0F172A]'
                        }`}
                      >
                        <span className="w-2 h-2 rounded-full bg-rose-500" />
                        <span>Sold</span>
                      </button>
                    </div>

                    {inventoryAccounts[editingIndex] && (inventoryAccounts[editingIndex].status || '').toLowerCase() === 'sold' && stockItemStatus === 'Available' && (
                      <p className="text-[11px] text-amber-800 bg-amber-50 p-2 rounded-lg border border-amber-200 font-semibold leading-relaxed">
                        ⚠️ Releasing this sold item back to stock will make it available for purchase and clear old order tags upon Save.
                      </p>
                    )}
                  </div>
                )}

                <div className="pt-2 flex items-center gap-2">
                  {editingIndex !== null && (
                    <button
                      type="button"
                      onClick={handleCancelStockEdit}
                      className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                    >
                      Cancel
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={handleAddAccountToInventory}
                    className="flex-1 bg-[#EDE9FE] hover:bg-[#DDD6FE] border border-[#DDD6FE] text-[#5B4DF5] font-extrabold text-xs py-2.5 px-4 rounded-xl transition cursor-pointer flex items-center justify-center gap-2"
                  >
                    <PlusCircle className="w-4 h-4 text-[#5B4DF5]" />
                    <span>{editingIndex !== null ? '💾 Save Item Changes' : '＋ Add This Item to Stock'}</span>
                  </button>
                </div>
              </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-extrabold uppercase text-[#64748B] mb-1">
              Account Description & Proof Details
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              placeholder="Describe the account history, niche, engagement rates, transfer instructions..."
              className="w-full bg-[#F8F7FD] text-[#0F172A] p-3 rounded-2xl border border-[#EBE7F7] focus:outline-none focus:border-[#5B4DF5] focus:bg-white text-xs sm:text-sm"
              required
            />
          </div>

          {/* Multiple Images Upload & Gallery */}
          <div className="bg-[#F8F7FD] p-4 rounded-2xl border border-[#EBE7F7] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold uppercase text-[#0F172A] flex items-center gap-1.5">
                <Image className="w-4 h-4 text-[#5B4DF5]" />
                Account Screenshots & Images ({images.length})
              </span>
              <label className="bg-[#5B4DF5] hover:bg-[#4838EE] text-white font-bold text-xs px-3 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1 shadow-xs">
                <Plus className="w-3.5 h-3.5" />
                <span>{uploadingImage ? 'Uploading...' : 'Upload Local File'}</span>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  disabled={uploadingImage}
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {uploadingImage && (
              <div className="text-[11px] text-[#5B4DF5] bg-[#EDE9FE] border border-[#DDD6FE] p-2 rounded-xl flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#5B4DF5] shrink-0 shadow-2xs" />
                <span>Uploading screenshots to Firebase Storage...</span>
              </div>
            )}

            {imageUploadError && (
              <div className="text-[11px] text-rose-700 bg-rose-50 border border-rose-200 p-2 rounded-xl">
                ⚠️ {imageUploadError}
              </div>
            )}

            {/* Input image URL */}
            <div className="flex gap-2">
              <input
                type="text"
                value={newImageUrl}
                onChange={(e) => setNewImageUrl(e.target.value)}
                placeholder="Or paste image URL (https://...)"
                className="flex-1 bg-white text-[#0F172A] p-2.5 rounded-xl border border-[#EBE7F7] text-xs focus:outline-none focus:border-[#5B4DF5]"
              />
              <button
                type="button"
                onClick={() => handleAddImage()}
                disabled={!newImageUrl.trim()}
                className="bg-[#EDE9FE] hover:bg-[#DDD6FE] text-[#5B4DF5] font-bold px-3 py-2 rounded-xl text-xs border border-[#DDD6FE] transition disabled:opacity-40 cursor-pointer"
              >
                Add URL
              </button>
            </div>

            {/* Category Presets */}
            <div>
              <span className="text-[10px] text-[#64748B] font-semibold block mb-1">Quick Presets:</span>
              <div className="flex flex-wrap gap-1.5">
                {(defaultCategoryImages[category] || defaultCategoryImages.Facebook).map((imgUrl, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => handleAddImage(imgUrl)}
                    className="bg-white hover:bg-[#EDE9FE] text-[#5B4DF5] text-[10px] px-2.5 py-1 rounded-lg border border-[#EBE7F7] transition cursor-pointer font-medium"
                  >
                    + Preset {i + 1}
                  </button>
                ))}
              </div>
            </div>

            {/* Thumbnail Grid */}
            {images.length > 0 && (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 pt-2 border-t border-[#EBE7F7]">
                {images.map((img, idx) => (
                  <div 
                    key={idx} 
                    className={`relative rounded-xl overflow-hidden border group bg-slate-100 aspect-video ${
                      imageUrl === img ? 'border-[#5B4DF5] ring-2 ring-[#5B4DF5]/30' : 'border-[#EBE7F7]'
                    }`}
                  >
                    <img src={img} alt={`Screenshot ${idx + 1}`} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-1 p-1">
                      <button
                        type="button"
                        onClick={() => setImageUrl(img)}
                        className="p-1 bg-[#5B4DF5] text-white rounded-lg text-[9px] font-bold cursor-pointer"
                        title="Set as Main Cover Image"
                      >
                        Main
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRemoveImage(idx)}
                        className="p-1 bg-rose-600 text-white rounded-lg cursor-pointer"
                        title="Remove Image"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    {imageUrl === img && (
                      <span className="absolute top-1 left-1 bg-[#5B4DF5] text-white text-[9px] font-black px-1.5 rounded uppercase">
                        Cover
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Form Actions */}
          <div className="pt-3 border-t border-[#EBE7F7] flex items-center justify-end gap-3 shrink-0">
            <button
              type="button"
              onClick={handleRequestClose}
              className="px-4 py-2.5 text-[#64748B] hover:text-[#0F172A] bg-[#F8F7FD] hover:bg-[#F2EFFC] border border-[#EBE7F7] rounded-2xl text-xs font-bold transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2.5 bg-[#5B4DF5] hover:bg-[#4838EE] text-white text-xs font-extrabold rounded-2xl shadow-md transition cursor-pointer flex items-center gap-2 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{loading ? 'Saving Changes...' : 'Save Listing Updates'}</span>
            </button>
          </div>
        </form>

        {/* Unsaved Changes Confirmation Overlay */}
        {showCancelConfirm && (
          <div className="absolute inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
            <div className="bg-white border border-[#EBE7F7] p-6 rounded-3xl max-w-sm w-full space-y-4 shadow-2xl text-center">
              <div className="w-12 h-12 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-center mx-auto text-amber-500">
                <AlertCircle className="w-6 h-6" />
              </div>
              
              <div className="space-y-1">
                <h3 className="font-extrabold text-[#0F172A] text-base sm:text-lg">Unsaved Changes</h3>
                <p className="text-xs text-[#64748B] leading-relaxed">
                  You have unsaved changes. Are you sure you want to cancel?
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCancelConfirm(false)}
                  className="py-2.5 px-3 bg-[#F8F7FD] hover:bg-[#F2EFFC] text-[#0F172A] border border-[#EBE7F7] rounded-xl font-bold text-xs transition cursor-pointer"
                >
                  Continue Editing
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowCancelConfirm(false);
                    onClose();
                  }}
                  className="py-2.5 px-3 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-extrabold text-xs shadow-md transition cursor-pointer"
                >
                  Discard Changes
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Stock Item Delete Confirmation Dialog */}
        {stockItemToDelete && (
          <div 
            className="fixed inset-0 z-70 bg-black/60 backdrop-blur-2xs flex items-center justify-center p-4 animate-in fade-in duration-150"
            onClick={() => !isDeletingStockItem && setStockItemToDelete(null)}
          >
            <div 
              className="bg-white rounded-2xl p-5 max-w-xs sm:max-w-sm w-full shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95 duration-150"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
                  <Trash2 className="w-5 h-5 text-rose-600" />
                </div>
                <div className="min-w-0">
                  <h4 className="text-sm font-extrabold text-slate-900">Delete Stock Item</h4>
                  <p className="text-[11px] text-slate-500 font-mono truncate">
                    {stockItemToDelete.item.accountEmail || stockItemToDelete.item.delivery_value || `Item #${stockItemToDelete.index + 1}`}
                  </p>
                </div>
              </div>

              <p className="text-xs text-slate-600 font-medium">
                Are you sure you want to delete this stock item?
              </p>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  disabled={isDeletingStockItem}
                  onClick={() => setStockItemToDelete(null)}
                  className="px-3.5 py-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="button"
                  disabled={isDeletingStockItem}
                  onClick={() => handleConfirmDeleteStockItem(stockItemToDelete.item, stockItemToDelete.index)}
                  className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-2xs active:scale-95"
                >
                  {isDeletingStockItem ? (
                    <>
                      <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Deleting...</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-3 h-3" />
                      <span>Delete</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
