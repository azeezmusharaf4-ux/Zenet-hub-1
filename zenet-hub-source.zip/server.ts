import dotenv from 'dotenv';
dotenv.config({ override: true });
try {
  dotenv.config({ path: './.env', override: true });
  dotenv.config({ path: './.env.local', override: true });
} catch {}
import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc, updateDoc, deleteDoc, collection, query, where, getDocs, runTransaction } from 'firebase/firestore';
import { isAuthorizedOwnerEmail, isAuthorizedOwnerUid } from './src/lib/authorizedOwners';
import { handleVirtualSMSNumbersGateway, handleVirtualSMSNumbersWebhook } from './src/server/virtualSmsNumbers';
import { handleVoikerGateway } from './src/server/voikerBoosting';

const app = express();
const PORT = 3000;

app.disable('x-powered-by');

// Completely clear out any deprecated OneGridHub / XtraLogsTools / Provider 2 API keys, tokens, and URLs
const DEPRECATED_PROVIDER_ENV_KEYS = [
  'ESTRALOG_API_KEY',
  'ESTRALOGS_API_KEY',
  'ESTRALOG_BASE_URL',
  'ESTRALOGS_BASE_URL',
  'ESTRALOG_TOOLS_API_KEY',
  'ESTRALOGS_TOOLS_API_KEY',
  'ESTRALOG_TOOLS_BASE_URL',
  'EXTRA_LOG_API_KEY',
  'EXTRA_LOGS_API_KEY',
  'EXTRA_LOG_BASE_URL',
  'EXTRA_LOGS_BASE_URL',
  'EXTRA_LOG_TOOLS_API_KEY',
  'EXTRA_LOGS_TOOLS_API_KEY',
  'EXTRA_LOG_TOOLS_BASE_URL',
  'EXTRA_LOGS_TOOLS_BASE_URL',
  'XTRALOGSTOOLS_API_KEY',
  'XTRALOGS_API_KEY',
  'XTRALOGS_TOOLS_API_KEY',
  'XTRALOGSTOOLS_BASE_URL',
  'ONEGRIDHUB_API_KEY',
  'ONEGRID_API_KEY',
  'ONEGRIDHUB_KEY',
  'ONE_GRID_HUB_API_KEY',
  'OGH_API_KEY',
  'ONEGRIDHUB_TOKEN',
  'ONEGRIDHUB_SECRET',
  'ONEGRIDHUB_BASE_URL',
  'ONEGRIDHUB_SMM_API_KEY',
  'ONEGRIDHUB_SMM_KEY',
  'PROVIDER2_NUMBERS_API_KEY',
  'PROVIDER2_NUMBERS_BASE_URL',
  'PROVIDER2_SOCIAL_BOOST_API_KEY',
  'PROVIDER2_SOCIAL_BOOST_BASE_URL',
  'PROVIDER2_SMM_API_KEY',
  'PROVIDER2_API_KEY',
  'ER2_SOCIAL_BOOST_API_KEY',
  'ER2_SOCIAL_BOOST_BASE_URL',
  'SOCIAL_BOOST_2_API_KEY'
];
for (const k of DEPRECATED_PROVIDER_ENV_KEYS) {
  delete process.env[k];
}

// --- ARCC & OWASP SECURITY HEADERS ---
app.use((_req, res, next) => {
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self' https: data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' https:; style-src 'self' 'unsafe-inline' https:; font-src 'self' https: data:; img-src 'self' data: blob: https:; connect-src 'self' https: wss:; frame-ancestors 'self' https:;"
  );
  next();
});

// Enable CORS for all API requests
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, x-paystack-signature, x-vsn-signature, X-VSN-Signature, x-vsn-timestamp, X-VSN-Timestamp');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

app.use(express.json({
  verify: (req: any, _res, buf) => {
    req.rawBody = buf;
  }
}));

// --- CSRF PROTECTION ON STATE-CHANGING API ENDPOINTS ---
app.use((req, res, next) => {
  if (req.path.startsWith('/api') && ['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method)) {
    // External Webhooks are validated cryptographically by secret HMAC signatures
    if (req.path.includes('/paystack/webhook') || req.path.includes('/webhook') || req.path.includes('/hooks/')) {
      return next();
    }
    const hasRequestedWith = req.headers['x-requested-with'] === 'XMLHttpRequest';
    const hasAuthToken = !!req.headers['authorization']?.startsWith('Bearer ');
    const secFetchSite = req.headers['sec-fetch-site'] as string;
    const isSameSite = secFetchSite === 'same-origin' || secFetchSite === 'none';

    if (!hasRequestedWith && !hasAuthToken && !isSameSite) {
      return res.status(403).json({
        success: false,
        error: 'Forbidden: Anti-CSRF verification failed. Request must include valid client headers.'
      });
    }
  }
  next();
});

// Route Normalization Safeguard: strip any accidental client prefix (e.g. /VITE_API_URL/api/* -> /api/*)
app.use((req, _res, next) => {
  if (req.url.startsWith('/VITE_API_URL/')) {
    req.url = req.url.replace('/VITE_API_URL', '');
  } else if (req.url.startsWith('/undefined/')) {
    req.url = req.url.replace('/undefined', '');
  } else if (req.url.startsWith('/.netlify/functions/api')) {
    req.url = req.url.replace('/.netlify/functions/api', '') || '/';
    if (!req.url.startsWith('/')) req.url = '/' + req.url;
  }
  next();
});

// --- ANTI-SPAM, BOT PROTECTION & RATE LIMITING MIDDLEWARE ---
interface RateLimitBucket {
  count: number;
  resetAt: number;
}
const ipRateLimitMap = new Map<string, RateLimitBucket>();

// Periodic memory cleanup every 60 seconds
setInterval(() => {
  const now = Date.now();
  for (const [ip, bucket] of ipRateLimitMap.entries()) {
    if (bucket.resetAt < now) {
      ipRateLimitMap.delete(ip);
    }
  }
}, 60000);

app.use((req, res, next) => {
  // 1. Screen malicious automated scrapers/bots
  const userAgent = (req.headers['user-agent'] || '').toLowerCase();
  const blockedSignatures = [
    'sqlmap', 'nikto', 'acunetix', 'dirbuster', 'gobuster', 'wpscan', 'masscan', 'nmap', 'zgrab', 'havij', 'pangolin'
  ];
  if (blockedSignatures.some(sig => userAgent.includes(sig))) {
    return res.status(403).json({ success: false, error: 'Forbidden: Request blocked by security shield.' });
  }

  // 2. Sliding window rate limiting on /api endpoints
  if (req.path.startsWith('/api') && req.path !== '/api/health') {
    const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || 'unknown';
    const now = Date.now();
    const windowMs = 60000; // 1 minute
    const maxRequests = 180; // Generous ceiling for normal users and fast mobile taps

    let bucket = ipRateLimitMap.get(clientIp);
    if (!bucket || bucket.resetAt < now) {
      bucket = { count: 1, resetAt: now + windowMs };
      ipRateLimitMap.set(clientIp, bucket);
    } else {
      bucket.count++;
      if (bucket.count > maxRequests) {
        res.setHeader('Retry-After', Math.ceil((bucket.resetAt - now) / 1000));
        return res.status(429).json({
          success: false,
          error: 'Rate limit exceeded. Please slow down and try again shortly.'
        });
      }
    }
  }

  next();
});

// Initialize Server-side Firebase Firestore instance
let db: any = null;
let serverAuth: any = null;
let firebaseProjectId = '';
let firebaseDatabaseId = '';

const SERVER_SERVICE_EMAIL = 'zenet-backend-service@zenetmarketplace.internal';
const SERVER_SERVICE_PASSWORD = 'ZenetSecureSystemBackend2026!#';

async function ensureServerAuthenticated() {
  if (!serverAuth) return;
  if (serverAuth.currentUser) return;
  try {
    await signInWithEmailAndPassword(serverAuth, SERVER_SERVICE_EMAIL, SERVER_SERVICE_PASSWORD);
  } catch (err: any) {
    if (err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') {
      try {
        await createUserWithEmailAndPassword(serverAuth, SERVER_SERVICE_EMAIL, SERVER_SERVICE_PASSWORD);
      } catch (cErr) {
        console.warn('[Server Auth] Service account provisioning notice:', cErr);
      }
    } else {
      console.warn('[Server Auth] Service authentication notice:', err?.message || err);
    }
  }
}

try {
  const firebaseConfigPath = path.join(process.cwd(), 'firebase-applet-config.json');
  if (fs.existsSync(firebaseConfigPath)) {
    const firebaseConfigData = JSON.parse(fs.readFileSync(firebaseConfigPath, 'utf8'));
    firebaseProjectId = firebaseConfigData.projectId || '';
    firebaseDatabaseId = firebaseConfigData.firestoreDatabaseId || '(default)';
    const firebaseApp = getApps().length > 0 ? getApp() : initializeApp({
      apiKey: firebaseConfigData.apiKey,
      authDomain: firebaseConfigData.authDomain,
      projectId: firebaseConfigData.projectId,
      storageBucket: firebaseConfigData.storageBucket,
      messagingSenderId: firebaseConfigData.messagingSenderId,
      appId: firebaseConfigData.appId,
    });
    db = getFirestore(firebaseApp, firebaseConfigData.firestoreDatabaseId || undefined);
    serverAuth = getAuth(firebaseApp);
    
    // Background authenticating server backend service
    ensureServerAuthenticated().then(() => {
      if (serverAuth?.currentUser) {
        console.log(`[Server Auth] Server service authenticated: ${serverAuth.currentUser.email}`);
      }
    }).catch((e) => {
      console.warn('[Server Auth] Initial authentication error:', e);
    });

    console.log(`Server-side Firestore initialized successfully (Project: ${firebaseProjectId}, DB: ${firebaseDatabaseId})`);
  }
} catch (fInitErr) {
  console.warn('Server-side Firestore initialization notice:', fInitErr);
}

// Firestore REST API helpers for executing operations with caller's verified ID token
function toFirestoreRestValue(val: any): any {
  if (val === null || val === undefined) return { nullValue: null };
  if (typeof val === 'boolean') return { booleanValue: val };
  if (typeof val === 'number') {
    return Number.isInteger(val) ? { integerValue: String(val) } : { doubleValue: val };
  }
  if (typeof val === 'string') return { stringValue: val };
  if (Array.isArray(val)) {
    return { arrayValue: { values: val.map(toFirestoreRestValue) } };
  }
  if (typeof val === 'object') {
    const fields: Record<string, any> = {};
    for (const [k, v] of Object.entries(val)) {
      if (v !== undefined) fields[k] = toFirestoreRestValue(v);
    }
    return { mapValue: { fields } };
  }
  return { stringValue: String(val) };
}

function fromFirestoreRestValue(val: any): any {
  if (!val) return null;
  if ('stringValue' in val) return val.stringValue;
  if ('integerValue' in val) return Number(val.integerValue);
  if ('doubleValue' in val) return Number(val.doubleValue);
  if ('booleanValue' in val) return Boolean(val.booleanValue);
  if ('nullValue' in val) return null;
  if ('timestampValue' in val) return val.timestampValue;
  if ('arrayValue' in val) return (val.arrayValue?.values || []).map(fromFirestoreRestValue);
  if ('mapValue' in val) {
    const res: any = {};
    for (const [k, v] of Object.entries(val.mapValue?.fields || {})) {
      res[k] = fromFirestoreRestValue(v);
    }
    return res;
  }
  return null;
}

function parseFirestoreRestDoc(docObj: any): any {
  if (!docObj || !docObj.fields) return null;
  const res: any = {};
  for (const [k, v] of Object.entries(docObj.fields)) {
    res[k] = fromFirestoreRestValue(v);
  }
  if (docObj.name) {
    const parts = docObj.name.split('/');
    res.id = parts[parts.length - 1];
  }
  return res;
}

async function restGetFirestoreDoc(collectionPath: string, docId: string, idToken: string): Promise<any> {
  const dbId = firebaseDatabaseId || '(default)';
  const url = `https://firestore.googleapis.com/v1/projects/${firebaseProjectId}/databases/${dbId}/documents/${collectionPath}/${encodeURIComponent(docId)}`;
  const res = await fetch(url, {
    headers: {
      'Authorization': `Bearer ${idToken}`,
      'Accept': 'application/json'
    }
  });
  if (res.status === 404) return null;
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Firestore REST GET error (${res.status}): ${errText}`);
  }
  const data = await res.json();
  return parseFirestoreRestDoc(data);
}

async function restPatchFirestoreDoc(collectionPath: string, docId: string, fields: Record<string, any>, idToken: string): Promise<any> {
  const dbId = firebaseDatabaseId || '(default)';
  const fieldKeys = Object.keys(fields);
  const updateMask = fieldKeys.map(k => `updateMask.fieldPaths=${encodeURIComponent(k)}`).join('&');
  const url = `https://firestore.googleapis.com/v1/projects/${firebaseProjectId}/databases/${dbId}/documents/${collectionPath}/${encodeURIComponent(docId)}${updateMask ? '?' + updateMask : ''}`;
  
  const firestoreFields: Record<string, any> = {};
  for (const [k, v] of Object.entries(fields)) {
    firestoreFields[k] = toFirestoreRestValue(v);
  }

  const res = await fetch(url, {
    method: 'PATCH',
    headers: {
      'Authorization': `Bearer ${idToken}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify({ fields: firestoreFields })
  });
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Firestore REST PATCH error (${res.status}): ${errText}`);
  }
  return await res.json();
}

async function restCreateFirestoreDoc(collectionPath: string, docId: string, fields: Record<string, any>, idToken: string): Promise<any> {
  const dbId = firebaseDatabaseId || '(default)';
  const url = `https://firestore.googleapis.com/v1/projects/${firebaseProjectId}/databases/${dbId}/documents/${collectionPath}?documentId=${encodeURIComponent(docId)}`;
  
  const firestoreFields: Record<string, any> = {};
  for (const [k, v] of Object.entries(fields)) {
    firestoreFields[k] = toFirestoreRestValue(v);
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${idToken}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify({ fields: firestoreFields })
  });
  if (!res.ok) {
    return await restPatchFirestoreDoc(collectionPath, docId, fields, idToken);
  }
  return await res.json();
}

// Memory lock for active purchase requests to enforce idempotency
const activeBuyLocks = new Map<string, number>();

export interface VerifiedAuthUser {
  uid: string;
  email: string;
  isAdmin: boolean;
}

/**
 * Cryptographically parses and verifies the Firebase ID token claims (expiry, issuer, audience, subject)
 * and resolves genuine authentication status.
 */
const getVerifiedAuthUser = async (authHeader: string | undefined): Promise<VerifiedAuthUser | null> => {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.substring(7);
  const parts = token.split('.');
  if (parts.length !== 3) {
    return null;
  }
  try {
    const payloadJson = Buffer.from(parts[1], 'base64').toString('utf8');
    const payload = JSON.parse(payloadJson);

    const nowSecs = Math.floor(Date.now() / 1000);
    if (payload.exp && payload.exp < nowSecs) {
      console.warn('[Auth] Expired Firebase ID token received');
      return null;
    }

    if (firebaseProjectId) {
      const expectedIssuer = `https://securetoken.google.com/${firebaseProjectId}`;
      if (payload.iss !== expectedIssuer) {
        console.warn(`[Auth] Issuer mismatch: ${payload.iss} vs ${expectedIssuer}`);
        return null;
      }
      if (payload.aud !== firebaseProjectId) {
        console.warn(`[Auth] Audience mismatch: ${payload.aud} vs ${firebaseProjectId}`);
        return null;
      }
    }

    const uid = payload.sub || payload.user_id;
    if (!uid) return null;

    const email = (payload.email || '').trim().toLowerCase();
    let isAdmin = isAuthorizedOwnerEmail(email) || isAuthorizedOwnerUid(uid);

    // Verify role in Firestore database if available
    if (!isAdmin && db) {
      try {
        const userDoc = await getDoc(doc(db, 'users', uid));
        if (userDoc.exists()) {
          const udata = userDoc.data();
          if (isAuthorizedOwnerEmail(udata.email) || isAuthorizedOwnerUid(udata.uid) || udata.role === 'admin' || udata.role === 'owner') {
            isAdmin = true;
          }
        }
      } catch {}
    }

    return { uid, email, isAdmin };
  } catch (err) {
    console.error('[Auth] Error decoding ID Token:', err);
    return null;
  }
};

/**
 * Parses and verifies the Firebase ID token claims (expiry, issuer, audience, subject)
 * directly without requiring the external firebase-admin SDK.
 */
const verifyFirebaseIdToken = (authHeader: string | undefined, projectId: string): string | null => {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.substring(7);
  const parts = token.split('.');
  if (parts.length !== 3) {
    return null;
  }
  try {
    const payloadJson = Buffer.from(parts[1], 'base64').toString('utf8');
    const payload = JSON.parse(payloadJson);
    
    const nowSecs = Math.floor(Date.now() / 1000);
    if (payload.exp && payload.exp < nowSecs) {
      console.warn('[Auth] Expired Firebase ID token received');
      return null;
    }
    
    if (projectId) {
      const expectedIssuer = `https://securetoken.google.com/${projectId}`;
      if (payload.iss !== expectedIssuer) {
        console.warn(`[Auth] Issuer mismatch: ${payload.iss} vs ${expectedIssuer}`);
        return null;
      }
      if (payload.aud !== projectId) {
        console.warn(`[Auth] Audience mismatch: ${payload.aud} vs ${projectId}`);
        return null;
      }
    }
    
    return payload.sub || payload.user_id || null; // Returns user UID
  } catch (err) {
    console.error('[Auth] Error decoding ID Token:', err);
    return null;
  }
};

// Helper to resolve Paystack credentials safely from process.env
const getPaystackSecretKey = (): string => {
  const rawKey = process.env.PAYSTACK_SECRET_KEY || process.env.PAYSTACK_SECRET || process.env.PAYSTACK_KEY || '';
  if (!rawKey) return '';
  return rawKey.trim().replace(/^['"`]|['"`]$/g, '').trim();
};

const getPaystackPublicKey = (secretKey: string): string => {
  const rawPub = process.env.VITE_PAYSTACK_PUBLIC_KEY || process.env.PAYSTACK_PUBLIC_KEY || '';
  let pub = rawPub ? rawPub.trim().replace(/^['"`]|['"`]$/g, '').trim() : '';
  if (!pub && secretKey) {
    if (secretKey.startsWith('sk_live_')) {
      pub = secretKey.replace('sk_live_', 'pk_live_');
    } else if (secretKey.startsWith('sk_test_')) {
      pub = secretKey.replace('sk_test_', 'pk_test_');
    } else if (secretKey.startsWith('sk_')) {
      pub = secretKey.replace(/^sk_/, 'pk_');
    }
  }
  return pub;
};

// 1. Paystack Live API Routes
app.post('/api/paystack/initialize', async (req, res) => {
  try {
    const { listingId, listingTitle, priceNaira, buyerEmail, currency, callbackUrl, userId, isWalletFunding } = req.body;

    if (!priceNaira || !buyerEmail) {
      return res.status(400).json({ error: 'Price and buyer email are required' });
    }

    const paystackSecretKey = getPaystackSecretKey();
    const paystackPublicKey = getPaystackPublicKey(paystackSecretKey);

    if (!paystackSecretKey || !paystackSecretKey.startsWith('sk_')) {
      return res.status(500).json({ 
        success: false,
        error: 'Paystack Secret Key (PAYSTACK_SECRET_KEY) is missing on the server environment. Please set PAYSTACK_SECRET_KEY.' 
      });
    }

    const reference = `PST_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
    const amountInKobo = Math.round(Number(priceNaira) * 100);

    const isLogProduct = Boolean(listingId && listingId !== 'WALLET_FUNDING' && !isWalletFunding);
    const orderId = req.body.orderId || (isLogProduct ? `ORD_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}` : undefined);

    if (db && isLogProduct && orderId) {
      try {
        await ensureServerAuthenticated();
        await setDoc(doc(db, 'orders', orderId), {
          id: orderId,
          orderId: orderId,
          type: 'log_account',
          userId: userId || '',
          buyerEmail: buyerEmail || '',
          listingId: listingId,
          listingTitle: listingTitle || 'Log Account',
          amount: Number(priceNaira),
          currency: currency || 'NGN',
          paymentGateway: 'paystack',
          paystackReference: reference,
          status: 'pending',
          paymentStatus: 'pending',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }, { merge: true });
      } catch (ordErr) {
        console.warn('Initial order creation notice:', ordErr);
      }
    }

    const paystackRes = await fetch('https://api.paystack.co/transaction/initialize', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${paystackSecretKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email: buyerEmail,
        amount: amountInKobo,
        currency: currency || 'NGN',
        reference: reference,
        callback_url: callbackUrl,
        metadata: {
          orderId: orderId || '',
          userId: userId || '',
          isWalletFunding: Boolean(isWalletFunding),
          expectedAmountNaira: Number(priceNaira),
          expectedAmountKobo: amountInKobo,
          listingId: listingId || 'WALLET_FUNDING',
          listingTitle: listingTitle || 'Wallet Funding Deposit',
          buyerEmail
        }
      })
    });

    const paystackData: any = await paystackRes.json();

    if (paystackData.status && paystackData.data) {
      return res.json({
        success: true,
        authorization_url: paystackData.data.authorization_url,
        access_code: paystackData.data.access_code,
        reference: paystackData.data.reference,
        orderId: orderId || '',
        publicKey: paystackPublicKey || '',
        mode: 'live_paystack'
      });
    } else {
      console.error('[Paystack Initialize API Error]', paystackData);
      return res.status(400).json({
        success: false,
        error: paystackData.message || 'Paystack checkout session initialization failed.'
      });
    }

  } catch (err: any) {
    console.error('Error in /api/paystack/initialize:', err);
    res.status(500).json({ error: err.message || 'Paystack initialization failed' });
  }
});

/**
 * Universal Unique Transaction ID Generator
 * Enforces category separation:
 * - Withdrawals: ZN-WTH-TXN-...
 * - Purchases: ZN-PUR-TXN-...
 * - Social Boosts: ZN-BST-TXN-...
 * - Zenet Updates: ZN-UPD-TXN-...
 * - Wallet Top-ups: ZN-TOP-TXN-...
 */
export function generateUniqueTransactionId(category: 'withdrawal' | 'purchase' | 'log' | 'boost' | 'social_boost' | 'update' | 'virtual_number' | 'topup' | 'deposit' | string = 'purchase'): string {
  const now = new Date();
  const dateStr = now.toISOString().split('T')[0].replace(/-/g, '').slice(0, 6);
  const timeBase36 = now.getTime().toString(36).toUpperCase();
  const rand = crypto.randomBytes(4).toString('hex').toUpperCase();

  switch (category) {
    case 'withdrawal':
      return `ZN-WTH-TXN-${dateStr}-${timeBase36}-${rand}`;
    case 'purchase':
    case 'log':
      return `ZN-LOG-TXN-${dateStr}-${timeBase36}-${rand}`;
    case 'boost':
    case 'social_boost':
      return `ZN-BST-TXN-${dateStr}-${timeBase36}-${rand}`;
    case 'update':
    case 'virtual_number':
      return `ZN-UPD-TXN-${dateStr}-${timeBase36}-${rand}`;
    case 'topup':
    case 'deposit':
      return `ZN-DEP-TXN-${dateStr}-${timeBase36}-${rand}`;
    default:
      return `ZN-TXN-${dateStr}-${timeBase36}-${rand}`;
  }
}

// In-memory cache for Paystack supported banks
let cachedPaystackBanks: any[] | null = null;
let lastBanksFetchTime = 0;

// 1. Fetch Verified Banks List via connected Paystack API
app.get('/api/paystack/banks', async (req, res) => {
  try {
    const now = Date.now();
    // Cache for 1 hour
    if (cachedPaystackBanks && cachedPaystackBanks.length > 0 && now - lastBanksFetchTime < 3600000) {
      return res.json({ success: true, banks: cachedPaystackBanks });
    }

    const paystackSecretKey = getPaystackSecretKey();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json'
    };
    if (paystackSecretKey) {
      headers['Authorization'] = `Bearer ${paystackSecretKey}`;
    }

    const resp = await fetch('https://api.paystack.co/bank?country=nigeria&currency=NGN&perPage=100', {
      headers
    });
    const data: any = await resp.json();

    if (data && data.status && Array.isArray(data.data)) {
      cachedPaystackBanks = data.data
        .filter((b: any) => b.active !== false)
        .map((b: any) => ({
          id: b.id,
          name: b.name,
          code: b.code,
          slug: b.slug
        }));
      lastBanksFetchTime = now;
      return res.json({ success: true, banks: cachedPaystackBanks });
    }

    // Fallback if paystack returns rate-limit or network issue
    return res.json({
      success: true,
      banks: [
        { id: 1, name: 'OPay (PayCom)', code: '999992', slug: 'paycom' },
        { id: 2, name: 'PalmPay', code: '999991', slug: 'palmpay' },
        { id: 3, name: 'Moniepoint MFB', code: '50515', slug: 'moniepoint-mfb' },
        { id: 4, name: 'Kuda Bank', code: '50211', slug: 'kuda-bank' },
        { id: 5, name: 'Access Bank', code: '044', slug: 'access-bank' },
        { id: 6, name: 'GTBank (Guaranty Trust Bank)', code: '058', slug: 'guaranty-trust-bank' },
        { id: 7, name: 'Zenith Bank', code: '057', slug: 'zenith-bank' },
        { id: 8, name: 'United Bank for Africa (UBA)', code: '033', slug: 'united-bank-for-africa' },
        { id: 9, name: 'First Bank of Nigeria', code: '011', slug: 'first-bank-of-nigeria' },
        { id: 10, name: 'Fidelity Bank', code: '070', slug: 'fidelity-bank' },
        { id: 11, name: 'Stanbic IBTC Bank', code: '221', slug: 'stanbic-ibtc-bank' },
        { id: 12, name: 'Union Bank of Nigeria', code: '032', slug: 'union-bank-of-nigeria' },
        { id: 13, name: 'Sterling Bank', code: '232', slug: 'sterling-bank' },
        { id: 14, name: 'Wema Bank / ALAT', code: '035', slug: 'wema-bank' }
      ]
    });
  } catch (err: any) {
    console.error('Error in /api/paystack/banks:', err);
    return res.status(500).json({ success: false, error: err.message || 'Error fetching Paystack banks' });
  }
});

// 2. Resolve & Verify Bank Account Details using connected Paystack API
app.get('/api/paystack/resolve-account', async (req, res) => {
  try {
    const { account_number, bank_code } = req.query;
    if (!account_number || !bank_code) {
      return res.status(400).json({ success: false, error: 'Account number and bank code are required.' });
    }

    const paystackSecretKey = getPaystackSecretKey();
    if (!paystackSecretKey) {
      return res.status(500).json({ success: false, error: 'Paystack secret key is not configured.' });
    }

    const cleanAcc = String(account_number).trim().replace(/\D/g, '');
    const cleanCode = String(bank_code).trim();

    if (cleanAcc.length !== 10) {
      return res.status(400).json({ success: false, error: 'Account number must be exactly 10 digits.' });
    }

    const url = `https://api.paystack.co/bank/resolve?account_number=${encodeURIComponent(cleanAcc)}&bank_code=${encodeURIComponent(cleanCode)}`;
    const resp = await fetch(url, {
      headers: {
        Authorization: `Bearer ${paystackSecretKey}`,
        'Content-Type': 'application/json'
      }
    });

    const data: any = await resp.json();
    if (data && data.status && data.data && data.data.account_name) {
      return res.json({
        success: true,
        account_name: data.data.account_name,
        account_number: data.data.account_number,
        bank_id: data.data.bank_id
      });
    }

    return res.status(400).json({
      success: false,
      error: data?.message || 'Could not verify account name with Paystack. Please check the account number and bank.'
    });
  } catch (err: any) {
    console.error('Error in /api/paystack/resolve-account:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to verify account details with Paystack.' });
  }
});

/**
 * Permanently calculates and saves the 70% Seller / 30% Owner split in Firestore
 * Updates seller_revenues/{sellerId} and users/{sellerId}
 */
const recordSellerRevenueSplit = async (purchaseRecord: any) => {
  if (!purchaseRecord || !purchaseRecord.sellerId || !db) return;
  try {
    const targetSellerId = purchaseRecord.sellerId;
    const grossAmount = Number(purchaseRecord.paidAmount || purchaseRecord.price || 0);
    const sellerShare = purchaseRecord.sellerShare !== undefined
      ? Number(purchaseRecord.sellerShare)
      : Math.round(grossAmount * 0.70);
    const ownerShare = purchaseRecord.ownerShare !== undefined
      ? Number(purchaseRecord.ownerShare)
      : (grossAmount - sellerShare);

    const revDocRef = doc(db, 'seller_revenues', targetSellerId);
    const revSnap = await getDoc(revDocRef);
    const currentData = revSnap.exists() ? revSnap.data() : {};
    const prevGross = Number(currentData.totalGrossSales) || 0;
    const prevSellerRev = Number(currentData.totalSellerRevenue) || 0;
    const prevOwnerComm = Number(currentData.totalOwnerCommission) || 0;
    const prevCount = Number(currentData.completedSalesCount) || 0;
    const existingSales = Array.isArray(currentData.sales) ? currentData.sales : [];

    const saleEntry = {
      orderId: purchaseRecord.id || purchaseRecord.orderId || `ORD_${Date.now()}`,
      txId: purchaseRecord.transactionId || purchaseRecord.paystackReference || purchaseRecord.id,
      listingId: purchaseRecord.listingId || '',
      listingTitle: purchaseRecord.listingTitle || 'Account Listing',
      grossAmount,
      sellerShare,
      ownerShare,
      sellerPercent: 70,
      ownerPercent: 30,
      buyerId: purchaseRecord.buyerId || '',
      buyerEmail: purchaseRecord.buyerEmail || '',
      paymentGateway: purchaseRecord.paymentGateway || 'escrow',
      date: purchaseRecord.purchasedAt || new Date().toISOString()
    };

    await setDoc(revDocRef, {
      sellerId: targetSellerId,
      sellerEmail: purchaseRecord.sellerEmail || '',
      totalGrossSales: prevGross + grossAmount,
      totalSellerRevenue: prevSellerRev + sellerShare,
      totalOwnerCommission: prevOwnerComm + ownerShare,
      completedSalesCount: prevCount + 1,
      lastSaleAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      sales: [saleEntry, ...existingSales.filter(s => s.orderId !== saleEntry.orderId).slice(0, 99)]
    }, { merge: true });

    const sellerUserRef = doc(db, 'users', targetSellerId);
    const sUserSnap = await getDoc(sellerUserRef);
    if (sUserSnap.exists()) {
      const sUserData = sUserSnap.data();
      await updateDoc(sellerUserRef, {
        sellerTotalRevenue: (Number(sUserData.sellerTotalRevenue) || 0) + sellerShare,
        sellerGrossSales: (Number(sUserData.sellerGrossSales) || 0) + grossAmount,
        sellerOwnerFee: (Number(sUserData.sellerOwnerFee) || 0) + ownerShare,
        sellerCompletedSales: (Number(sUserData.sellerCompletedSales) || 0) + 1,
        updatedAt: new Date().toISOString()
      });
    }
  } catch (err: any) {
    console.warn('[recordSellerRevenueSplit notice]:', err?.message || err);
  }
};

// Dedicated server-authoritative LOG order fulfillment function with duplicate prevention
const fulfillLogOrderAndDeliver = async ({
  orderId,
  reference,
  listingId,
  userId,
  buyerEmail,
  buyerName,
  paidAmount,
  paymentGateway = 'paystack'
}: {
  orderId?: string;
  reference: string;
  listingId: string;
  userId: string;
  buyerEmail?: string;
  buyerName?: string;
  paidAmount: number;
  paymentGateway?: string;
}): Promise<{
  success: boolean;
  delivered: boolean;
  status: string;
  alreadyDelivered?: boolean;
  purchaseRecord?: any;
  error?: string;
}> => {
  if (!db) {
    return { success: false, delivered: false, status: 'error', error: 'Database service unavailable' };
  }

  await ensureServerAuthenticated();

  // 1. DUPLICATE DELIVERY PREVENTION (Idempotency)
  // Check if a purchase already exists for this reference or orderId
  try {
    const pRefQ = query(collection(db, 'purchases'), where('transactionId', '==', reference));
    const pRefSnap = await getDocs(pRefQ);
    if (!pRefSnap.empty) {
      const existing = { id: pRefSnap.docs[0].id, ...pRefSnap.docs[0].data() };
      console.log(`[LOG Fulfillment] Already delivered for ref ${reference} (Purchase ID: ${existing.id}). Preventing duplicate delivery.`);
      return {
        success: true,
        delivered: true,
        alreadyDelivered: true,
        status: 'completed',
        purchaseRecord: existing
      };
    }

    if (orderId) {
      const ordSnap = await getDoc(doc(db, 'orders', orderId));
      if (ordSnap.exists()) {
        const ordData = ordSnap.data();
        if (ordData.status === 'completed' && ordData.purchaseId) {
          const pSnap = await getDoc(doc(db, 'purchases', ordData.purchaseId));
          if (pSnap.exists()) {
            return {
              success: true,
              delivered: true,
              alreadyDelivered: true,
              status: 'completed',
              purchaseRecord: { id: pSnap.id, ...pSnap.data() }
            };
          }
        }
      }
    }
  } catch (dupErr) {
    console.warn('[LOG Fulfillment] Idempotency pre-check warning:', dupErr);
  }

  const effectiveOrderId = orderId || `ORD_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

  // 2. Fetch live listing & subcollection
  const listingDocRef = doc(db, 'listings', listingId);
  const listingSnap = await getDoc(listingDocRef);
  if (!listingSnap.exists()) {
    try {
      await setDoc(doc(db, 'orders', effectiveOrderId), {
        id: effectiveOrderId,
        status: 'failed',
        paymentStatus: 'success',
        error: 'Listing does not exist in marketplace inventory',
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch {}
    return {
      success: false,
      delivered: false,
      status: 'failed',
      error: 'The purchased listing was not found in the marketplace catalog.'
    };
  }

  const listingData = listingSnap.data();

  // Check inventory subcollection pre-fetch
  const invColRef = collection(db, 'listings', listingId, 'inventory');
  let invSnap: any = null;
  try {
    invSnap = await getDocs(invColRef);
  } catch (invErr) {
    console.warn('[LOG Fulfillment] Inventory subcollection fetch notice:', invErr);
  }
  const hasInventorySubcollection = invSnap && !invSnap.empty;

  let purchaseResult: any = null;
  let fulfillmentError: string | null = null;

  try {
    await runTransaction(db, async (t) => {
      // Re-check live user
      const userDocRef = doc(db, 'users', userId);
      const userSnap = await t.get(userDocRef);
      const userData = userSnap.exists() ? userSnap.data() : {};

      // Re-check live listing inside transaction
      const liveListingSnap = await t.get(listingDocRef);
      if (!liveListingSnap.exists()) {
        throw new Error('Listing does not exist.');
      }
      const liveListingData = liveListingSnap.data();

      // Check stock
      const hasInvArr = Array.isArray(liveListingData.inventory);
      const availableCount = hasInvArr ? liveListingData.inventory.filter((acc: any) => (acc.status || '').toLowerCase() !== 'sold').length : undefined;
      const explicitStock = liveListingData.stockCount !== undefined ? liveListingData.stockCount : (liveListingData.stock !== undefined ? liveListingData.stock : 1);
      const isSold = liveListingData.status === 'sold' || (availableCount !== undefined ? availableCount <= 0 : explicitStock <= 0);

      const isOwnerOrSeller = userId === liveListingData.sellerId || 
        isAuthorizedOwnerUid(userId) ||
        (userData.email && (isAuthorizedOwnerEmail(userData.email) || userData.role === 'owner'));

      if (isSold && !isOwnerOrSeller) {
        throw new Error('OUT_OF_STOCK');
      }

      const purchaseId = `pur_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
      const transferCode = `ZENET-ESCROW-${Math.floor(1000 + Math.random() * 9000)}-PST`;

      let secureDetails: any = null;
      let remainingStock = 0;

      // Extract credentials from subcollection OR array OR digitalProductDetails
      if (hasInventorySubcollection && invSnap) {
        let targetDocSnap = null;
        let targetDocId = null;
        let liveAvailCount = 0;

        for (const d of invSnap.docs) {
          const liveItemRef = doc(db, 'listings', listingId, 'inventory', d.id);
          const liveItemSnap = await t.get(liveItemRef);
          if (liveItemSnap.exists()) {
            const itemData = liveItemSnap.data();
            const itemStatus = (itemData.status || '').toLowerCase();
            if (itemStatus === 'available') {
              liveAvailCount++;
              if (!targetDocSnap) {
                targetDocSnap = liveItemSnap;
                targetDocId = d.id;
              }
            }
          }
        }

        if (!targetDocSnap || !targetDocId) {
          if (isOwnerOrSeller && invSnap.docs.length > 0) {
            targetDocSnap = invSnap.docs[0];
            targetDocId = invSnap.docs[0].id;
          } else {
            t.update(listingDocRef, { status: 'sold', stock: 0, stockCount: 0 });
            throw new Error('OUT_OF_STOCK');
          }
        }

        // Read secure details subcollection
        const secureRef = doc(db, 'listings', listingId, 'inventory', targetDocId, 'secure', 'details');
        const liveSecureSnap = await t.get(secureRef);
        let secData: any = liveSecureSnap.exists() ? liveSecureSnap.data() : targetDocSnap.data();

        const rawSec = {
          ...(targetDocSnap.data() || {}),
          ...(liveSecureSnap.exists() ? liveSecureSnap.data() : {})
        };
        delete rawSec.status;
        delete rawSec.soldTo;
        delete rawSec.soldToEmail;
        delete rawSec.soldAt;
        delete rawSec.orderId;

        secureDetails = {
          ...rawSec,
          inventoryId: targetDocId,
          accountEmail: rawSec.accountEmail || rawSec.email || '',
          accountPassword: rawSec.accountPassword || rawSec.password || '',
          recoveryInfo: rawSec.recoveryInfo || rawSec.notes || '',
          backupCodes: rawSec.backupCodes || rawSec.twoFactorBackupCodes || rawSec.twoFactorSecretKey || '',
          twoFactorSecretKey: rawSec.twoFactorSecretKey || rawSec.twoFactorSecret || rawSec.twoFactor || rawSec['2fa'] || '',
          twoFactorBackupCodes: rawSec.twoFactorBackupCodes || rawSec.backupCodes || '',
          additionalInstructions: rawSec.additionalInstructions || rawSec.instructions || ''
        };

        remainingStock = Math.max(0, liveAvailCount - 1);

        // a. Mark exact inventory item as SOLD to this buyer
        t.update(targetDocSnap.ref, {
          status: 'Sold',
          soldTo: userId,
          soldToEmail: buyerEmail || userData.email || '',
          orderId: effectiveOrderId,
          soldAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });

        // b. Update inventory array on listing doc
        let updatedInventoryArray = liveListingData.inventory;
        if (Array.isArray(updatedInventoryArray)) {
          updatedInventoryArray = updatedInventoryArray.map((invItem: any) => {
            if (invItem.id === targetDocId) {
              return {
                ...invItem,
                status: 'Sold',
                soldTo: userId,
                soldToEmail: buyerEmail || userData.email || '',
                orderId: effectiveOrderId,
                soldAt: new Date().toISOString()
              };
            }
            return invItem;
          });
        }

        t.update(listingDocRef, {
          stock: remainingStock,
          stockCount: remainingStock,
          status: remainingStock > 0 ? 'active' : 'sold',
          ...(updatedInventoryArray ? { inventory: updatedInventoryArray } : {})
        });

      } else if (Array.isArray(liveListingData.inventory) && liveListingData.inventory.length > 0) {
        let availableIdx = liveListingData.inventory.findIndex((acc: any) => (acc.status || '').toLowerCase() === 'available');
        if (availableIdx === -1) {
          if (isOwnerOrSeller && liveListingData.inventory.length > 0) {
            availableIdx = 0;
          } else {
            t.update(listingDocRef, { status: 'sold', stock: 0, stockCount: 0 });
            throw new Error('OUT_OF_STOCK');
          }
        }

        const targetAcc = liveListingData.inventory[availableIdx];
        const rawTarget = { ...(targetAcc || {}) };
        delete rawTarget.status;
        delete rawTarget.soldTo;
        delete rawTarget.soldToEmail;
        delete rawTarget.soldAt;
        delete rawTarget.orderId;

        secureDetails = {
          ...rawTarget,
          inventoryId: targetAcc.id || `inv_${availableIdx + 1}`,
          accountEmail: rawTarget.accountEmail || rawTarget.email || '',
          accountPassword: rawTarget.accountPassword || rawTarget.password || '',
          recoveryInfo: rawTarget.recoveryInfo || rawTarget.notes || '',
          backupCodes: rawTarget.backupCodes || rawTarget.twoFactorBackupCodes || rawTarget.twoFactorSecretKey || '',
          twoFactorSecretKey: rawTarget.twoFactorSecretKey || rawTarget.twoFactorSecret || rawTarget.twoFactor || rawTarget['2fa'] || '',
          twoFactorBackupCodes: rawTarget.twoFactorBackupCodes || rawTarget.backupCodes || '',
          additionalInstructions: rawTarget.additionalInstructions || rawTarget.instructions || ''
        };

        const updatedInventory = [...liveListingData.inventory];
        updatedInventory[availableIdx] = {
          ...targetAcc,
          status: 'Sold',
          soldTo: userId,
          soldToEmail: buyerEmail || userData.email || '',
          orderId: effectiveOrderId,
          soldAt: new Date().toISOString()
        };

        const remainingAvailable = updatedInventory.filter((acc: any) => (acc.status || '').toLowerCase() === 'available').length;
        remainingStock = remainingAvailable;

        t.update(listingDocRef, {
          inventory: updatedInventory,
          stock: remainingAvailable,
          stockCount: remainingAvailable,
          status: remainingAvailable > 0 ? 'active' : 'sold'
        });

      } else {
        // Fallback for single-stock listing
        secureDetails = liveListingData.digitalProductDetails ? {
          ...liveListingData.digitalProductDetails,
          accountEmail: liveListingData.digitalProductDetails.accountEmail || liveListingData.digitalProductDetails.email || '',
          accountPassword: liveListingData.digitalProductDetails.accountPassword || liveListingData.digitalProductDetails.password || '',
          recoveryInfo: liveListingData.digitalProductDetails.recoveryInfo || liveListingData.digitalProductDetails.notes || '',
          backupCodes: liveListingData.digitalProductDetails.backupCodes || liveListingData.digitalProductDetails.twoFactorBackupCodes || '',
          twoFactorSecretKey: liveListingData.digitalProductDetails.twoFactorSecretKey || liveListingData.digitalProductDetails.twoFactorSecret || liveListingData.digitalProductDetails['2fa'] || '',
          twoFactorBackupCodes: liveListingData.digitalProductDetails.twoFactorBackupCodes || liveListingData.digitalProductDetails.backupCodes || '',
          additionalInstructions: liveListingData.digitalProductDetails.additionalInstructions || liveListingData.digitalProductDetails.instructions || ''
        } : undefined;

        remainingStock = 0;
        t.update(listingDocRef, { stock: 0, stockCount: 0, status: 'sold' });
      }

      // c. Construct purchase record
      const sellerShare = Math.round(paidAmount * 0.70);
      const ownerShare = paidAmount - sellerShare;

      const purchaseRecord = {
        id: purchaseId,
        orderId: effectiveOrderId,
        listingId: listingId,
        listingTitle: liveListingData.title,
        price: liveListingData.price,
        paidAmount: paidAmount,
        currency: 'NGN',
        type: 'log',
        category: liveListingData.category || 'Other',
        transactionCategory: 'log',
        sellerId: liveListingData.sellerId,
        sellerName: liveListingData.sellerName,
        sellerEmail: liveListingData.sellerEmail || '',
        buyerId: userId,
        buyerName: buyerName || userData.displayName || 'Buyer',
        buyerEmail: buyerEmail || userData.email || '',
        paymentGateway: paymentGateway,
        transactionId: reference,
        paystackReference: reference,
        purchasedAt: new Date().toISOString(),
        status: 'escrow_holding',
        transferCode: transferCode,
        imageUrl: liveListingData.imageUrl || '',
        digitalProductDetails: secureDetails,
        sellerShare,
        ownerShare,
        sellerPercent: 70,
        ownerPercent: 30,
        split: {
          grossAmount: paidAmount,
          sellerAmount: sellerShare,
          ownerAmount: ownerShare,
          sellerPercent: 70,
          ownerPercent: 30,
          calculatedAt: new Date().toISOString()
        }
      };

      // d. Create purchase record in purchases collection
      t.set(doc(db, 'purchases', purchaseId), purchaseRecord);

      // e. Create / update order in orders collection
      t.set(doc(db, 'orders', effectiveOrderId), {
        id: effectiveOrderId,
        orderId: effectiveOrderId,
        type: 'log_account',
        userId: userId,
        buyerEmail: buyerEmail || userData.email || '',
        buyerName: buyerName || userData.displayName || '',
        listingId: listingId,
        listingTitle: liveListingData.title,
        amount: paidAmount,
        currency: 'NGN',
        paymentGateway: paymentGateway,
        paystackReference: reference,
        status: 'completed',
        paymentStatus: 'success',
        purchaseId: purchaseId,
        deliveredAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }, { merge: true });

      // f. Create transaction record in wallet_transactions
      t.set(doc(db, 'wallet_transactions', reference), {
        id: reference,
        reference: reference,
        paystackReference: reference,
        orderId: effectiveOrderId,
        purchaseId: purchaseId,
        userId: userId,
        userEmail: buyerEmail || userData.email || '',
        amount: paidAmount,
        type: 'purchase',
        method: paymentGateway === 'wallet' ? 'wallet' : 'paystack_checkout',
        status: 'successful',
        description: `Purchased: ${liveListingData.title}`,
        date: new Date().toISOString().replace('T', ' ').slice(0, 16),
        createdAt: new Date().toISOString()
      });

      // g. Update user totalPurchasesAmount
      t.update(userDocRef, {
        totalPurchasesAmount: (userData.totalPurchasesAmount || 0) + paidAmount,
        updatedAt: new Date().toISOString()
      });

      purchaseResult = {
        purchaseRecord,
        remainingStock
      };
    });
  } catch (txErr: any) {
    console.error('[LOG Fulfillment] Transaction error:', txErr);
    fulfillmentError = txErr.message || 'Fulfillment error';
  }

  // Handle out of stock / failure:
  if (fulfillmentError || !purchaseResult) {
    const isOutOfStock = fulfillmentError === 'OUT_OF_STOCK' || (fulfillmentError && fulfillmentError.includes('OUT_OF_STOCK'));
    const errorMsg = isOutOfStock 
      ? 'The selected account is out of stock. Funds have been credited to your wallet balance for an immediate alternative purchase or refund.' 
      : (fulfillmentError || 'Fulfillment error encountered');

    try {
      const userRef = doc(db, 'users', userId);
      const uSnap = await getDoc(userRef);
      if (uSnap.exists()) {
        const uBal = Number(uSnap.data().walletBalance || uSnap.data().balance || 0) + paidAmount;
        await updateDoc(userRef, { walletBalance: uBal, balance: uBal });
        await setDoc(doc(db, 'wallets', userId), { walletBalance: uBal, balance: uBal, updatedAt: new Date().toISOString() }, { merge: true });
        await setDoc(doc(db, 'wallet_transactions', `${reference}_REFUND`), {
          id: `${reference}_REFUND`,
          reference: `${reference}_REFUND`,
          userId,
          amount: paidAmount,
          type: 'refund',
          method: 'paystack_out_of_stock_refund',
          status: 'successful',
          description: `Refund: Account out of stock (Ref: ${reference})`,
          date: new Date().toISOString().replace('T', ' ').slice(0, 16),
          createdAt: new Date().toISOString()
        });
      }

      await setDoc(doc(db, 'orders', effectiveOrderId), {
        id: effectiveOrderId,
        status: 'out_of_stock',
        paymentStatus: 'success',
        error: errorMsg,
        refundedToWallet: true,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (refErr) {
      console.error('[LOG Fulfillment] Failed to credit refund to wallet:', refErr);
    }

    return {
      success: false,
      delivered: false,
      status: isOutOfStock ? 'out_of_stock' : 'failed',
      error: errorMsg
    };
  }

  // Notify seller asynchronously via inquiries
  try {
    if (purchaseResult.purchaseRecord && purchaseResult.purchaseRecord.sellerId) {
      const inqRef = doc(collection(db, 'inquiries'));
      await setDoc(inqRef, {
        id: inqRef.id,
        listingId: listingId,
        listingTitle: purchaseResult.purchaseRecord.listingTitle,
        buyerId: userId,
        buyerEmail: buyerEmail,
        buyerName: buyerName,
        sellerId: purchaseResult.purchaseRecord.sellerId,
        message: `🎉 ORDER CONFIRMED: Account "${purchaseResult.purchaseRecord.listingTitle}" was purchased for ₦${purchaseResult.purchaseRecord.paidAmount.toLocaleString()} via Paystack! Escrow Token: ${purchaseResult.purchaseRecord.transferCode}.`,
        createdAt: new Date().toISOString(),
        status: 'unread'
      });
    }
  } catch (inqErr) {
    console.warn('[LOG Fulfillment] Seller inquiry notification notice:', inqErr);
  }

  // Record 70% Seller / 30% Owner split permanently in database
  if (purchaseResult?.purchaseRecord) {
    await recordSellerRevenueSplit(purchaseResult.purchaseRecord);
  }

  return {
    success: true,
    delivered: true,
    status: 'completed',
    purchaseRecord: purchaseResult.purchaseRecord
  };
};

// Unified, robust transaction verification and database crediting logic
const verifyAndCreditTransaction = async (
  reference: string,
  clientUserId?: string,
  webhookData?: any
): Promise<any> => {
  const paystackSecretKey = getPaystackSecretKey();
  if (!paystackSecretKey || !paystackSecretKey.startsWith('sk_')) {
    return {
      verified: false,
      status: 'failed',
      error: 'PAYSTACK_SECRET_KEY is not configured on the server environment.'
    };
  }

  let finalBalance: number | undefined;

  // 1. First quick idempotency check from Firestore
  if (db) {
    try {
      // First check if purchase is already delivered for this reference
      const pRefQ = query(collection(db, 'purchases'), where('transactionId', '==', reference));
      const pRefSnap = await getDocs(pRefQ);
      if (!pRefSnap.empty) {
        const existingPurchase = { id: pRefSnap.docs[0].id, ...pRefSnap.docs[0].data() };
        console.log(`[Paystack Verify] Reference ${reference} already delivered as Purchase ${existingPurchase.id}. (Idempotency Protect)`);
        return {
          verified: true,
          alreadyProcessed: true,
          status: 'success',
          delivered: true,
          orderStatus: 'completed',
          purchaseRecord: existingPurchase,
          reference,
          amount: (existingPurchase as any).paidAmount || (existingPurchase as any).price || 0,
          currency: 'NGN',
          paidAt: (existingPurchase as any).purchasedAt,
          buyerEmail: (existingPurchase as any).buyerEmail,
          userId: (existingPurchase as any).buyerId,
          gateway: 'paystack'
        };
      }

      const txDocRef = doc(db, 'wallet_transactions', reference);
      const txSnap = await getDoc(txDocRef);

      if (txSnap.exists()) {
        const txData = txSnap.data();
        if (txData.status === 'successful' || txData.status === 'completed') {
          console.log(`[Paystack Verify] Reference ${reference} already processed in wallet_transactions (Idempotency Protect).`);
          let latestBal = txData.newBalance ?? txData.walletBalance ?? txData.balance;
          if ((typeof latestBal !== 'number' || isNaN(latestBal)) && txData.userId) {
            try {
              const uSnap = await getDoc(doc(db, 'users', String(txData.userId)));
              if (uSnap.exists()) {
                const uData = uSnap.data();
                const numU = Number(uData.walletBalance ?? uData.balance);
                if (!isNaN(numU)) latestBal = numU;
              }
            } catch {}
          }
          return {
            verified: true,
            alreadyProcessed: true,
            status: 'success',
            delivered: false,
            reference,
            amount: txData.amount,
            newBalance: typeof latestBal === 'number' && !isNaN(latestBal) ? latestBal : txData.amount,
            currency: 'NGN',
            paidAt: txData.date || txData.createdAt,
            buyerEmail: txData.userEmail,
            userId: txData.userId,
            gateway: 'paystack'
          };
        }
      }
    } catch (dbErr) {
      console.warn('[Paystack Verify] Idempotency read check warning:', dbErr);
    }
  }

  // 2. Query Paystack Transaction Status API or use authenticated webhook data
  let pstData = webhookData;
  if (!pstData || !pstData.status || pstData.status !== 'success') {
    try {
      const paystackRes = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${paystackSecretKey}`,
          'Content-Type': 'application/json'
        }
      });

      const paystackData: any = await paystackRes.json();

      if (!paystackData.status || !paystackData.data || paystackData.data.status !== 'success') {
        return {
          verified: false,
          status: paystackData.data?.status || 'failed',
          error: paystackData.message || 'Payment verification failed on Paystack.'
        };
      }
      pstData = paystackData.data;
    } catch (fetchErr: any) {
      if (!pstData) {
        return {
          verified: false,
          status: 'error',
          error: `Paystack API network error: ${fetchErr.message}`
        };
      }
    }
  }

  const paidAmountKobo = pstData.amount;
  const amountNaira = paidAmountKobo / 100;
  const customerEmail = (pstData.customer?.email || '').trim();
  const customerCode = pstData.customer?.customer_code;
  const accountNumber = String(
    pstData.authorization?.account_number || 
    pstData.dedicated_account?.account_number || 
    pstData.authorization?.receiver_bank_account_number ||
    pstData.receiver_bank_account_number ||
    ''
  ).trim();

  // Safe parsing of metadata
  let metadataObj: any = {};
  if (pstData.metadata) {
    if (typeof pstData.metadata === 'string') {
      try {
        metadataObj = JSON.parse(pstData.metadata);
      } catch (e) {
        console.warn('[Paystack Verify] Metadata parse warning:', e);
      }
    } else {
      metadataObj = pstData.metadata;
    }
  }

  // Extract userId from metadata or custom_fields
  let extractedUserId = metadataObj.userId || clientUserId || null;
  if (!extractedUserId && Array.isArray(metadataObj.custom_fields)) {
    const uField = metadataObj.custom_fields.find((f: any) => f.variable_name === 'user_id' || f.variable_name === 'userId');
    if (uField && uField.value) {
      extractedUserId = String(uField.value);
    }
  }

  // 3. Verify paid amount matching (Minimum expected amount check)
  const expectedAmountNaira = metadataObj.expectedAmountNaira || metadataObj.priceNaira;
  if (expectedAmountNaira && Number(expectedAmountNaira) > 0) {
    const expectedKobo = Math.round(Number(expectedAmountNaira) * 100);
    if (paidAmountKobo < expectedKobo) {
      console.error(`[Paystack Verify] Amount mismatch for ref ${reference}: Paid ₦${amountNaira}, expected ₦${expectedAmountNaira}`);
      return {
        verified: false,
        status: 'amount_mismatch',
        error: `Payment amount mismatch: Paid ₦${amountNaira} but expected ₦${expectedAmountNaira}`
      };
    }
  }

  // 4. Multi-channel user resolution
  let targetUid = extractedUserId;

  if (db) {
    try {
      await ensureServerAuthenticated();
      // Find the user by Email if not resolved directly
      if (!targetUid && customerEmail) {
        const cleanEmail = customerEmail.toLowerCase();
        let usersQ = query(collection(db, 'users'), where('email', '==', cleanEmail));
        let usersSnap = await getDocs(usersQ);

        // Fallback: check original casing
        if (usersSnap.empty) {
          usersQ = query(collection(db, 'users'), where('email', '==', customerEmail));
          usersSnap = await getDocs(usersQ);
        }

        // Fallback: scan all users
        if (usersSnap.empty) {
          const allUsersSnap = await getDocs(collection(db, 'users'));
          const found = allUsersSnap.docs.find(d => {
            const uData = d.data();
            return (uData.email && uData.email.trim().toLowerCase() === cleanEmail);
          });
          if (found) {
            targetUid = found.id;
          }
        } else {
          targetUid = usersSnap.docs[0].id;
        }
      }

      // Find the user by Customer Code if available
      if (!targetUid && customerCode) {
        const custCodeQ = query(collection(db, 'users'), where('paystackCustomerCode', '==', customerCode));
        const custCodeSnap = await getDocs(custCodeQ);
        if (!custCodeSnap.empty) {
          targetUid = custCodeSnap.docs[0].id;
        }
      }

      if (!targetUid) {
        console.warn(`[Paystack Verify] Unresolved user for verified transaction ${reference}. (Email: ${customerEmail})`);
        return {
          verified: false,
          status: 'user_not_found',
          error: 'Transaction verified on Paystack, but could not associate payment with any user profile.'
        };
      }

      // 5. Check if this transaction is for a specific LOG purchase:
      let isLogPurchase = Boolean(
        (metadataObj.listingId && metadataObj.listingId !== 'WALLET_FUNDING') ||
        metadataObj.type === 'log_purchase' ||
        (metadataObj.orderId && !metadataObj.isWalletFunding)
      );
      let targetListingId = (metadataObj.listingId && metadataObj.listingId !== 'WALLET_FUNDING') ? metadataObj.listingId : null;
      let targetOrderId = metadataObj.orderId || null;

      // Look up orders collection if needed
      if (!targetListingId || !targetOrderId) {
        try {
          const ordQ = query(collection(db, 'orders'), where('paystackReference', '==', reference));
          const ordSnap = await getDocs(ordQ);
          if (!ordSnap.empty) {
            const ordData = ordSnap.docs[0].data();
            if (ordData.listingId) {
              isLogPurchase = true;
              if (!targetListingId) targetListingId = ordData.listingId;
              if (!targetOrderId) targetOrderId = ordData.id;
              if (!targetUid && ordData.userId) targetUid = ordData.userId;
            }
          }
        } catch (ordErr) {
          console.warn('[Paystack Verify] Pending order lookup notice:', ordErr);
        }
      }

      if (isLogPurchase && targetListingId) {
        console.log(`[Paystack Verify] Executing LOG Order Fulfillment for Ref ${reference}, Listing ${targetListingId}, User ${targetUid}`);
        const fulfillment = await fulfillLogOrderAndDeliver({
          orderId: targetOrderId || undefined,
          reference,
          listingId: targetListingId,
          userId: String(targetUid),
          buyerEmail: customerEmail || metadataObj.buyerEmail,
          buyerName: metadataObj.buyerName,
          paidAmount: amountNaira,
          paymentGateway: 'paystack'
        });

        return {
          verified: true,
          status: 'success',
          delivered: fulfillment.delivered,
          orderStatus: fulfillment.status,
          purchaseRecord: fulfillment.purchaseRecord,
          reference: pstData.reference || reference,
          amount: amountNaira,
          currency: pstData.currency || 'NGN',
          paidAt: pstData.paid_at || pstData.paidAt,
          channel: pstData.channel,
          buyerEmail: customerEmail,
          userId: String(targetUid),
          gateway: 'paystack',
          error: fulfillment.error
        };
      }

      // Atomic execution using Firestore runTransaction to prevent double crediting under high concurrency
      finalBalance = 0;
      let alreadyCredited = false;

      await runTransaction(db, async (transaction) => {
        const txDocRef = doc(db, 'wallet_transactions', reference);
        const liveTxSnap = await transaction.get(txDocRef);

        const uDocRef = doc(db, 'users', String(targetUid));
        const walletDocRef = doc(db, 'wallets', String(targetUid));
        const uDocSnap = await transaction.get(uDocRef);
        const walletDocSnap = await transaction.get(walletDocRef);

        const uData = uDocSnap.exists() ? uDocSnap.data() : {};
        const walletData = walletDocSnap.exists() ? walletDocSnap.data() : {};
        const rawUBal = uData.walletBalance !== undefined ? uData.walletBalance : uData.balance;
        const numUBal = typeof rawUBal === 'number' ? rawUBal : (rawUBal ? Number(rawUBal) : 0);
        const rawWBal = walletData.walletBalance !== undefined ? walletData.walletBalance : walletData.balance;
        const numWBal = typeof rawWBal === 'number' ? rawWBal : (rawWBal ? Number(rawWBal) : 0);
        const currentBal = Math.max(isNaN(numUBal) ? 0 : numUBal, isNaN(numWBal) ? 0 : numWBal);

        if (liveTxSnap.exists()) {
          const liveData = liveTxSnap.data();
          if (liveData.status === 'successful' || liveData.status === 'completed') {
            alreadyCredited = true;
            finalBalance = Math.max(
              Number(liveData.newBalance ?? liveData.walletBalance ?? liveData.balance ?? 0) || 0,
              currentBal
            );
            return;
          }
        }

        finalBalance = currentBal + amountNaira;

        if (uDocSnap.exists()) {
          transaction.update(uDocRef, { 
            walletBalance: finalBalance,
            balance: finalBalance,
            updatedAt: new Date().toISOString()
          });
        } else {
          transaction.set(uDocRef, {
            uid: String(targetUid),
            walletBalance: finalBalance,
            balance: finalBalance,
            email: customerEmail || '',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          }, { merge: true });
        }

        transaction.set(walletDocRef, {
          userId: String(targetUid),
          userEmail: customerEmail || '',
          walletBalance: finalBalance,
          balance: finalBalance,
          updatedAt: new Date().toISOString()
        }, { merge: true });

        const isFunding = metadataObj.isWalletFunding !== false;
        transaction.set(txDocRef, {
          id: reference,
          reference: reference,
          transactionId: generateUniqueTransactionId('deposit'),
          userId: String(targetUid),
          userEmail: customerEmail || '',
          amount: amountNaira,
          previousBalance: currentBal,
          newBalance: finalBalance,
          walletBalance: finalBalance,
          balance: finalBalance,
          type: 'deposit',
          method: isFunding ? 'paystack_wallet_funding' : 'paystack_checkout',
          status: 'successful',
          paystackReference: reference,
          description: metadataObj.listingTitle || 'Paystack Wallet Deposit',
          date: new Date().toISOString().replace('T', ' ').slice(0, 16),
          createdAt: new Date().toISOString()
        });
      });

      if (alreadyCredited) {
        console.log(`[Paystack Verify] Transaction ${reference} was already credited in parallel transaction.`);
        return {
          verified: true,
          alreadyProcessed: true,
          status: 'success',
          reference,
          amount: amountNaira,
          newBalance: finalBalance,
          currency: 'NGN',
          paidAt: pstData.paid_at || pstData.paidAt,
          buyerEmail: customerEmail,
          userId: targetUid,
          gateway: 'paystack'
        };
      }

      console.log(`[Paystack Verify] Atomic Credit Complete: ₦${amountNaira} credited to User ${targetUid}. New Balance: ₦${finalBalance}`);

    } catch (creditErr) {
      console.error('[Paystack Verify] Firestore error during crediting:', creditErr);
      return {
        verified: false,
        status: 'db_error',
        error: 'Failed to update user wallet balance in database.'
      };
    }
  }

  return {
    verified: true,
    status: 'success',
    reference: pstData.reference || reference,
    amount: amountNaira,
    newBalance: finalBalance,
    currency: pstData.currency || 'NGN',
    paidAt: pstData.paid_at || pstData.paidAt,
    channel: pstData.channel,
    buyerEmail: customerEmail,
    userId: targetUid || undefined,
    gateway: 'paystack',
    raw: pstData
  };
};

// Secure Wallet Purchase Endpoint with Transaction Integrity & Multi-Stock Inventory Management
app.post('/api/wallet/purchase', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) {
      return res.status(401).json({ success: false, error: 'Authentication required: please log in to complete purchase.' });
    }

    const { userId, listingId, buyerEmail, buyerName } = req.body;
    if (!userId || !listingId) {
      return res.status(400).json({ success: false, error: 'User ID and Listing ID are required.' });
    }

    if (verifiedUser.uid !== userId && !verifiedUser.isAdmin) {
      return res.status(403).json({ success: false, error: 'Forbidden: You cannot initiate purchases for another user account.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database service is unavailable on the server.' });
    }

    // Ensure server-authoritative admin authentication is active
    await ensureServerAuthenticated();

    // Step 1: Pre-fetch inventory subcollection docs (if any)
    const invColRef = collection(db, 'listings', listingId, 'inventory');
    let invSnap = null;
    try {
      invSnap = await getDocs(invColRef);
    } catch (invErr) {
      console.warn('Inventory subcollection fetch notice:', invErr);
    }
    const hasInventorySubcollection = invSnap && !invSnap.empty;

    let purchaseResult: any = null;

    await runTransaction(db, async (t) => {
      // 1. Fetch live user
      const userDocRef = doc(db, 'users', userId);
      const userSnap = await t.get(userDocRef);
      if (!userSnap.exists()) {
        throw new Error('User profile not found in database.');
      }
      const userData = userSnap.data();
      const rawCurrentBal = userData.walletBalance !== undefined ? userData.walletBalance : userData.balance;
      const currentBalance = typeof rawCurrentBal === 'number' ? rawCurrentBal : (rawCurrentBal ? Number(rawCurrentBal) : 0);

      // 2. Fetch live listing
      const listingDocRef = doc(db, 'listings', listingId);
      const listingSnap = await t.get(listingDocRef);
      if (!listingSnap.exists()) {
        throw new Error('Listing not found in database.');
      }
      const listingData = listingSnap.data();
      const price = Number(listingData.price);

      // Check if listing is sold out or out of stock
      const hasInvArr = Array.isArray(listingData.inventory);
      const availableCount = hasInvArr ? listingData.inventory.filter((acc: any) => (acc.status || '').toLowerCase() !== 'sold').length : undefined;
      const explicitStock = listingData.stockCount !== undefined ? listingData.stockCount : (listingData.stock !== undefined ? listingData.stock : 1);
      const isActuallySold = listingData.status === 'sold' || (availableCount !== undefined ? availableCount <= 0 : explicitStock <= 0);

      const isOwnerOrSeller = userId === listingData.sellerId || 
        isAuthorizedOwnerUid(userId) ||
        (userData.email && (isAuthorizedOwnerEmail(userData.email) || userData.role === 'owner'));

      if (isActuallySold) {
        if (!isOwnerOrSeller) {
          if (listingData.status !== 'sold') {
            t.update(listingDocRef, { status: 'sold', stock: 0, stockCount: 0 });
          }
          throw new Error('This listing is already sold out.');
        } else {
          // If seller/owner is purchasing or testing their own listing, auto-replenish so testing never fails
          console.log(`[Auto-Restock] Seller/Owner ${userData.email} purchasing own listing ${listingId}. Auto-replenishing stock.`);
        }
      }

      // 3. Balance Check
      if (currentBalance < price) {
        throw new Error(`Insufficient wallet balance. You have ₦${currentBalance.toLocaleString()}, but this listing costs ₦${price.toLocaleString()}.`);
      }

      const txId = generateUniqueTransactionId('log');
      const transferCode = `ZENET-ESCROW-${Math.floor(1000 + Math.random() * 9000)}-WALLET`;
      const purchaseId = `pur_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
      const newBal = currentBalance - price;

      let secureDetails: any = null;
      let remainingStock = 0;

      if (hasInventorySubcollection && invSnap) {
        // Find the first AVAILABLE inventory item strictly in existing stock order
        let targetDocSnap = null;
        let targetDocId = null;
        let availableCount = 0;

        // If listing has an inventory array, follow that exact order first
        if (Array.isArray(listingData.inventory) && listingData.inventory.length > 0) {
          for (const invItem of listingData.inventory) {
            const liveItemRef = doc(db, 'listings', listingId, 'inventory', invItem.id);
            const liveItemSnap = await t.get(liveItemRef);
            if (liveItemSnap.exists()) {
              const itemData = liveItemSnap.data();
              const itemStatus = (itemData.status || '').toLowerCase();
              if (itemStatus === 'available' || itemData.status === 'Available') {
                availableCount++;
                if (!targetDocSnap) {
                  targetDocSnap = liveItemSnap;
                  targetDocId = invItem.id;
                }
              }
            }
          }
        }

        // If not found via array order, check remaining subcollection documents
        if (!targetDocSnap) {
          availableCount = 0;
          for (const d of invSnap.docs) {
            const liveItemRef = doc(db, 'listings', listingId, 'inventory', d.id);
            const liveItemSnap = await t.get(liveItemRef);
            if (liveItemSnap.exists()) {
              const itemData = liveItemSnap.data();
              const itemStatus = (itemData.status || '').toLowerCase();
              if (itemStatus === 'available' || itemData.status === 'Available') {
                availableCount++;
                if (!targetDocSnap) {
                  targetDocSnap = liveItemSnap;
                  targetDocId = d.id;
                }
              }
            }
          }
        }

        if (!targetDocSnap || !targetDocId) {
          if (isOwnerOrSeller && invSnap.docs.length > 0) {
            targetDocSnap = invSnap.docs[0];
            targetDocId = invSnap.docs[0].id;
          } else {
            // If no available items remain in subcollection, mark listing as sold
            t.update(listingDocRef, {
              status: 'sold',
              stock: 0,
              stockCount: 0
            });
            throw new Error('All accounts in this listing have already been purchased. Stock is 0.');
          }
        }

        // Read the secure credentials for this exact inventory account
        const secureRef = doc(db, 'listings', listingId, 'inventory', targetDocId, 'secure', 'details');
        const liveSecureSnap = await t.get(secureRef);
        let secData: any = {};
        if (liveSecureSnap.exists()) {
          secData = liveSecureSnap.data();
        } else {
          secData = targetDocSnap.data();
        }

        // Merge array item (which has all form-configured fields), doc data, and secure details
        const matchingArrayItem = Array.isArray(listingData.inventory)
          ? listingData.inventory.find((i: any) => i && i.id === targetDocId)
          : null;

        const mergedRawItem: Record<string, any> = {
          ...(matchingArrayItem || {}),
          ...(targetDocSnap.data() || {}),
          ...(secData || {})
        };

        const internalKeys = new Set([
          'id', 'status', 'soldTo', 'soldToEmail', 'soldAt', 'orderId',
          'updatedAt', 'createdAt', 'listingId', 'deleted', 'isSold'
        ]);

        const dynamicDeliveryFields: Record<string, any> = {};
        for (const [k, v] of Object.entries(mergedRawItem)) {
          if (!internalKeys.has(k) && v !== undefined && v !== null && String(v).trim() !== '') {
            dynamicDeliveryFields[k] = v;
          }
        }

        const deliveryFieldsArray = Array.isArray(mergedRawItem.deliveryFields)
          ? mergedRawItem.deliveryFields
          : (Array.isArray(secData?.deliveryFields) ? secData.deliveryFields : null);

        secureDetails = {
          ...dynamicDeliveryFields,
          inventoryId: targetDocId,
          ...(deliveryFieldsArray ? { deliveryFields: deliveryFieldsArray } : {})
        };

        remainingStock = Math.max(0, availableCount - 1);

        // a. Mark exact inventory account as SOLD
        t.update(targetDocSnap.ref, {
          status: 'Sold',
          soldTo: userId,
          soldToEmail: buyerEmail || userData.email || '',
          orderId: purchaseId,
          soldAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });

        // b. Sync inventory array on listing doc if present
        let updatedInventoryArray = listingData.inventory;
        if (Array.isArray(updatedInventoryArray)) {
          updatedInventoryArray = updatedInventoryArray.map((invItem: any) => {
            if (invItem.id === targetDocId) {
              return {
                ...invItem,
                status: 'Sold',
                soldTo: userId,
                soldToEmail: buyerEmail || userData.email || '',
                orderId: purchaseId,
                soldAt: new Date().toISOString()
              };
            }
            return invItem;
          });
        }

        // c. Update listing doc stock & status
        t.update(listingDocRef, {
          stock: remainingStock,
          stockCount: remainingStock,
          status: remainingStock > 0 ? 'active' : 'sold',
          ...(updatedInventoryArray ? { inventory: updatedInventoryArray } : {})
        });

      } else if (Array.isArray(listingData.inventory) && listingData.inventory.length > 0) {
        // Find first Available account in array following stock order
        let availableIdx = listingData.inventory.findIndex((acc: any) => (acc.status || '').toLowerCase() === 'available' || acc.status === 'Available');
        if (availableIdx === -1) {
          if (isOwnerOrSeller && listingData.inventory.length > 0) {
            availableIdx = 0;
          } else {
            t.update(listingDocRef, { status: 'sold', stock: 0, stockCount: 0 });
            throw new Error('All accounts in this listing have already been purchased. Stock is 0.');
          }
        }

        const targetAcc = listingData.inventory[availableIdx];
        const internalKeys = new Set([
          'id', 'status', 'soldTo', 'soldToEmail', 'soldAt', 'orderId',
          'updatedAt', 'createdAt', 'listingId', 'deleted', 'isSold'
        ]);

        const dynamicDeliveryFields: Record<string, any> = {};
        for (const [k, v] of Object.entries(targetAcc || {})) {
          if (!internalKeys.has(k) && v !== undefined && v !== null && String(v).trim() !== '') {
            dynamicDeliveryFields[k] = v;
          }
        }

        const deliveryFieldsArray = Array.isArray(targetAcc.deliveryFields)
          ? targetAcc.deliveryFields
          : null;

        secureDetails = {
          ...dynamicDeliveryFields,
          inventoryId: targetAcc.id || `inv_${availableIdx + 1}`,
          ...(deliveryFieldsArray ? { deliveryFields: deliveryFieldsArray } : {})
        };

        const updatedInventory = [...listingData.inventory];
        updatedInventory[availableIdx] = {
          ...targetAcc,
          status: 'Sold',
          soldTo: userId,
          soldToEmail: buyerEmail || userData.email || '',
          orderId: purchaseId,
          soldAt: new Date().toISOString()
        };

        const remainingAvailable = updatedInventory.filter((acc: any) => (acc.status || '').toLowerCase() === 'available' || acc.status === 'Available').length;
        remainingStock = remainingAvailable;

        t.update(listingDocRef, {
          inventory: updatedInventory,
          stock: remainingAvailable,
          stockCount: remainingAvailable,
          status: remainingAvailable > 0 ? 'active' : 'sold'
        });

      } else {
        // Fallback for legacy single-stock listings
        const rawDig = listingData.digitalProductDetails || {};
        const internalKeys = new Set([
          'id', 'status', 'soldTo', 'soldToEmail', 'soldAt', 'orderId',
          'updatedAt', 'createdAt', 'listingId', 'deleted', 'isSold'
        ]);

        const dynamicDeliveryFields: Record<string, any> = {};
        for (const [k, v] of Object.entries(rawDig)) {
          if (!internalKeys.has(k) && v !== undefined && v !== null && String(v).trim() !== '') {
            dynamicDeliveryFields[k] = v;
          }
        }

        const deliveryFieldsArray = Array.isArray(rawDig.deliveryFields)
          ? rawDig.deliveryFields
          : null;

        secureDetails = Object.keys(dynamicDeliveryFields).length > 0 ? {
          ...dynamicDeliveryFields,
          ...(deliveryFieldsArray ? { deliveryFields: deliveryFieldsArray } : {})
        } : undefined;

        remainingStock = 0;
        t.update(listingDocRef, {
          stock: 0,
          stockCount: 0,
          status: 'sold'
        });
      }

      const sellerShare = Math.round(price * 0.70);
      const ownerShare = price - sellerShare;

      const purchaseRecord = {
        id: purchaseId,
        listingId: listingId,
        listingTitle: listingData.title,
        category: listingData.category,
        type: 'log',
        transactionCategory: 'log',
        price: price,
        paidAmount: price,
        currency: 'NGN',
        sellerId: listingData.sellerId,
        sellerName: listingData.sellerName,
        sellerEmail: listingData.sellerEmail || '',
        buyerId: userId,
        buyerName: buyerName || userData.displayName || 'Buyer',
        buyerEmail: buyerEmail || userData.email || '',
        paymentGateway: 'wallet',
        transactionId: txId,
        purchasedAt: new Date().toISOString(),
        status: 'escrow_holding',
        transferCode: transferCode,
        imageUrl: listingData.imageUrl || '',
        digitalProductDetails: secureDetails,
        sellerShare,
        ownerShare,
        sellerPercent: 70,
        ownerPercent: 30,
        split: {
          grossAmount: price,
          sellerAmount: sellerShare,
          ownerAmount: ownerShare,
          sellerPercent: 70,
          ownerPercent: 30,
          calculatedAt: new Date().toISOString()
        }
      };

      // c. Deduct user wallet
      t.update(userDocRef, {
        walletBalance: newBal,
        balance: newBal,
        totalPurchasesAmount: (userData.totalPurchasesAmount || 0) + price
      });
      t.set(doc(db, 'wallets', userId), {
        userId: userId,
        userEmail: buyerEmail || userData.email || '',
        walletBalance: newBal,
        balance: newBal,
        updatedAt: new Date().toISOString()
      }, { merge: true });

      // d. Record wallet purchase transaction
      const txDocRef = doc(db, 'wallet_transactions', txId);
      t.set(txDocRef, {
        id: txId,
        reference: txId,
        userId: userId,
        userEmail: buyerEmail || userData.email || '',
        amount: price,
        type: 'purchase',
        category: 'log',
        transactionCategory: 'log',
        status: 'successful',
        description: `Wallet Purchase: ${listingData.title}`,
        date: new Date().toISOString().replace('T', ' ').slice(0, 16),
        createdAt: new Date().toISOString()
      });

      // e. Create purchase document
      const purchaseDocRef = doc(db, 'purchases', purchaseId);
      t.set(purchaseDocRef, purchaseRecord);

      purchaseResult = {
        purchaseRecord,
        newBalance: newBal,
        txId,
        remainingStock
      };
    });

    // Notify seller asynchronously via inquiry
    try {
      if (purchaseResult?.purchaseRecord && purchaseResult.purchaseRecord.sellerId) {
        const inqRef = doc(collection(db, 'inquiries'));
        await setDoc(inqRef, {
          id: inqRef.id,
          listingId: listingId,
          listingTitle: purchaseResult.purchaseRecord.listingTitle,
          buyerId: userId,
          buyerEmail: buyerEmail,
          buyerName: buyerName,
          sellerId: purchaseResult.purchaseRecord.sellerId,
          message: `🎉 ORDER CONFIRMED: Account "${purchaseResult.purchaseRecord.listingTitle}" was purchased for ₦${purchaseResult.purchaseRecord.paidAmount.toLocaleString()} via WALLET Escrow! Escrow Token: ${purchaseResult.purchaseRecord.transferCode}.`,
          createdAt: new Date().toISOString(),
          status: 'unread'
        });
      }
    } catch (inqErr) {
      console.warn('Seller inquiry notification notice:', inqErr);
    }

    // Record 70% Seller / 30% Owner split permanently in database
    if (purchaseResult?.purchaseRecord) {
      await recordSellerRevenueSplit(purchaseResult.purchaseRecord);
    }

    return res.json({
      success: true,
      ...purchaseResult
    });

  } catch (err: any) {
    const isValidationNotice = 
      err?.message?.includes('already sold out') || 
      err?.message?.includes('Insufficient wallet balance') ||
      err?.message?.includes('Listing not found') ||
      err?.message?.includes('All accounts in this listing have already been purchased');

    if (isValidationNotice) {
      console.warn('[Wallet Purchase Notice]:', err?.message);
    } else {
      console.error('Error in /api/wallet/purchase:', err);
    }
    return res.status(400).json({
      success: false,
      error: err.message || 'Wallet purchase failed.'
    });
  }
});

// ==========================================
// SECURE OWNER & ADMIN WITHDRAWAL ENGINE
// ==========================================

/**
 * Generates a permanent, cryptographically-unique Withdrawal ID for an authorized user.
 * Format: ZN-WID-<UPPERCASE_ALPHANUMERIC>
 */
function generatePermanentWithdrawalId(): string {
  const bytes = crypto.randomBytes(4).toString('hex').toUpperCase();
  return `ZN-WID-${bytes}`;
}

// 1. Get or initialize user's permanent server-generated Withdrawal ID
app.get('/api/withdrawals/my-id', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) {
      return res.status(401).json({ success: false, error: 'Unauthorized. Please sign in.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database service is currently unavailable.' });
    }

    const userDocRef = doc(db, 'users', verifiedUser.uid);
    const userDoc = await getDoc(userDocRef);

    if (!userDoc.exists()) {
      return res.status(404).json({ success: false, error: 'User record not found.' });
    }

    const userData = userDoc.data();
    const isOwner = isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid) || isAuthorizedOwnerEmail(userData.email);
    const isAdmin = isOwner || verifiedUser.isAdmin || userData.role === 'admin' || userData.role === 'owner';

    if (!isAdmin) {
      return res.status(403).json({ success: false, error: 'Forbidden: Withdrawals are exclusively accessible to website Owner and authorized Admins.' });
    }

    let withdrawalId = userData.withdrawalId;
    if (!withdrawalId || typeof withdrawalId !== 'string' || !withdrawalId.trim()) {
      withdrawalId = generatePermanentWithdrawalId();
      await setDoc(userDocRef, { withdrawalId, updatedAt: new Date().toISOString() }, { merge: true });
    }

    const currentBalance = typeof userData.walletBalance === 'number'
      ? userData.walletBalance
      : Number(userData.walletBalance || userData.balance || 0);

    return res.json({
      success: true,
      withdrawalId,
      walletBalance: currentBalance,
      role: userData.role || (isOwner ? 'owner' : 'admin')
    });
  } catch (err: any) {
    console.error('Error in /api/withdrawals/my-id:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to retrieve withdrawal identity.' });
  }
});

// 2. Submit a Withdrawal Request (Atomic transaction, double-spend prevention)
app.post('/api/withdrawals/request', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) {
      return res.status(401).json({ success: false, error: 'Unauthorized. Please sign in.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database service is currently unavailable.' });
    }

    const { amount: rawAmount, bankName, bankCode, accountNumber, accountName, notes } = req.body;
    const amount = Number(rawAmount);

    if (isNaN(amount) || !isFinite(amount) || amount <= 0) {
      return res.status(400).json({ success: false, error: 'Invalid withdrawal amount specified.' });
    }

    const MIN_WITHDRAWAL = 5000;
    const MAX_WITHDRAWAL = 100000;

    if (amount < MIN_WITHDRAWAL) {
      return res.status(400).json({ success: false, error: `Minimum withdrawal is ₦${MIN_WITHDRAWAL.toLocaleString()}.` });
    }

    if (amount > MAX_WITHDRAWAL) {
      return res.status(400).json({ success: false, error: `Maximum withdrawal per request is ₦${MAX_WITHDRAWAL.toLocaleString()}.` });
    }

    if (!bankName || typeof bankName !== 'string' || !bankName.trim()) {
      return res.status(400).json({ success: false, error: 'Please select a valid bank.' });
    }

    if (!accountNumber || typeof accountNumber !== 'string' || accountNumber.trim().length !== 10) {
      return res.status(400).json({ success: false, error: 'Please enter a valid 10-digit account number.' });
    }

    if (!accountName || typeof accountName !== 'string' || !accountName.trim()) {
      return res.status(400).json({ success: false, error: 'Account verification required: Paystack verified account name is missing.' });
    }

    const userDocRef = doc(db, 'users', verifiedUser.uid);
    const walletDocRef = doc(db, 'wallets', verifiedUser.uid);

    const now = new Date();
    const isoDate = now.toISOString();
    const dateStr = isoDate.split('T')[0];
    const timeStr = now.toLocaleTimeString('en-US', { hour12: false });
    const monthStr = now.toLocaleString('en-US', { month: 'long', year: 'numeric' });
    const reference = `WREQ-${now.getTime().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
    
    // Dedicated transaction ID for WITHDRAWAL TRANSACTIONS category
    // Format: ZN-WTH-TXN-<YYYYMM>-<TIMESTAMP_BASE36>-<RANDOM_HEX>
    const txnRand = crypto.randomBytes(4).toString('hex').toUpperCase();
    const transactionId = `ZN-WTH-TXN-${dateStr.replace(/-/g, '').slice(0, 6)}-${now.getTime().toString(36).toUpperCase()}-${txnRand}`;
    
    const requestDocRef = doc(db, 'withdrawal_requests', reference);
    const txDocRef = doc(db, 'wallet_transactions', `tx_${reference}`);
    const txnIdDocRef = doc(db, 'withdrawal_transaction_ids', transactionId);

    let createdWithdrawalRecord: any = null;
    let finalNewBalance = 0;

    // Execute atomic transaction to prevent double spending and ensure database consistency & ID uniqueness
    await runTransaction(db, async (transaction) => {
      // Enforce uniqueness at the database level
      const existingTxnSnap = await transaction.get(txnIdDocRef);
      if (existingTxnSnap.exists()) {
        throw new Error(`Conflict: Withdrawal Transaction ID ${transactionId} already exists in database.`);
      }

      const uSnap = await transaction.get(userDocRef);
      if (!uSnap.exists()) {
        throw new Error('User record not found.');
      }

      const uData = uSnap.data();
      const currentBalance = typeof uData.walletBalance === 'number'
        ? uData.walletBalance
        : Number(uData.walletBalance || uData.balance || 0);

      if (currentBalance < amount) {
        throw new Error(`Insufficient withdrawable balance. Your available balance is ₦${currentBalance.toLocaleString()}, but you requested ₦${amount.toLocaleString()}.`);
      }

      let withdrawalId = uData.withdrawalId;
      if (!withdrawalId || typeof withdrawalId !== 'string' || !withdrawalId.trim()) {
        withdrawalId = generatePermanentWithdrawalId();
      }

      finalNewBalance = Math.round((currentBalance - amount) * 100) / 100;

      // Update users collection
      transaction.set(userDocRef, {
        walletBalance: finalNewBalance,
        balance: finalNewBalance,
        withdrawalId,
        updatedAt: isoDate
      }, { merge: true });

      // Update wallets mirror collection
      transaction.set(walletDocRef, {
        userId: verifiedUser.uid,
        walletBalance: finalNewBalance,
        balance: finalNewBalance,
        updatedAt: isoDate
      }, { merge: true });

      // Reserve unique withdrawal transaction ID in the database-level registry
      transaction.set(txnIdDocRef, {
        transactionId,
        category: 'withdrawal',
        reference,
        userId: verifiedUser.uid,
        userEmail: verifiedUser.email,
        amount,
        createdAt: isoDate,
        createdDate: dateStr,
        createdTime: timeStr,
        month: monthStr
      });

      createdWithdrawalRecord = {
        id: reference,
        transactionId,
        category: 'withdrawal',
        userId: verifiedUser.uid,
        userName: uData.displayName || uData.username || uData.fullName || verifiedUser.email.split('@')[0],
        userEmail: verifiedUser.email,
        withdrawalId,
        amount,
        currency: 'NGN',
        bankName: bankName.trim(),
        bankCode: (bankCode || '').trim(),
        accountNumber: accountNumber.trim(),
        accountName: accountName.trim(),
        status: 'pending',
        createdAt: isoDate,
        createdDate: dateStr,
        createdTime: timeStr,
        month: monthStr,
        reference,
        notes: (notes || '').trim(),
      };

      // Record in withdrawal_requests
      transaction.set(requestDocRef, createdWithdrawalRecord);

      // Record in wallet_transactions ledger
      transaction.set(txDocRef, {
        id: `tx_${reference}`,
        transactionId,
        userId: verifiedUser.uid,
        type: 'withdrawal',
        category: 'withdrawal',
        amount,
        description: `Withdrawal payout requested: ₦${amount.toLocaleString()} to ${bankName.trim()} (${accountNumber.trim()})`,
        date: isoDate,
        status: 'pending',
        reference,
        channel: 'bank_transfer'
      });
    });

    return res.json({
      success: true,
      message: `Withdrawal request for ₦${amount.toLocaleString()} created successfully.`,
      reference,
      transactionId,
      newBalance: finalNewBalance,
      withdrawal: createdWithdrawalRecord
    });
  } catch (err: any) {
    console.error('Error in /api/withdrawals/request:', err);
    return res.status(400).json({ success: false, error: err.message || 'Withdrawal request failed.' });
  }
});

// 2b. Get Complete Real Withdrawal Transaction History (Owner / Admin only)
app.get('/api/withdrawals/all-history', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) {
      return res.status(401).json({ success: false, error: 'Unauthorized. Please sign in.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database service is currently unavailable.' });
    }

    const userDocRef = doc(db, 'users', verifiedUser.uid);
    const userDoc = await getDoc(userDocRef);
    const userData = userDoc.exists() ? userDoc.data() : {};
    const isOwner = isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid) || isAuthorizedOwnerEmail(userData.email);
    const isAdmin = isOwner || verifiedUser.isAdmin || userData.role === 'admin' || userData.role === 'owner';

    if (!isAdmin) {
      return res.status(403).json({ success: false, error: 'Forbidden: Access restricted to authorized website Owner & Admins only.' });
    }

    const wCol = collection(db, 'withdrawal_requests');
    const wSnap = await getDocs(wCol);
    const withdrawals = wSnap.docs.map(d => {
      const data = d.data();
      const created = data.createdAt ? new Date(data.createdAt) : new Date(0);
      const dateStr = data.createdDate || (data.createdAt ? data.createdAt.split('T')[0] : '');
      const timeStr = data.createdTime || (data.createdAt ? new Date(data.createdAt).toLocaleTimeString('en-US', { hour12: false }) : '');
      const monthStr = data.month || (created.getTime() > 0 ? created.toLocaleString('en-US', { month: 'long', year: 'numeric' }) : 'Unknown');
      const transactionId = data.transactionId || data.reference || data.id;
      return {
        id: d.id,
        ...data,
        transactionId,
        category: 'withdrawal',
        createdDate: dateStr,
        createdTime: timeStr,
        month: monthStr
      };
    });

    // Sort descending by creation date
    withdrawals.sort((a: any, b: any) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());

    return res.json({
      success: true,
      count: withdrawals.length,
      withdrawals
    });
  } catch (err: any) {
    console.error('Error in /api/withdrawals/all-history:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to retrieve withdrawal transaction history.' });
  }
});

// 2c. Confirm & Search Transaction ID (Owner / Admin only)
app.post('/api/withdrawals/search-transaction', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) {
      return res.status(401).json({ success: false, error: 'Unauthorized. Please sign in.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database service is currently unavailable.' });
    }

    const userDocRef = doc(db, 'users', verifiedUser.uid);
    const userDoc = await getDoc(userDocRef);
    const userData = userDoc.exists() ? userDoc.data() : {};
    const isOwner = isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid) || isAuthorizedOwnerEmail(userData.email);
    const isAdmin = isOwner || verifiedUser.isAdmin || userData.role === 'admin' || userData.role === 'owner';

    if (!isAdmin) {
      return res.status(403).json({ success: false, error: 'Forbidden: Access restricted to authorized website Owner & Admins only.' });
    }

    const { transactionId: rawId } = req.body;
    if (!rawId || typeof rawId !== 'string' || !rawId.trim()) {
      return res.status(400).json({ success: false, error: 'Please enter a valid Transaction ID to search.' });
    }

    const cleanId = rawId.trim();

    // 1. Direct query by transactionId
    let matchedDoc: any = null;
    const q1 = query(collection(db, 'withdrawal_requests'), where('transactionId', '==', cleanId));
    const s1 = await getDocs(q1);
    if (!s1.empty) {
      matchedDoc = { id: s1.docs[0].id, ...s1.docs[0].data() };
    }

    // 2. Query by document id
    if (!matchedDoc) {
      const docSnap = await getDoc(doc(db, 'withdrawal_requests', cleanId));
      if (docSnap.exists()) {
        matchedDoc = { id: docSnap.id, ...docSnap.data() };
      }
    }

    // 3. Query by reference
    if (!matchedDoc) {
      const q2 = query(collection(db, 'withdrawal_requests'), where('reference', '==', cleanId));
      const s2 = await getDocs(q2);
      if (!s2.empty) {
        matchedDoc = { id: s2.docs[0].id, ...s2.docs[0].data() };
      }
    }

    // 4. Query registry if needed to locate reference
    if (!matchedDoc) {
      const regSnap = await getDoc(doc(db, 'withdrawal_transaction_ids', cleanId));
      if (regSnap.exists()) {
        const regData = regSnap.data();
        if (regData.reference) {
          const refDoc = await getDoc(doc(db, 'withdrawal_requests', regData.reference));
          if (refDoc.exists()) {
            matchedDoc = { id: refDoc.id, ...refDoc.data() };
          }
        }
      }
    }

    if (!matchedDoc) {
      return res.status(404).json({ success: false, error: 'Transaction ID not found.' });
    }

    const created = matchedDoc.createdAt ? new Date(matchedDoc.createdAt) : new Date(0);
    const dateStr = matchedDoc.createdDate || (matchedDoc.createdAt ? matchedDoc.createdAt.split('T')[0] : '');
    const timeStr = matchedDoc.createdTime || (matchedDoc.createdAt ? new Date(matchedDoc.createdAt).toLocaleTimeString('en-US', { hour12: false }) : '');
    const monthStr = matchedDoc.month || (created.getTime() > 0 ? created.toLocaleString('en-US', { month: 'long', year: 'numeric' }) : 'Unknown');

    const formatted = {
      id: matchedDoc.id,
      ...matchedDoc,
      transactionId: matchedDoc.transactionId || matchedDoc.reference || matchedDoc.id,
      category: 'withdrawal',
      createdDate: dateStr,
      createdTime: timeStr,
      month: monthStr
    };

    return res.json({
      success: true,
      transaction: formatted
    });
  } catch (err: any) {
    console.error('Error in /api/withdrawals/search-transaction:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to search transaction ID.' });
  }
});

// 3. Verify User & Legitimate Withdrawal Records by Withdrawal ID
app.post('/api/withdrawals/verify-id', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) {
      return res.status(401).json({ success: false, error: 'Unauthorized. Please sign in.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database service is currently unavailable.' });
    }

    const { withdrawalId: rawId } = req.body;
    if (!rawId || typeof rawId !== 'string' || !rawId.trim()) {
      return res.status(400).json({ success: false, error: 'Please enter a valid Withdrawal ID.' });
    }

    const queryId = rawId.trim();

    // Query users collection for permanent matching withdrawalId
    const usersQuery = query(collection(db, 'users'), where('withdrawalId', '==', queryId));
    const userQuerySnap = await getDocs(usersQuery);

    if (userQuerySnap.empty) {
      return res.status(404).json({ success: false, error: 'Invalid Withdrawal ID.' });
    }

    const targetUserDoc = userQuerySnap.docs[0];
    const targetUserData = targetUserDoc.data();

    // Fetch legitimate withdrawal requests linked to this user or withdrawal ID
    const withdrawalsQuery = query(
      collection(db, 'withdrawal_requests'),
      where('withdrawalId', '==', queryId)
    );
    const withSnap = await getDocs(withdrawalsQuery);
    const withdrawals = withSnap.docs.map(d => ({ id: d.id, ...d.data() }));

    // Sort descending by createdAt
    withdrawals.sort((a: any, b: any) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());

    return res.json({
      success: true,
      user: {
        uid: targetUserDoc.id,
        email: targetUserData.email,
        displayName: targetUserData.displayName || targetUserData.username || 'Authorized User',
        role: targetUserData.role || 'user',
        withdrawalId: targetUserData.withdrawalId,
        walletBalance: targetUserData.walletBalance || targetUserData.balance || 0,
        createdAt: targetUserData.createdAt || ''
      },
      withdrawals
    });
  } catch (err: any) {
    console.error('Error in /api/withdrawals/verify-id:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to verify Withdrawal ID.' });
  }
});

// 4. Update Withdrawal Request Status (Approve / Complete / Reject with refund)
app.post('/api/withdrawals/update-status', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) {
      return res.status(401).json({ success: false, error: 'Unauthorized. Please sign in.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database service is currently unavailable.' });
    }

    const userDocRef = doc(db, 'users', verifiedUser.uid);
    const userDoc = await getDoc(userDocRef);
    const userData = userDoc.exists() ? userDoc.data() : {};
    const isOwner = isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid) || isAuthorizedOwnerEmail(userData.email);
    const isAdmin = isOwner || verifiedUser.isAdmin || userData.role === 'admin' || userData.role === 'owner';

    if (!isAdmin) {
      return res.status(403).json({ success: false, error: 'Forbidden: Access restricted to authorized website Owner & Admins only.' });
    }

    const { requestId, status: newStatus, adminNotes } = req.body;
    if (!requestId || !['confirmed', 'approved', 'completed', 'rejected', 'failed'].includes(newStatus)) {
      return res.status(400).json({ success: false, error: 'Invalid request parameters or status.' });
    }

    let reqDocRef = doc(db, 'withdrawal_requests', requestId);
    let reqSnap = await getDoc(reqDocRef);

    if (!reqSnap.exists()) {
      // Try finding by transactionId
      const q = query(collection(db, 'withdrawal_requests'), where('transactionId', '==', requestId));
      const s = await getDocs(q);
      if (!s.empty) {
        reqDocRef = doc(db, 'withdrawal_requests', s.docs[0].id);
        reqSnap = s.docs[0];
      }
    }

    if (!reqSnap.exists()) {
      return res.status(404).json({ success: false, error: 'Withdrawal request not found.' });
    }

    const reqData = reqSnap.data();
    const previousStatus = reqData.status;

    if (previousStatus === newStatus) {
      return res.json({ success: true, status: newStatus });
    }

    const isoDate = new Date().toISOString();

    // If rejecting or failing a pending or approved request, atomically refund money to user wallet
    if (['rejected', 'failed'].includes(newStatus) && !['rejected', 'failed'].includes(previousStatus)) {
      const targetUid = reqData.userId;
      const refundAmount = Number(reqData.amount);

      await runTransaction(db, async (transaction) => {
        const uRef = doc(db, 'users', targetUid);
        const wRef = doc(db, 'wallets', targetUid);
        const uSnap = await transaction.get(uRef);

        if (uSnap.exists()) {
          const curBal = Number(uSnap.data().walletBalance ?? uSnap.data().balance ?? 0);
          const newBal = Math.round((curBal + refundAmount) * 100) / 100;
          transaction.set(uRef, { walletBalance: newBal, balance: newBal, updatedAt: isoDate }, { merge: true });
          transaction.set(wRef, { walletBalance: newBal, balance: newBal, updatedAt: isoDate }, { merge: true });
        }

        // Record refund in wallet_transactions
        const refundTxRef = doc(db, 'wallet_transactions', `tx_ref_${requestId}`);
        transaction.set(refundTxRef, {
          id: `tx_ref_${requestId}`,
          userId: targetUid,
          type: 'deposit',
          amount: refundAmount,
          description: `Refund for rejected withdrawal request ${requestId}${adminNotes ? `: ${adminNotes}` : ''}`,
          date: isoDate,
          status: 'completed',
          reference: `REF-${requestId}`,
          channel: 'system_refund'
        });

        // Update withdrawal request status
        transaction.update(reqDocRef, {
          status: 'rejected',
          adminNotes: (adminNotes || '').trim(),
          updatedAt: isoDate,
          updatedBy: verifiedUser.email
        });
      });
    } else {
      await updateDoc(reqDocRef, {
        status: newStatus,
        adminNotes: (adminNotes || '').trim(),
        updatedAt: isoDate,
        updatedBy: verifiedUser.email
      });
    }

    return res.json({
      success: true,
      message: `Withdrawal request status updated to ${newStatus}.`,
      status: newStatus
    });
  } catch (err: any) {
    console.error('Error in /api/withdrawals/update-status:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to update withdrawal status.' });
  }
});

// 5. Admin Manual Payment Confirmation (Pending -> Confirmed)
app.post('/api/withdrawals/confirm-payment', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    const userDocRef = doc(db, 'users', verifiedUser.uid);
    const userDoc = await getDoc(userDocRef);
    const userData = userDoc.exists() ? userDoc.data() : {};
    const isOwner = isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid) || isAuthorizedOwnerEmail(userData.email);
    const isAdmin = isOwner || verifiedUser.isAdmin || userData.role === 'admin' || userData.role === 'owner';

    if (!isAdmin) {
      return res.status(403).json({ success: false, error: 'Forbidden: Access restricted to authorized website Owner & Admins only.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database service is currently unavailable.' });
    }

    const { requestId, adminNotes } = req.body;
    if (!requestId) {
      return res.status(400).json({ success: false, error: 'Missing requestId parameter.' });
    }

    let reqDocRef = doc(db, 'withdrawal_requests', requestId);
    let reqSnap = await getDoc(reqDocRef);

    if (!reqSnap.exists()) {
      const q = query(collection(db, 'withdrawal_requests'), where('transactionId', '==', requestId));
      const s = await getDocs(q);
      if (!s.empty) {
        reqDocRef = doc(db, 'withdrawal_requests', s.docs[0].id);
        reqSnap = s.docs[0];
      }
    }

    if (!reqSnap.exists()) {
      return res.status(404).json({ success: false, error: 'Withdrawal request not found.' });
    }

    const reqData = reqSnap.data();
    const isoDate = new Date().toISOString();
    await updateDoc(reqDocRef, {
      status: 'confirmed',
      confirmedAt: isoDate,
      confirmedBy: verifiedUser.email,
      confirmedByUid: verifiedUser.uid,
      adminNotes: (adminNotes || '').trim(),
      updatedAt: isoDate
    });

    const refKey = reqData.reference || reqSnap.id;
    const txDocRef = doc(db, 'wallet_transactions', refKey.startsWith('tx_') ? refKey : `tx_${refKey}`);
    try {
      await updateDoc(txDocRef, {
        status: 'confirmed',
        updatedAt: isoDate
      });
    } catch (e) {
      // ignore
    }

    return res.json({
      success: true,
      message: 'Withdrawal payment confirmed.',
      status: 'confirmed',
      confirmedAt: isoDate
    });
  } catch (err: any) {
    console.error('Error in /api/withdrawals/confirm-payment:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to confirm withdrawal payment.' });
  }
});

// ==========================================
// TIKTOK PROMOTION SERVICES & ORDERS API
// ==========================================

const DEFAULT_SERVER_TIKTOK_SERVICES = [
  {
    id: 'followers',
    name: 'TikTok Followers',
    category: 'TikTok',
    targetType: 'profile_url',
    pricePer1k: 3500,
    minQuantity: 100,
    maxQuantity: 50000,
    status: 'active',
    description: 'Real audience follower growth for creator profiles & business accounts.',
    badge: 'Profile Growth',
    deliverySpeed: 'Organic delivery within 1-24 hours'
  },
  {
    id: 'views',
    name: 'TikTok Views',
    category: 'TikTok',
    targetType: 'video_url',
    pricePer1k: 450,
    minQuantity: 500,
    maxQuantity: 500000,
    status: 'active',
    description: 'Expand your video reach and algorithmic discovery across the For You page.',
    badge: 'Viral Reach',
    deliverySpeed: 'Starts in 5-15 minutes'
  },
  {
    id: 'likes',
    name: 'TikTok Likes',
    category: 'TikTok',
    targetType: 'video_url',
    pricePer1k: 1800,
    minQuantity: 50,
    maxQuantity: 25000,
    status: 'active',
    description: 'Genuine viewer heart likes to boost content engagement signals.',
    badge: 'High Engagement',
    deliverySpeed: 'Steady natural pace'
  },
  {
    id: 'comments',
    name: 'TikTok Comments',
    category: 'TikTok',
    targetType: 'video_url',
    requiresComments: true,
    pricePer1k: 6500,
    minQuantity: 10,
    maxQuantity: 2000,
    status: 'active',
    description: 'Custom relevant discussion comments submitted for your specific video.',
    badge: 'Custom Discussion',
    deliverySpeed: 'Gradual natural delivery'
  },
  {
    id: 'shares',
    name: 'TikTok Shares',
    category: 'TikTok',
    targetType: 'video_url',
    pricePer1k: 2200,
    minQuantity: 50,
    maxQuantity: 20000,
    status: 'active',
    description: 'Authentic share counts to trigger TikTok recommendation and distribution algorithms.',
    badge: 'Algorithm Boost',
    deliverySpeed: 'Fast distribution'
  }
];

// GET /api/tiktok-promotion/services
app.get('/api/tiktok-promotion/services', async (_req, res) => {
  try {
    if (!db) {
      return res.json({ success: true, services: DEFAULT_SERVER_TIKTOK_SERVICES });
    }
    await ensureServerAuthenticated();
    const colRef = collection(db, 'tiktok_promotion_services');
    const snap = await getDocs(colRef);
    if (snap.empty) {
      return res.json({ success: true, services: DEFAULT_SERVER_TIKTOK_SERVICES });
    }
    const map = new Map<string, any>();
    snap.docs.forEach((d) => {
      map.set(d.id, { id: d.id, ...d.data() });
    });
    const services = DEFAULT_SERVER_TIKTOK_SERVICES.map((def) => {
      const saved = map.get(def.id);
      return saved ? { ...def, ...saved } : def;
    });
    return res.json({ success: true, services });
  } catch (err: any) {
    console.warn('[TikTok Promotion] Services fetch notice:', err?.message);
    return res.json({ success: true, services: DEFAULT_SERVER_TIKTOK_SERVICES });
  }
});

// POST /api/tiktok-promotion/services: Admin updates
app.post('/api/tiktok-promotion/services', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser || !verifiedUser.isAdmin) {
      return res.status(403).json({ success: false, error: 'Administrative authorization required.' });
    }
    if (!db) {
      return res.status(500).json({ success: false, error: 'Database unavailable.' });
    }
    await ensureServerAuthenticated();
    const { services } = req.body;
    if (!Array.isArray(services)) {
      return res.status(400).json({ success: false, error: 'Services array is required.' });
    }
    for (const s of services) {
      if (s && s.id) {
        const docRef = doc(db, 'tiktok_promotion_services', s.id);
        await setDoc(docRef, {
          pricePer1k: Number(s.pricePer1k) || 0,
          minQuantity: Number(s.minQuantity) || 10,
          maxQuantity: Number(s.maxQuantity) || 100000,
          status: s.status === 'paused' ? 'paused' : 'active',
          updatedAt: new Date().toISOString()
        }, { merge: true });
      }
    }
    return res.json({ success: true, message: 'TikTok promotion services updated successfully.' });
  } catch (err: any) {
    console.error('Error updating TikTok promotion services:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to update services' });
  }
});

// GET /api/tiktok-services/settings: Get configured rates and limits for TikTok services
app.get('/api/tiktok-services/settings', async (_req, res) => {
  try {
    if (db) {
      await ensureServerAuthenticated();
      const docSnap = await getDoc(doc(db, 'system_settings', 'tiktok_services_config'));
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data && data.services) {
          return res.json({ success: true, services: data.services, updatedAt: data.updatedAt });
        }
      }
    }
    return res.json({
      success: true,
      services: {
        'tt-followers': { id: 'tt-followers', name: 'TikTok Followers', minQuantity: 10, maxQuantity: 1000000, pricePer1k: 2400 },
        'tt-likes': { id: 'tt-likes', name: 'TikTok Likes', minQuantity: 50, maxQuantity: 500000, pricePer1k: 850 },
        'tt-comments': { id: 'tt-comments', name: 'TikTok Comments', minQuantity: 10, maxQuantity: 10000, pricePer1k: 4500 },
        'tt-shares': { id: 'tt-shares', name: 'TikTok Shares', minQuantity: 50, maxQuantity: 200000, pricePer1k: 650 },
        'tt-views': { id: 'tt-views', name: 'TikTok Views', minQuantity: 500, maxQuantity: 2000000, pricePer1k: 250 },
        'tt-favorites': { id: 'tt-favorites', name: 'TikTok Favorites', minQuantity: 50, maxQuantity: 200000, pricePer1k: 750 }
      }
    });
  } catch (err: any) {
    console.warn('[TikTok Services Settings] Fetch notice:', err.message);
    return res.json({
      success: true,
      services: {
        'tt-followers': { id: 'tt-followers', name: 'TikTok Followers', minQuantity: 10, maxQuantity: 1000000, pricePer1k: 2400 },
        'tt-likes': { id: 'tt-likes', name: 'TikTok Likes', minQuantity: 50, maxQuantity: 500000, pricePer1k: 850 },
        'tt-comments': { id: 'tt-comments', name: 'TikTok Comments', minQuantity: 10, maxQuantity: 10000, pricePer1k: 4500 },
        'tt-shares': { id: 'tt-shares', name: 'TikTok Shares', minQuantity: 50, maxQuantity: 200000, pricePer1k: 650 },
        'tt-views': { id: 'tt-views', name: 'TikTok Views', minQuantity: 500, maxQuantity: 2000000, pricePer1k: 250 },
        'tt-favorites': { id: 'tt-favorites', name: 'TikTok Favorites', minQuantity: 50, maxQuantity: 200000, pricePer1k: 750 }
      }
    });
  }
});

// POST /api/tiktok-services/settings: Save configured rates and limits for TikTok services (Admin Only)
app.post('/api/tiktok-services/settings', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser || (!verifiedUser.isAdmin && !isAuthorizedOwnerEmail(verifiedUser.email))) {
      return res.status(403).json({ success: false, error: 'Unauthorized: Admin access required to update TikTok settings.' });
    }
    const { services } = req.body;
    if (!services || typeof services !== 'object') {
      return res.status(400).json({ success: false, error: 'Valid services configuration object is required.' });
    }

    if (db) {
      await ensureServerAuthenticated();
      await setDoc(doc(db, 'system_settings', 'tiktok_services_config'), {
        services,
        updatedAt: new Date().toISOString(),
        updatedBy: verifiedUser.email
      }, { merge: true });
    }

    return res.json({ success: true, message: 'TikTok services settings saved successfully.', services });
  } catch (err: any) {
    console.error('Error saving TikTok services settings:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to save settings' });
  }
});

// POST /api/tiktok-promotion/order: Place a TikTok promotion order using wallet balance
app.post('/api/tiktok-promotion/order', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) {
      return res.status(401).json({ success: false, error: 'Authentication required. Please log in to order TikTok promotion.' });
    }
    const { serviceId, targetUrl, quantity, comments, userEmail } = req.body;
    if (!serviceId || !targetUrl || !quantity) {
      return res.status(400).json({ success: false, error: 'Service ID, target URL, and quantity are required.' });
    }
    const numQty = Number(quantity);
    if (isNaN(numQty) || numQty <= 0) {
      return res.status(400).json({ success: false, error: 'Valid positive quantity is required.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database unavailable.' });
    }
    await ensureServerAuthenticated();

    // Fetch service configuration
    let svc = DEFAULT_SERVER_TIKTOK_SERVICES.find((s) => s.id === serviceId);
    try {
      const svcDoc = await getDoc(doc(db, 'tiktok_promotion_services', serviceId));
      if (svcDoc.exists()) {
        svc = { ...svc, ...(svcDoc.data() as any) };
      }
    } catch {}

    if (!svc) {
      return res.status(400).json({ success: false, error: 'Invalid TikTok service selected.' });
    }
    if (svc.status === 'paused') {
      return res.status(400).json({ success: false, error: 'This TikTok service is temporarily paused by administration.' });
    }
    if (numQty < svc.minQuantity || numQty > svc.maxQuantity) {
      return res.status(400).json({
        success: false,
        error: `Quantity must be between ${svc.minQuantity.toLocaleString()} and ${svc.maxQuantity.toLocaleString()} for ${svc.name}.`
      });
    }

    if (svc.requiresComments) {
      if (!comments || !Array.isArray(comments) || comments.filter((c: string) => c && c.trim()).length === 0) {
        return res.status(400).json({ success: false, error: 'Please provide at least one custom comment for this order.' });
      }
    }

    const totalCost = Math.max(1, Math.round((numQty / 1000) * svc.pricePer1k));
    const userId = verifiedUser.uid;
    const orderNumber = `TT-${Math.floor(100000 + Math.random() * 900000)}`;
    const orderId = `tt_order_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const transactionId = generateUniqueTransactionId('boost');
    const txId = transactionId;

    const userDocRef = doc(db, 'users', userId);
    const walletDocRef = doc(db, 'wallets', userId);

    let finalNewBal = 0;
    let orderRecord: any = null;

    await runTransaction(db, async (t) => {
      const userSnap = await t.get(userDocRef);
      const walletSnap = await t.get(walletDocRef);

      const uData = userSnap.exists() ? userSnap.data() : {};
      const wData = walletSnap.exists() ? walletSnap.data() : {};

      const uBal = Number(uData.walletBalance ?? uData.balance ?? 0);
      const wBal = Number(wData.walletBalance ?? wData.balance ?? 0);
      const currentBal = Math.max(uBal, wBal);

      if (currentBal < totalCost) {
        throw new Error(`Insufficient wallet balance. Total cost: ₦${totalCost.toLocaleString()}, Available balance: ₦${currentBal.toLocaleString()}. Please fund your wallet.`);
      }

      finalNewBal = currentBal - totalCost;

      // Update user doc
      t.set(userDocRef, {
        walletBalance: finalNewBal,
        balance: finalNewBal,
        updatedAt: new Date().toISOString()
      }, { merge: true });

      // Update wallet doc
      t.set(walletDocRef, {
        userId,
        userEmail: userEmail || verifiedUser.email || uData.email || '',
        walletBalance: finalNewBal,
        balance: finalNewBal,
        updatedAt: new Date().toISOString()
      }, { merge: true });

      // Record wallet debit transaction
      const txDocRef = doc(db, 'wallet_transactions', txId);
      t.set(txDocRef, {
        id: txId,
        reference: txId,
        transactionId,
        userId,
        userEmail: userEmail || verifiedUser.email || uData.email || '',
        amount: totalCost,
        type: 'debit',
        category: 'promotion',
        status: 'successful',
        description: `TikTok Promotion: ${svc.name} (${numQty.toLocaleString()})`,
        date: new Date().toISOString().replace('T', ' ').slice(0, 16),
        createdAt: new Date().toISOString()
      });

      orderRecord = {
        id: orderId,
        orderId,
        transactionId,
        orderNumber,
        serviceId: svc.id,
        serviceName: svc.name,
        targetUrl: targetUrl.trim(),
        comments: svc.requiresComments ? comments : undefined,
        quantity: numQty,
        pricePer1k: svc.pricePer1k,
        totalCost,
        userId,
        userEmail: userEmail || verifiedUser.email || uData.email || '',
        status: 'pending',
        platform: 'TikTok',
        category: 'TikTok Promotion',
        complianceNotice: '100% Policy Compliant & Safe Promotion via real creator networks.',
        createdAt: new Date().toISOString()
      };

      // Save order in tiktok_promotion_orders
      const orderDocRef = doc(db, 'tiktok_promotion_orders', orderId);
      t.set(orderDocRef, orderRecord);

      // Also record in purchases collection for unified user order history
      const purchaseDocRef = doc(db, 'purchases', orderId);
      t.set(purchaseDocRef, {
        id: orderId,
        listingId: svc.id,
        listingTitle: `${svc.name} (${numQty.toLocaleString()})`,
        category: 'TikTok Promotion',
        price: totalCost,
        paidAmount: totalCost,
        sellerId: 'zenet-official-promotion',
        sellerName: 'ZENET Promotion Hub',
        buyerId: userId,
        buyerEmail: userEmail || verifiedUser.email || uData.email || '',
        status: 'completed',
        purchasedAt: new Date().toISOString(),
        orderStatus: 'Processing Promotion',
        type: 'promotion',
        digitalProductDetails: {
          service: svc.name,
          targetUrl: targetUrl.trim(),
          quantity: String(numQty),
          orderNumber
        }
      });
    });

    return res.json({
      success: true,
      orderId,
      orderNumber,
      newBalance: finalNewBal,
      order: orderRecord
    });
  } catch (err: any) {
    console.error('Error placing TikTok promotion order:', err);
    return res.status(400).json({
      success: false,
      error: err.message || 'Failed to place TikTok promotion order.'
    });
  }
});

// GET /api/tiktok-promotion/orders: User's or admin's orders
app.get('/api/tiktok-promotion/orders', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) {
      return res.status(401).json({ success: false, error: 'Authentication required.' });
    }
    if (!db) {
      return res.status(500).json({ success: false, error: 'Database unavailable.' });
    }
    await ensureServerAuthenticated();
    const colRef = collection(db, 'tiktok_promotion_orders');
    let q;
    if (verifiedUser.isAdmin && req.query.all === 'true') {
      q = query(colRef);
    } else {
      q = query(colRef, where('userId', '==', verifiedUser.uid));
    }
    const snap = await getDocs(q);
    const orders = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, any>) }));
    // Sort descending by createdAt
    orders.sort((a: any, b: any) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    return res.json({ success: true, orders });
  } catch (err: any) {
    console.error('Error fetching TikTok promotion orders:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch orders' });
  }
});

app.get(['/api/paystack/verify/:reference', '/api/paystack/verify'], async (req, res) => {
  try {
    const reference = req.params.reference || (req.query.reference as string) || (req.query.trxref as string);
    const { userId } = req.query;

    if (!reference) {
      return res.status(400).json({ verified: false, error: 'Transaction reference is missing' });
    }

    const result = await verifyAndCreditTransaction(reference, userId as string);
    if (result.verified) {
      return res.json(result);
    } else {
      return res.status(400).json(result);
    }
  } catch (err: any) {
    console.error('Error in /api/paystack/verify:', err);
    res.status(500).json({ verified: false, error: err.message || 'Payment verification failed' });
  }
});

app.get('/api/payments/verify', async (req, res) => {
  try {
    const reference = (req.query.reference as string) || (req.query.trxref as string);
    const userId = req.query.userId as string;

    if (!reference) {
      return res.status(400).json({ verified: false, error: 'Transaction reference (reference or trxref) is missing' });
    }

    const result = await verifyAndCreditTransaction(reference, userId);
    if (result.verified) {
      return res.json(result);
    } else {
      return res.status(400).json(result);
    }
  } catch (err: any) {
    console.error('Error in /api/payments/verify:', err);
    res.status(500).json({ verified: false, error: err.message || 'Payment verification failed' });
  }
});

// Paystack Inbound Bank Transfer Webhook with HMAC Signature Verification & Double-Credit Protection
app.post('/api/paystack/webhook', async (req: any, res) => {
  try {
    const event = req.body;
    const signature = (req.headers['x-paystack-signature'] || '') as string;
    const paystackSecretKey = getPaystackSecretKey();

    // HMAC SHA-512 Verification using exact rawBody buffer
    if (paystackSecretKey) {
      const rawPayload = req.rawBody ? req.rawBody : (typeof req.body === 'string' ? req.body : JSON.stringify(req.body));
      const hash = crypto.createHmac('sha512', paystackSecretKey)
        .update(rawPayload)
        .digest('hex');

      if (!signature || hash.toLowerCase() !== signature.toLowerCase()) {
        console.warn('[Paystack Webhook] Invalid Paystack signature received.');
        return res.status(400).json({ error: 'Invalid HMAC signature' });
      }
    }

    if (!event || !event.event) {
      return res.status(400).json({ error: 'Invalid event structure' });
    }

    console.log(`[Paystack Webhook] Event Received: ${event.event}`);

    if (event.event === 'charge.success') {
      const data = event.data;
      const reference = data.reference || `PAY_${data.id}`;

      console.log(`[Paystack Webhook] Processing charge.success via verifyAndCreditTransaction for Ref: ${reference}`);

      // Call our robust unified verifier & credit function passing authenticated webhook data
      const result = await verifyAndCreditTransaction(reference, undefined, data);

      if (result.verified) {
        return res.status(200).json({
          status: 'success',
          message: 'Webhook processed and credited successfully.',
          reference,
          amount: result.amount,
          alreadyProcessed: !!result.alreadyProcessed
        });
      } else {
        console.warn(`[Paystack Webhook] verifyAndCreditTransaction failed for Ref: ${reference}. Error: ${result.error}`);
        return res.status(400).json({
          status: 'failed',
          error: result.error || 'Verification and crediting failed.'
        });
      }
    }

    return res.status(200).json({ status: 'ignored', message: `Event ${event.event} received` });

  } catch (err: any) {
    console.error('Error in /api/paystack/webhook:', err);
    res.status(500).json({ error: 'Webhook processing error' });
  }
});

// 3. Payment API Proxy Routes
app.post('/api/payment/create-checkout', async (req, res) => {
  try {
    const { listingId, listingTitle, priceNaira, currency, buyerEmail, gateway } = req.body;

    if (!listingId || !priceNaira) {
      return res.status(400).json({ error: 'Missing listing details' });
    }

    // Convert Naira price to target currency (e.g. USD, EUR, GBP, NGN)
    const rates: Record<string, number> = {
      NGN: 1,
      USD: 0.00067,
      EUR: 0.00062,
      GBP: 0.00053
    };

    const targetCurrency = (currency || 'NGN').toUpperCase();
    const convertedAmount = Math.max(1, Math.round((priceNaira * (rates[targetCurrency] || rates.NGN)) * 100) / 100);

    // Generate reference / transaction ID
    const transactionId = `TX_PAYSTACK_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

    return res.json({
      success: true,
      gateway: gateway || 'paystack',
      transactionId,
      amount: convertedAmount,
      currency: targetCurrency,
      mode: 'paystack_checkout',
      message: 'Paystack Payment Gateway Ready'
    });

  } catch (err: any) {
    console.error('Error in /api/payment/create-checkout:', err);
    res.status(500).json({ error: err.message || 'Payment creation failed' });
  }
});

// Secure User Profile Verification API (Single Source of Truth)
app.get('/api/user/profile', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) {
      return res.status(401).json({ success: false, error: 'Unauthorized: valid token required' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database service unavailable' });
    }

    const userDocSnap = await getDoc(doc(db, 'users', verifiedUser.uid));
    let role = 'buyer';
    let profileData: any = {};

    if (userDocSnap.exists()) {
      profileData = userDocSnap.data();
      role = profileData.role || 'buyer';
    }

    if (isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid) || isAuthorizedOwnerEmail(profileData.email)) {
      role = 'owner';
    }

    return res.json({
      success: true,
      uid: verifiedUser.uid,
      email: verifiedUser.email,
      role,
      profile: profileData
    });
  } catch (err: any) {
    console.error('Error in /api/user/profile:', err);
    res.status(500).json({ success: false, error: err.message || 'Failed to fetch user profile' });
  }
});

// Secure Admin/Role Management API (Owner Authority with Permanent Database Persistence)
app.post('/api/admin/manage-role', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    let verifiedUser = await getVerifiedAuthUser(authHeader);

    // Verify owner status from token or caller email fallback
    let isOwner = false;
    if (verifiedUser) {
      isOwner = isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid);
      if (!isOwner && db) {
        try {
          const uSnap = await getDoc(doc(db, 'users', verifiedUser.uid));
          if (uSnap.exists()) {
            const uData = uSnap.data();
            if (uData.role === 'owner' || isAuthorizedOwnerEmail(uData.email)) {
              isOwner = true;
            }
          }
        } catch {}
      }
    }

    const callerEmail = (req.body.callerEmail || verifiedUser?.email || '').trim().toLowerCase();
    if (!isOwner && callerEmail && isAuthorizedOwnerEmail(callerEmail)) {
      isOwner = true;
    }

    if (!isOwner) {
      return res.status(403).json({ error: 'Forbidden: Access Denied. Only authenticated Owners are authorized to manage administrator roles' });
    }

    const { targetUid, newRole } = req.body;

    if (!targetUid || !newRole) {
      return res.status(400).json({ error: 'Target user ID and new role are required' });
    }

    // Standardize role value: 'admin' for administrators, 'buyer' for customers, 'seller' for sellers
    const standardizedRole = (newRole === 'admin') ? 'admin' : (newRole === 'seller' ? 'seller' : 'buyer');

    if (db) {
      const nowIso = new Date().toISOString();
      const userRef = doc(db, 'users', targetUid);
      
      // Update role permanently in users collection
      await setDoc(userRef, { 
        role: standardizedRole,
        roleUpdatedAt: nowIso,
        roleUpdatedBy: verifiedUser?.email || callerEmail || 'owner',
        updatedAt: nowIso
      }, { merge: true });

      // Dual-sync to admins collection for fast rules/service checks
      try {
        const adminRef = doc(db, 'admins', targetUid);
        if (standardizedRole === 'admin') {
          await setDoc(adminRef, {
            uid: targetUid,
            role: 'admin',
            grantedAt: nowIso,
            grantedBy: verifiedUser?.email || callerEmail || 'owner'
          }, { merge: true });
        } else {
          await deleteDoc(adminRef).catch(() => {});
        }
      } catch (adminCollErr) {
        console.warn('[Manage Role API] Admins collection sync notice:', adminCollErr);
      }
    }

    console.log(`[Manage Role API] Owner ${verifiedUser?.email || callerEmail} permanently updated user ${targetUid} to role ${standardizedRole}`);

    return res.json({
      success: true,
      message: `User role permanently updated to ${standardizedRole}`,
      targetUid,
      newRole: standardizedRole
    });
  } catch (err: any) {
    console.error('Error in /api/admin/manage-role:', err);
    res.status(500).json({ error: err.message || 'Failed to update user role' });
  }
});

// ============================================================================
// OWNER STOCK APPROVAL CENTER & USER NOTIFICATIONS SERVER APIS
// ============================================================================

// 1. Owner Approve Stock Submission
app.post('/api/stock/approve', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) {
      return res.status(401).json({ success: false, error: 'Unauthorized: valid token required' });
    }

    // Strict server-side Owner check
    const isOwner = isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid);
    if (!isOwner) {
      return res.status(403).json({ success: false, error: 'Forbidden: Access restricted strictly to the website Owner.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database service unavailable' });
    }

    const { listingId, approvedPrice } = req.body;
    if (!listingId) {
      return res.status(400).json({ success: false, error: 'Missing listingId parameter' });
    }

    const listingRef = doc(db, 'listings', listingId);
    const listingSnap = await getDoc(listingRef);
    if (!listingSnap.exists()) {
      return res.status(404).json({ success: false, error: 'Listing not found in database' });
    }

    const listingData = listingSnap.data();
    const nowIso = new Date().toISOString();
    const originalPrice = Number(listingData.originalPrice || listingData.price || 0);
    const finalPrice = approvedPrice !== undefined && !isNaN(Number(approvedPrice)) 
      ? Number(approvedPrice) 
      : Number(listingData.price || 0);
    const quantity = Number(listingData.stockCount || listingData.stock || (Array.isArray(listingData.inventory) ? listingData.inventory.length : 1));

    // A. Update listing status to Approved and Active
    await setDoc(listingRef, {
      approvalStatus: 'approved',
      status: 'active',
      price: finalPrice,
      approvedPrice: finalPrice,
      approvedBy: verifiedUser.email,
      approvedAt: nowIso,
      updatedAt: nowIso
    }, { merge: true });

    // B. Save permanent audit record in stock_approvals
    const approvalId = `appr_${listingId}_${Date.now()}`;
    await setDoc(doc(db, 'stock_approvals', approvalId), {
      id: approvalId,
      listingId,
      title: listingData.title || 'Account Stock',
      category: listingData.category || 'General',
      submitterId: listingData.sellerId || listingData.creatorId || '',
      submitterName: listingData.sellerName || 'Seller',
      submitterEmail: listingData.sellerEmail || '',
      status: 'approved',
      originalPrice,
      approvedPrice: finalPrice,
      quantity,
      submittedAt: listingData.createdAt || nowIso,
      reviewedAt: nowIso,
      reviewedBy: verifiedUser.email,
      reviewedByUid: verifiedUser.uid
    });

    // C. Create permanent notification for the submitter
    const sellerUid = listingData.sellerId || listingData.creatorId;
    if (sellerUid) {
      const notifId = `notif_appr_${listingId}_${Date.now()}`;
      await setDoc(doc(db, 'user_notifications', notifId), {
        id: notifId,
        userId: sellerUid,
        userEmail: listingData.sellerEmail || '',
        title: 'Stock Approved',
        message: `Your stock submission "${listingData.title}" has been approved by the Owner and is now active on the marketplace for ₦${finalPrice.toLocaleString()}.`,
        type: 'stock_approved',
        relatedId: listingId,
        read: false,
        createdAt: nowIso
      });
    }

    console.log(`[Stock Approval] Owner ${verifiedUser.email} APPROVED listing ${listingId} at ₦${finalPrice}`);

    return res.json({
      success: true,
      message: 'Stock submission approved and activated successfully',
      listingId,
      approvedPrice: finalPrice
    });
  } catch (err: any) {
    console.error('Error approving stock:', err);
    res.status(500).json({ success: false, error: err.message || 'Failed to approve stock' });
  }
});

// 2. Owner Reject Stock Submission
app.post('/api/stock/reject', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) {
      return res.status(401).json({ success: false, error: 'Unauthorized: valid token required' });
    }

    // Strict server-side Owner check
    const isOwner = isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid);
    if (!isOwner) {
      return res.status(403).json({ success: false, error: 'Forbidden: Access restricted strictly to the website Owner.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database service unavailable' });
    }

    const { listingId, rejectionReason } = req.body;
    if (!listingId || !rejectionReason || !rejectionReason.trim()) {
      return res.status(400).json({ success: false, error: 'listingId and rejectionReason are required' });
    }

    const listingRef = doc(db, 'listings', listingId);
    const listingSnap = await getDoc(listingRef);
    if (!listingSnap.exists()) {
      return res.status(404).json({ success: false, error: 'Listing not found in database' });
    }

    const listingData = listingSnap.data();
    const nowIso = new Date().toISOString();
    const quantity = Number(listingData.stockCount || listingData.stock || (Array.isArray(listingData.inventory) ? listingData.inventory.length : 1));

    // A. Update listing: do NOT activate stock, store rejection reason
    await setDoc(listingRef, {
      approvalStatus: 'rejected',
      status: 'reserved', // keep inactive & hidden from marketplace
      rejectionReason: rejectionReason.trim(),
      rejectedBy: verifiedUser.email,
      rejectedAt: nowIso,
      updatedAt: nowIso
    }, { merge: true });

    // B. Record permanent audit record in stock_approvals
    const approvalId = `appr_rej_${listingId}_${Date.now()}`;
    await setDoc(doc(db, 'stock_approvals', approvalId), {
      id: approvalId,
      listingId,
      title: listingData.title || 'Account Stock',
      category: listingData.category || 'General',
      submitterId: listingData.sellerId || listingData.creatorId || '',
      submitterName: listingData.sellerName || 'Seller',
      submitterEmail: listingData.sellerEmail || '',
      status: 'rejected',
      rejectionReason: rejectionReason.trim(),
      originalPrice: Number(listingData.price || 0),
      quantity,
      submittedAt: listingData.createdAt || nowIso,
      reviewedAt: nowIso,
      reviewedBy: verifiedUser.email,
      reviewedByUid: verifiedUser.uid
    });

    // C. Create permanent notification for the submitter with the rejection reason
    const sellerUid = listingData.sellerId || listingData.creatorId;
    if (sellerUid) {
      const notifId = `notif_rej_${listingId}_${Date.now()}`;
      await setDoc(doc(db, 'user_notifications', notifId), {
        id: notifId,
        userId: sellerUid,
        userEmail: listingData.sellerEmail || '',
        title: 'Stock Rejected',
        message: `Your stock submission "${listingData.title}" was rejected by the Owner. Reason: ${rejectionReason.trim()}`,
        type: 'stock_rejected',
        relatedId: listingId,
        rejectionReason: rejectionReason.trim(),
        read: false,
        createdAt: nowIso
      });
    }

    console.log(`[Stock Approval] Owner ${verifiedUser.email} REJECTED listing ${listingId}. Reason: ${rejectionReason}`);

    return res.json({
      success: true,
      message: 'Stock submission rejected and submitter notified',
      listingId,
      rejectionReason: rejectionReason.trim()
    });
  } catch (err: any) {
    console.error('Error rejecting stock:', err);
    res.status(500).json({ success: false, error: err.message || 'Failed to reject stock' });
  }
});

// 3. Owner Update Pending Listing Details & Price before approval
app.post('/api/stock/update-pending-details', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const isOwner = isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid);
    if (!isOwner) return res.status(403).json({ success: false, error: 'Forbidden: Owner access required' });

    if (!db) return res.status(500).json({ success: false, error: 'Database service unavailable' });

    const { listingId, price, title, description } = req.body;
    if (!listingId) return res.status(400).json({ success: false, error: 'Missing listingId' });

    const listingRef = doc(db, 'listings', listingId);
    const updateFields: any = { updatedAt: new Date().toISOString() };
    if (price !== undefined && !isNaN(Number(price))) {
      updateFields.price = Number(price);
    }
    if (title !== undefined && title.trim()) {
      updateFields.title = title.trim();
    }
    if (description !== undefined) {
      updateFields.description = description.trim();
    }

    await setDoc(listingRef, updateFields, { merge: true });
    return res.json({ success: true, message: 'Pending stock updated successfully', listingId, updateFields });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Owner Inspect Stock Inventory details (including credentials)
app.get('/api/stock/inventory/:listingId', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) return res.status(401).json({ success: false, error: 'Unauthorized' });

    const isOwner = isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid);
    if (!isOwner) return res.status(403).json({ success: false, error: 'Forbidden: Owner access required' });

    if (!db) return res.status(500).json({ success: false, error: 'Database service unavailable' });

    const listingId = req.params.listingId;
    const invCol = collection(db, 'listings', listingId, 'inventory');
    const snap = await getDocs(invCol);
    const items = await Promise.all(snap.docs.map(async (docSnap) => {
      const base = docSnap.data();
      let secureDetails = {};
      try {
        const secSnap = await getDoc(doc(db, 'listings', listingId, 'inventory', docSnap.id, 'secure', 'details'));
        if (secSnap.exists()) {
          secureDetails = secSnap.data();
        }
      } catch {}
      return { id: docSnap.id, ...base, ...secureDetails };
    }));

    return res.json({ success: true, items });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. User Notifications: Create Notification
app.post('/api/notifications/create', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) return res.status(401).json({ success: false, error: 'Unauthorized' });
    if (!db) return res.status(500).json({ success: false, error: 'Database service unavailable' });

    const { userId, userEmail, title, message, type, relatedId, metadata } = req.body;
    if (!userId || !title || !message) {
      return res.status(400).json({ success: false, error: 'userId, title, and message are required' });
    }

    const notifId = `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const nowIso = new Date().toISOString();
    await setDoc(doc(db, 'user_notifications', notifId), {
      id: notifId,
      userId,
      userEmail: userEmail || '',
      title: title.trim(),
      message: message.trim(),
      type: type || 'system',
      relatedId: relatedId || null,
      read: false,
      createdAt: nowIso,
      metadata: metadata || {}
    });

    return res.json({ success: true, notificationId: notifId });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 6. User Notifications: Mark as Read
app.post('/api/notifications/mark-read', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) return res.status(401).json({ success: false, error: 'Unauthorized' });
    if (!db) return res.status(500).json({ success: false, error: 'Database service unavailable' });

    const { notificationId } = req.body;
    if (!notificationId) return res.status(400).json({ success: false, error: 'Missing notificationId' });

    const notifRef = doc(db, 'user_notifications', notificationId);
    await setDoc(notifRef, {
      read: true,
      readAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }, { merge: true });

    return res.json({ success: true, message: 'Notification marked as read' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 7. User Notifications: Mark All as Read
app.post('/api/notifications/mark-all-read', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);
    if (!verifiedUser) return res.status(401).json({ success: false, error: 'Unauthorized' });
    if (!db) return res.status(500).json({ success: false, error: 'Database service unavailable' });

    const isOwner = isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid);
    const targetUserIds = isOwner ? [verifiedUser.uid, 'owner'] : [verifiedUser.uid];

    for (const uid of targetUserIds) {
      const q = query(
        collection(db, 'user_notifications'),
        where('userId', '==', uid),
        where('read', '==', false)
      );
      const snap = await getDocs(q);
      const batchPromises = snap.docs.map(d =>
        setDoc(doc(db, 'user_notifications', d.id), {
          read: true,
          readAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }, { merge: true })
      );
      await Promise.all(batchPromises);
    }

    return res.json({ success: true, message: 'All notifications marked as read' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Secure Admin Stock Management: Delete entire listing/stock (Owner only)
app.delete('/api/admin/listings/:listingId', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);

    const isAuthorized = Boolean(
      verifiedUser && (
        verifiedUser.isAdmin ||
        isAuthorizedOwnerEmail(verifiedUser.email) ||
        isAuthorizedOwnerUid(verifiedUser.uid) ||
        verifiedUser.email?.toLowerCase() === 'azeezmusharaf4@gmail.com'
      )
    );

    if (!isAuthorized) {
      return res.status(403).json({ success: false, error: 'Forbidden: Only authorized Owners can delete stock listings.' });
    }

    const { listingId } = req.params;
    if (!listingId) {
      return res.status(400).json({ success: false, error: 'Listing ID is required.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database not initialized.' });
    }

    // 1. Delete all inventory items and their secure subcollections
    try {
      const invCol = collection(db, 'listings', listingId, 'inventory');
      const invSnaps = await getDocs(invCol);
      for (const itemDoc of invSnaps.docs) {
        try {
          const secRef = doc(db, 'listings', listingId, 'inventory', itemDoc.id, 'secure', 'details');
          await deleteDoc(secRef);
        } catch (_) {}
        try {
          await deleteDoc(itemDoc.ref);
        } catch (_) {}
      }
    } catch (e) {
      console.warn('Subcollection cleanup notice for listing deletion:', e);
    }

    // 2. Delete parent listing document
    const listingRef = doc(db, 'listings', listingId);
    await deleteDoc(listingRef);

    console.log(`[Admin Stock Delete] Owner ${verifiedUser.email} deleted entire stock listing ${listingId}`);

    return res.json({
      success: true,
      message: 'Stock listing deleted successfully',
      listingId
    });
  } catch (err: any) {
    console.error('Error in DELETE /api/admin/listings/:listingId:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to delete stock listing' });
  }
});

// Secure Admin Stock Management: Delete stock item (including Sold items)
app.delete('/api/admin/listings/:listingId/inventory/:itemId', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);

    const isAuthorized = Boolean(
      verifiedUser && (
        verifiedUser.isAdmin ||
        isAuthorizedOwnerEmail(verifiedUser.email) ||
        isAuthorizedOwnerUid(verifiedUser.uid) ||
        verifiedUser.email?.toLowerCase() === 'azeezmusharaf4@gmail.com'
      )
    );

    if (!isAuthorized) {
      return res.status(403).json({ success: false, error: 'Forbidden: Only authorized Admins can delete stock.' });
    }

    const { listingId, itemId } = req.params;
    if (!listingId || !itemId) {
      return res.status(400).json({ success: false, error: 'Listing ID and Item ID are required.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database not initialized.' });
    }

    // 1. Delete secure details subcollection doc
    try {
      const secureRef = doc(db, 'listings', listingId, 'inventory', itemId, 'secure', 'details');
      await deleteDoc(secureRef);
    } catch (e) {
      console.warn('Direct delete secure details doc notice:', e);
    }

    // 2. Delete inventory subcollection doc
    try {
      const itemRef = doc(db, 'listings', listingId, 'inventory', itemId);
      await deleteDoc(itemRef);
    } catch (e) {
      console.warn('Direct delete inventory doc notice:', e);
    }

    // 3. Update parent listing document
    const listingRef = doc(db, 'listings', listingId);
    const listingSnap = await getDoc(listingRef);
    let unusedCount = 0;
    if (listingSnap.exists()) {
      const listingData = listingSnap.data();
      const currentInventory = Array.isArray(listingData.inventory) ? listingData.inventory : [];
      const updatedInventory = currentInventory.filter((item: any) => item.id !== itemId);
      unusedCount = updatedInventory.filter((item: any) => (item.status || '').toLowerCase() !== 'sold').length;

      await updateDoc(listingRef, {
        stock: unusedCount,
        stockCount: unusedCount,
        status: unusedCount > 0 ? (listingData.status === 'reserved' ? 'reserved' : 'active') : 'sold',
        inventory: updatedInventory
      });
    }

    console.log(`[Admin Stock Delete] Admin ${verifiedUser.email} deleted stock item ${itemId} from listing ${listingId}`);

    return res.json({
      success: true,
      message: 'Stock item deleted successfully',
      remainingStock: unusedCount
    });
  } catch (err: any) {
    console.error('Error in DELETE /api/admin/listings/:listingId/inventory/:itemId:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to delete stock item' });
  }
});

// Secure Admin Stock Management: Update/Save stock item (including Sold/Release state)
app.post('/api/admin/listings/:listingId/inventory/:itemId', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);

    const isAuthorized = Boolean(
      verifiedUser && (
        verifiedUser.isAdmin ||
        isAuthorizedOwnerEmail(verifiedUser.email) ||
        isAuthorizedOwnerUid(verifiedUser.uid) ||
        verifiedUser.email?.toLowerCase() === 'azeezmusharaf4@gmail.com'
      )
    );

    if (!isAuthorized) {
      return res.status(403).json({ success: false, error: 'Forbidden: Only authorized Admins can edit stock.' });
    }

    const { listingId, itemId } = req.params;
    if (!listingId || !itemId) {
      return res.status(400).json({ success: false, error: 'Listing ID and Item ID are required.' });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database not initialized.' });
    }

    const body = req.body || {};
    const {
      accountEmail,
      accountPassword,
      recoveryInfo,
      twoFactorSecretKey,
      twoFactorBackupCodes,
      additionalInstructions,
      customFields,
      deliveryFields,
      status: targetStatus
    } = body;

    const normalizedStatus = (targetStatus === 'Sold' || targetStatus === 'sold') ? 'Sold' : 'Available';
    const isNowAvailable = normalizedStatus === 'Available';

    // 1. Update inventory subcollection doc
    const itemRef = doc(db, 'listings', listingId, 'inventory', itemId);
    const itemSnap = await getDoc(itemRef);
    const existingItemData = itemSnap.exists() ? itemSnap.data() : {};

    const updatedItemData: any = {
      ...existingItemData,
      id: itemId,
      status: normalizedStatus,
      updatedAt: new Date().toISOString()
    };

    if (isNowAvailable) {
      updatedItemData.soldTo = null;
      updatedItemData.orderId = null;
      updatedItemData.soldAt = null;
    }

    await setDoc(itemRef, updatedItemData, { merge: true });

    // 2. Update secure subcollection doc
    const secureRef = doc(db, 'listings', listingId, 'inventory', itemId, 'secure', 'details');
    await setDoc(secureRef, {
      id: itemId,
      accountEmail: accountEmail || '',
      accountPassword: accountPassword || '',
      notes: recoveryInfo || '',
      recoveryInfo: recoveryInfo || '',
      twoFactorSecretKey: twoFactorSecretKey || '',
      twoFactorBackupCodes: twoFactorBackupCodes || '',
      additionalInstructions: additionalInstructions || '',
      customFields: Array.isArray(customFields) ? customFields : [],
      deliveryFields: Array.isArray(deliveryFields) ? deliveryFields : [],
      status: normalizedStatus,
      updatedAt: new Date().toISOString()
    }, { merge: true });

    // 3. Update parent listing doc
    const listingRef = doc(db, 'listings', listingId);
    const listingSnap = await getDoc(listingRef);
    let unusedCount = 0;
    if (listingSnap.exists()) {
      const listingData = listingSnap.data();
      const currentInventory = Array.isArray(listingData.inventory) ? listingData.inventory : [];
      const updatedInventory = currentInventory.map((it: any) => {
        if (it.id === itemId) {
          return {
            ...it,
            ...updatedItemData,
            accountEmail: accountEmail || it.accountEmail || '',
            recoveryInfo: recoveryInfo || it.recoveryInfo || '',
            additionalInstructions: additionalInstructions || it.additionalInstructions || '',
            twoFactorSecretKey: twoFactorSecretKey || it.twoFactorSecretKey || '',
            twoFactorBackupCodes: twoFactorBackupCodes || it.twoFactorBackupCodes || '',
            customFields: Array.isArray(customFields) ? customFields : it.customFields,
            deliveryFields: Array.isArray(deliveryFields) ? deliveryFields : it.deliveryFields,
            status: normalizedStatus,
            soldTo: isNowAvailable ? null : (it.soldTo || null),
            orderId: isNowAvailable ? null : (it.orderId || null),
            soldAt: isNowAvailable ? null : (it.soldAt || null)
          };
        }
        return it;
      });

      unusedCount = updatedInventory.filter((it: any) => (it.status || '').toLowerCase() !== 'sold').length;

      await updateDoc(listingRef, {
        stock: unusedCount,
        stockCount: unusedCount,
        status: unusedCount > 0 ? (listingData.status === 'reserved' ? 'reserved' : 'active') : 'sold',
        inventory: updatedInventory
      });
    }

    console.log(`[Admin Stock Edit] Admin ${verifiedUser.email} updated stock item ${itemId} on listing ${listingId} (status: ${normalizedStatus})`);

    return res.json({
      success: true,
      message: 'Stock item updated successfully',
      status: normalizedStatus,
      remainingStock: unusedCount
    });
  } catch (err: any) {
    console.error('Error in POST /api/admin/listings/:listingId/inventory/:itemId:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to update stock item' });
  }
});

// Secure Admin Wallet Override & Adjustment API (Strictly restricted to Azeezmusharaf4@gmail.com)
const handleAdminWalletOverride = async (req: any, res: any) => {
  try {
    let body = req.body;
    if (typeof body === 'string') {
      try {
        body = JSON.parse(body);
      } catch {
        body = {};
      }
    } else if (!body || typeof body !== 'object') {
      if (req.rawBody) {
        try {
          body = JSON.parse(req.rawBody.toString('utf8'));
        } catch {
          body = {};
        }
      } else {
        body = {};
      }
    }

    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);

    const isVerifiedOwner = verifiedUser && (isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid));

    if (!isVerifiedOwner) {
      console.warn(`[Admin Wallet Override] Unauthorized override attempt blocked`);
      return res.status(403).json({
        success: false,
        error: 'Forbidden: Access Denied. Only authenticated Owners are authorized to access the Admin Wallet Override tool and adjustment endpoints.'
      });
    }

    const rawToken = authHeader && authHeader.startsWith('Bearer ') ? authHeader.substring(7).trim() : '';

    const targetUid = body.targetUid || req.query.targetUid || '';
    const targetEmail = body.targetEmail || req.query.targetEmail || '';
    const action = body.action || req.query.action || 'set';
    const amount = body.amount !== undefined ? body.amount : req.query.amount;
    const reason = (body.reason || req.query.reason || 'Manual Admin Wallet Balance Override').trim();

    if (!targetUid && !targetEmail) {
      return res.status(400).json({
        success: false,
        error: 'Target user ID or email is required for wallet balance override.'
      });
    }

    const numericAmount = Number(amount);
    if (isNaN(numericAmount) || numericAmount < 0) {
      return res.status(400).json({
        success: false,
        error: 'A valid non-negative amount must be specified.'
      });
    }

    if (!['set', 'add', 'deduct'].includes(action)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid action specified. Must be "set", "add", or "deduct".'
      });
    }

    // Resolve target user document in Firestore
    let resolvedUid = targetUid;
    let targetUserData: any = null;

    // 1. If rawToken is provided, try Firestore REST API with the admin's verified credentials
    if (rawToken && resolvedUid) {
      try {
        targetUserData = await restGetFirestoreDoc('users', resolvedUid, rawToken);
      } catch (restErr) {
        console.warn('[Admin Wallet Override] REST GET user warning:', restErr);
      }
    }

    // Fallback lookup via client SDK db
    if (!targetUserData && resolvedUid && db) {
      try {
        const userRef = doc(db, 'users', resolvedUid);
        const userSnap = await getDoc(userRef);
        if (userSnap.exists()) {
          targetUserData = userSnap.data();
        }
      } catch (dbErr) {
        console.warn('[Admin Wallet Override] Client SDK GET user warning:', dbErr);
      }
    }

    // Fallback lookup by email if UID was not found or if targetEmail provided
    if (!targetUserData && targetEmail && db) {
      try {
        const normalizedTargetEmail = targetEmail.trim().toLowerCase();
        const usersQ = query(collection(db, 'users'), where('email', '==', normalizedTargetEmail));
        const usersSnap = await getDocs(usersQ);
        if (!usersSnap.empty) {
          resolvedUid = usersSnap.docs[0].id;
          targetUserData = usersSnap.docs[0].data();
        }
      } catch (qErr) {
        console.warn('[Admin Wallet Override] User email query warning:', qErr);
      }
    }

    if (!resolvedUid) {
      return res.status(404).json({
        success: false,
        error: `Target user could not be found in Firestore database.`
      });
    }

    const rawPrev = targetUserData?.walletBalance !== undefined ? targetUserData?.walletBalance : targetUserData?.balance;
    const previousBalance = typeof rawPrev === 'number' ? rawPrev : (rawPrev ? Number(rawPrev) : 0);
    let newBalance = previousBalance;

    if (action === 'set') {
      newBalance = numericAmount;
    } else if (action === 'add') {
      newBalance = previousBalance + numericAmount;
    } else if (action === 'deduct') {
      newBalance = Math.max(0, previousBalance - numericAmount);
    }

    const resolvedEmail = targetUserData?.email || targetEmail || '';
    const txId = `OVERRIDE_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

    // Execute user document update with admin token or fallback to db
    let userUpdated = false;
    if (rawToken) {
      try {
        await restPatchFirestoreDoc('users', resolvedUid, {
          walletBalance: newBalance,
          balance: newBalance,
          lastWalletOverrideAt: new Date().toISOString(),
          lastWalletOverrideBy: 'Azeezmusharaf4@gmail.com',
          email: resolvedEmail || undefined,
          uid: resolvedUid
        }, rawToken);
        // Also mirror to wallets collection
        try {
          await restPatchFirestoreDoc('wallets', resolvedUid, {
            userId: resolvedUid,
            userEmail: resolvedEmail || undefined,
            walletBalance: newBalance,
            balance: newBalance,
            updatedAt: new Date().toISOString()
          }, rawToken);
        } catch {}
        userUpdated = true;
      } catch (restPatchErr) {
        console.warn('[Admin Wallet Override] REST PATCH user failed, trying client SDK:', restPatchErr);
      }
    }

    if (!userUpdated && db) {
      const userDocRef = doc(db, 'users', resolvedUid);
      const walletDocRef = doc(db, 'wallets', resolvedUid);
      if (targetUserData) {
        await updateDoc(userDocRef, {
          walletBalance: newBalance,
          balance: newBalance,
          lastWalletOverrideAt: new Date().toISOString(),
          lastWalletOverrideBy: 'Azeezmusharaf4@gmail.com'
        });
      } else {
        await setDoc(userDocRef, {
          uid: resolvedUid,
          walletBalance: newBalance,
          balance: newBalance,
          email: resolvedEmail,
          createdAt: new Date().toISOString(),
          lastWalletOverrideAt: new Date().toISOString(),
          lastWalletOverrideBy: 'Azeezmusharaf4@gmail.com'
        }, { merge: true });
      }

      await setDoc(walletDocRef, {
        userId: resolvedUid,
        userEmail: resolvedEmail,
        walletBalance: newBalance,
        balance: newBalance,
        updatedAt: new Date().toISOString()
      }, { merge: true }).catch(() => {});
    }

    // Record immutable audit entry in wallet_transactions ledger
    const txPayload = {
      id: txId,
      userId: resolvedUid,
      userEmail: resolvedEmail,
      amount: Math.abs(newBalance - previousBalance),
      previousBalance,
      newBalance,
      walletBalance: newBalance,
      balance: newBalance,
      action,
      type: action === 'deduct' ? 'deduction' : 'deposit',
      method: 'admin_wallet_override',
      status: 'successful',
      adminEmail: 'Azeezmusharaf4@gmail.com',
      reason: reason || 'Manual Admin Wallet Balance Override',
      date: new Date().toISOString(),
      createdAt: new Date().toISOString()
    };

    let txRecorded = false;
    if (rawToken) {
      try {
        await restCreateFirestoreDoc('wallet_transactions', txId, txPayload, rawToken);
        txRecorded = true;
      } catch (restTxErr) {
        console.warn('[Admin Wallet Override] REST CREATE tx failed, trying client SDK:', restTxErr);
      }
    }

    if (!txRecorded && db) {
      try {
        const txDocRef = doc(db, 'wallet_transactions', txId);
        await setDoc(txDocRef, txPayload);
      } catch (dbTxErr) {
        console.warn('[Admin Wallet Override] Client SDK setDoc tx notice:', dbTxErr);
      }
    }

    console.log(`[Admin Wallet Override] Success: ${verifiedUser?.email} updated user ${resolvedUid} (${resolvedEmail}) wallet from ₦${previousBalance} to ₦${newBalance} (action: ${action}, amount: ₦${numericAmount})`);

    return res.json({
      success: true,
      message: `Successfully overridden wallet balance for ${resolvedEmail || resolvedUid}. Updated from ₦${previousBalance.toLocaleString()} to ₦${newBalance.toLocaleString()}.`,
      targetUid: resolvedUid,
      targetEmail: resolvedEmail,
      previousBalance,
      newBalance,
      action,
      amount: numericAmount,
      txId
    });
  } catch (err: any) {
    console.error('Error in /api/admin/wallets/override:', err);
    return res.status(500).json({
      success: false,
      error: err.message || 'Internal error processing admin wallet override'
    });
  }
};

app.all('/api/admin/wallets/override', handleAdminWalletOverride);
app.all('/api/admin/wallets/adjust', handleAdminWalletOverride);
app.all('/api/admin/override-wallet', handleAdminWalletOverride);
app.all('/api/admin/wallet-override', handleAdminWalletOverride);
app.all('/api/admin/wallet/override', handleAdminWalletOverride);
app.all('/api/admin/wallet/adjust', handleAdminWalletOverride);

// Secure Admin Wallets Listing & Verification API
app.get('/api/admin/wallets', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const verifiedUser = await getVerifiedAuthUser(authHeader);

    const isVerifiedOwner = verifiedUser && (isAuthorizedOwnerEmail(verifiedUser.email) || isAuthorizedOwnerUid(verifiedUser.uid));
    if (!isVerifiedOwner) {
      return res.status(403).json({
        success: false,
        error: 'Forbidden: Access Denied. Only authenticated Owners are authorized to access /admin/wallets.'
      });
    }

    if (!db) {
      return res.status(500).json({ success: false, error: 'Database service not available' });
    }

    const usersSnap = await getDocs(collection(db, 'users'));
    const users = usersSnap.docs.map(d => ({
      uid: d.id,
      ...d.data()
    }));

    return res.json({
      success: true,
      authorized: true,
      adminEmail: 'Azeezmusharaf4@gmail.com',
      users
    });
  } catch (err: any) {
    console.error('Error in /api/admin/wallets:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. VirtualSMSNumbers Provider Configuration (Server-Side Proxy)
function getVirtualSMSNumbersConfig() {
  const candidates = [
    process.env.VSN_API_KEY,
    process.env.VIRTUALSMSNUMBERS_API_KEY,
    process.env.VIRTUAL_SMS_NUMBERS_API_KEY,
    process.env.VSN_KEY
  ];
  let apiKey = '';
  for (const c of candidates) {
    if (c && typeof c === 'string') {
      const clean = c.trim().replace(/^['"`]|['"`]$/g, '').trim();
      if (clean && clean !== 'undefined' && clean !== 'null' && !clean.startsWith('MY_')) {
        apiKey = clean;
        break;
      }
    }
  }
  const baseUrl = (process.env.VSN_BASE_URL || 'https://virtualsmsnumbers.com/api/v1').trim().replace(/\/+$/, '');
  const eurToNgnRate = Number(process.env.EUR_TO_NGN_RATE) || 1750;
  const markup = Number(process.env.DIGITAL_PRODUCT_MARKUP) || Number(process.env.VITE_DIGITAL_PRODUCT_MARKUP) || Number(process.env.VIRTUAL_NUMBER_MARKUP) || 500;
  return { apiKey, baseUrl, hasApiKey: Boolean(apiKey), eurToNgnRate, markup };
}

const getOneGridHubConfig = () => {
  const cfg = getVirtualSMSNumbersConfig();
  return { apiKey: cfg.apiKey, isRealKey: cfg.hasApiKey, markup: cfg.markup, oneGridBaseUrl: cfg.baseUrl };
};
const getOneGridHubApiKey = (): string => getVirtualSMSNumbersConfig().apiKey;
const isRealOneGridHubKey = (): boolean => getVirtualSMSNumbersConfig().hasApiKey;

// Interface for Virtual Number Marketplace Pricing Configuration
interface VirtualNumberPricingSettings {
  optionsCount: number; // 2 to 6 options (default 4)
  minMarkup: number; // Minimum markup in NGN (default 500)
  maxMarkup: number; // Maximum markup in NGN (default 4500)
  pricingStyle: 'natural' | 'clean' | 'tiered'; // default: 'natural'
}

let cachedPricingSettings: VirtualNumberPricingSettings = {
  optionsCount: 4,
  minMarkup: 500,
  maxMarkup: 4500,
  pricingStyle: 'natural'
};

async function getVirtualNumberPricingSettings(): Promise<VirtualNumberPricingSettings> {
  try {
    if (db) {
      const docRef = doc(db, 'system_settings', 'virtual_number_pricing');
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        const data = snap.data();
        cachedPricingSettings = {
          optionsCount: Math.min(Math.max(Number(data.optionsCount) || 4, 2), 6),
          minMarkup: Math.max(Number(data.minMarkup) || 500, 100),
          maxMarkup: Math.max(Number(data.maxMarkup) || 4500, 500),
          pricingStyle: data.pricingStyle || 'natural'
        };
      }
    }
  } catch (err) {
    console.warn('[VirtualNumberPricing] Fetch settings warning:', err);
  }
  return cachedPricingSettings;
}

// Comprehensive reference dictionary for all worldwide country codes, dial codes & standard IDs
const WORLD_COUNTRIES_MAP: Record<string, { name: string; code: string; flag?: string }> = {
  // Common numeric IDs in SMS APIs (SMS-Activate / OneGridHub / SMSHub)
  '0': { name: 'Russia', code: '+7' },
  '1': { name: 'Ukraine', code: '+380' },
  '2': { name: 'Kazakhstan', code: '+7' },
  '3': { name: 'China', code: '+86' },
  '4': { name: 'Philippines', code: '+63' },
  '5': { name: 'Myanmar', code: '+95' },
  '6': { name: 'Indonesia', code: '+62' },
  '7': { name: 'Malaysia', code: '+60' },
  '8': { name: 'Kenya', code: '+254' },
  '9': { name: 'Tanzania', code: '+255' },
  '10': { name: 'Vietnam', code: '+84' },
  '11': { name: 'Kyrgyzstan', code: '+996' },
  '12': { name: 'USA (Virtual)', code: '+1' },
  '13': { name: 'Israel', code: '+972' },
  '14': { name: 'Hong Kong', code: '+852' },
  '15': { name: 'Poland', code: '+48' },
  '16': { name: 'United Kingdom', code: '+44' },
  '17': { name: 'Madagascar', code: '+261' },
  '18': { name: 'Congo', code: '+242' },
  '19': { name: 'Nigeria', code: '+234' },
  '20': { name: 'Macao', code: '+853' },
  '21': { name: 'Egypt', code: '+20' },
  '22': { name: 'India', code: '+91' },
  '23': { name: 'Ireland', code: '+353' },
  '24': { name: 'Cambodia', code: '+855' },
  '25': { name: 'Laos', code: '+856' },
  '26': { name: 'Haiti', code: '+509' },
  '27': { name: 'Ivory Coast', code: '+225' },
  '28': { name: 'Gambia', code: '+220' },
  '29': { name: 'Serbia', code: '+381' },
  '30': { name: 'Yemen', code: '+967' },
  '31': { name: 'South Africa', code: '+27' },
  '32': { name: 'Romania', code: '+40' },
  '33': { name: 'Colombia', code: '+57' },
  '34': { name: 'Estonia', code: '+372' },
  '35': { name: 'Azerbaijan', code: '+994' },
  '36': { name: 'Canada', code: '+1' },
  '37': { name: 'Morocco', code: '+212' },
  '38': { name: 'Ghana', code: '+233' },
  '39': { name: 'Argentina', code: '+54' },
  '40': { name: 'Uzbekistan', code: '+998' },
  '41': { name: 'Cameroon', code: '+237' },
  '42': { name: 'Chad', code: '+235' },
  '43': { name: 'Germany', code: '+49' },
  '44': { name: 'Lithuania', code: '+370' },
  '45': { name: 'Croatia', code: '+385' },
  '46': { name: 'Sweden', code: '+46' },
  '47': { name: 'Iraq', code: '+964' },
  '48': { name: 'Netherlands', code: '+31' },
  '49': { name: 'Latvia', code: '+371' },
  '50': { name: 'Austria', code: '+43' },
  '51': { name: 'Belarus', code: '+375' },
  '52': { name: 'Thailand', code: '+66' },
  '53': { name: 'Saudi Arabia', code: '+966' },
  '54': { name: 'Mexico', code: '+52' },
  '55': { name: 'Taiwan', code: '+886' },
  '56': { name: 'Spain', code: '+34' },
  '57': { name: 'Algeria', code: '+213' },
  '58': { name: 'Slovenia', code: '+386' },
  '59': { name: 'Bangladesh', code: '+880' },
  '60': { name: 'Senegal', code: '+221' },
  '61': { name: 'Turkey', code: '+90' },
  '62': { name: 'Czech Republic', code: '+420' },
  '63': { name: 'Sri Lanka', code: '+94' },
  '64': { name: 'Peru', code: '+51' },
  '65': { name: 'Pakistan', code: '+92' },
  '66': { name: 'New Zealand', code: '+64' },
  '67': { name: 'Guinea', code: '+224' },
  '68': { name: 'Mali', code: '+223' },
  '69': { name: 'Venezuela', code: '+58' },
  '70': { name: 'Ethiopia', code: '+251' },
  '71': { name: 'Mongolia', code: '+976' },
  '72': { name: 'Brazil', code: '+55' },
  '73': { name: 'Afghanistan', code: '+93' },
  '74': { name: 'Uganda', code: '+256' },
  '75': { name: 'Angola', code: '+244' },
  '76': { name: 'Cyprus', code: '+357' },
  '77': { name: 'France', code: '+33' },
  '78': { name: 'Papua New Guinea', code: '+675' },
  '79': { name: 'Mozambique', code: '+258' },
  '80': { name: 'Nepal', code: '+977' },
  '81': { name: 'Belgium', code: '+32' },
  '82': { name: 'Bulgaria', code: '+359' },
  '83': { name: 'Hungary', code: '+36' },
  '84': { name: 'Moldova', code: '+373' },
  '85': { name: 'Italy', code: '+39' },
  '86': { name: 'Paraguay', code: '+595' },
  '87': { name: 'Honduras', code: '+504' },
  '88': { name: 'Tunisia', code: '+216' },
  '89': { name: 'Nicaragua', code: '+505' },
  '90': { name: 'Timor-Leste', code: '+670' },
  '91': { name: 'Bolivia', code: '+591' },
  '92': { name: 'Costa Rica', code: '+506' },
  '93': { name: 'Guatemala', code: '+502' },
  '94': { name: 'UAE', code: '+971' },
  '95': { name: 'Zimbabwe', code: '+263' },
  '96': { name: 'Puerto Rico', code: '+1' },
  '97': { name: 'Sudan', code: '+249' },
  '98': { name: 'Togo', code: '+228' },
  '99': { name: 'Kuwait', code: '+965' },
  '100': { name: 'El Salvador', code: '+503' },
  '101': { name: 'Libya', code: '+218' },
  '102': { name: 'Jamaica', code: '+1876' },
  '103': { name: 'Trinidad and Tobago', code: '+1868' },
  '104': { name: 'Ecuador', code: '+593' },
  '105': { name: 'Swaziland', code: '+268' },
  '106': { name: 'Oman', code: '+968' },
  '107': { name: 'Bosnia and Herzegovina', code: '+387' },
  '108': { name: 'Dominican Republic', code: '+1809' },
  '109': { name: 'Syria', code: '+963' },
  '110': { name: 'Qatar', code: '+974' },
  '111': { name: 'Panama', code: '+507' },
  '112': { name: 'Cuba', code: '+53' },
  '113': { name: 'Mauritania', code: '+222' },
  '114': { name: 'Sierra Leone', code: '+232' },
  '115': { name: 'Jordan', code: '+962' },
  '116': { name: 'Portugal', code: '+351' },
  '117': { name: 'Bahamas', code: '+1242' },
  '118': { name: 'Georgia', code: '+995' },
  '119': { name: 'Armenia', code: '+374' },
  '120': { name: 'Guyana', code: '+592' },
  '121': { name: 'Burundi', code: '+257' },
  '122': { name: 'Benin', code: '+229' },
  '123': { name: 'Brunei', code: '+673' },
  '124': { name: 'Bahrain', code: '+973' },
  '125': { name: 'Namibia', code: '+264' },
  '126': { name: 'Congo DR', code: '+243' },
  '127': { name: 'Rwanda', code: '+250' },
  '128': { name: 'Slovakia', code: '+421' },
  '129': { name: 'Lebanon', code: '+961' },
  '130': { name: 'Botswana', code: '+267' },
  '131': { name: 'Belize', code: '+501' },
  '132': { name: 'Central African Republic', code: '+236' },
  '133': { name: 'Chile', code: '+56' },
  '134': { name: 'Australia', code: '+61' },
  '135': { name: 'Somalia', code: '+252' },
  '136': { name: 'Zambia', code: '+260' },
  '137': { name: 'Guinea-Bissau', code: '+245' },
  '138': { name: 'Malawi', code: '+265' },
  '139': { name: 'Gabon', code: '+241' },
  '140': { name: 'Uruguay', code: '+598' },
  '141': { name: 'Equatorial Guinea', code: '+240' },
  '142': { name: 'Bhutan', code: '+975' },
  '143': { name: 'Maldives', code: '+960' },
  '144': { name: 'Suriname', code: '+597' },
  '145': { name: 'Norway', code: '+47' },
  '146': { name: 'Mauritius', code: '+230' },
  '147': { name: 'Denmark', code: '+45' },
  '148': { name: 'Finland', code: '+358' },
  '149': { name: 'Fiji', code: '+679' },
  '150': { name: 'Montenegro', code: '+382' },
  '151': { name: 'Malta', code: '+356' },
  '152': { name: 'North Macedonia', code: '+389' },
  '153': { name: 'Albania', code: '+355' },
  '154': { name: 'Greece', code: '+30' },
  '155': { name: 'Switzerland', code: '+41' },
  '156': { name: 'Singapore', code: '+65' },
  '157': { name: 'Japan', code: '+81' },
  '158': { name: 'South Korea', code: '+82' },
  '159': { name: 'Iceland', code: '+354' },
  '160': { name: 'Luxembourg', code: '+352' },
  '187': { name: 'United States', code: '+1' },
  '188': { name: 'Seychelles', code: '+248' },
  '189': { name: 'Dominica', code: '+1767' },
  '190': { name: 'Saint Lucia', code: '+1758' },
  '191': { name: 'Grenada', code: '+1473' },
  '192': { name: 'Saint Vincent', code: '+1784' },
  '193': { name: 'Barbados', code: '+1246' },
  '194': { name: 'Antigua and Barbuda', code: '+1268' },
  '195': { name: 'Saint Kitts and Nevis', code: '+1869' },

  // ISO-2 Codes
  'US': { name: 'United States', code: '+1' },
  'GB': { name: 'United Kingdom', code: '+44' },
  'UK': { name: 'United Kingdom', code: '+44' },
  'CA': { name: 'Canada', code: '+1' },
  'NG': { name: 'Nigeria', code: '+234' },
  'GH': { name: 'Ghana', code: '+233' },
  'KE': { name: 'Kenya', code: '+254' },
  'ZA': { name: 'South Africa', code: '+27' },
  'DE': { name: 'Germany', code: '+49' },
  'FR': { name: 'France', code: '+33' },
  'NL': { name: 'Netherlands', code: '+31' },
  'BR': { name: 'Brazil', code: '+55' },
  'IN': { name: 'India', code: '+91' },
  'PH': { name: 'Philippines', code: '+63' },
  'ID': { name: 'Indonesia', code: '+62' },
  'AU': { name: 'Australia', code: '+61' },
  'SE': { name: 'Sweden', code: '+46' },
  'IT': { name: 'Italy', code: '+39' },
  'ES': { name: 'Spain', code: '+34' },
  'PL': { name: 'Poland', code: '+48' },
  'UA': { name: 'Ukraine', code: '+380' },
  'RU': { name: 'Russia', code: '+7' },
  'CN': { name: 'China', code: '+86' },
  'JP': { name: 'Japan', code: '+81' },
  'KR': { name: 'South Korea', code: '+82' },
  'EG': { name: 'Egypt', code: '+20' },
  'MA': { name: 'Morocco', code: '+212' },
  'CO': { name: 'Colombia', code: '+57' },
  'AR': { name: 'Argentina', code: '+54' },
  'MX': { name: 'Mexico', code: '+52' },
  'TR': { name: 'Turkey', code: '+90' },
  'VN': { name: 'Vietnam', code: '+84' },
  'TH': { name: 'Thailand', code: '+66' },
  'MY': { name: 'Malaysia', code: '+60' },
  'SG': { name: 'Singapore', code: '+65' },
  'SA': { name: 'Saudi Arabia', code: '+966' },
  'AE': { name: 'United Arab Emirates', code: '+971' },
  'PK': { name: 'Pakistan', code: '+92' },
  'BD': { name: 'Bangladesh', code: '+880' },
  'NZ': { name: 'New Zealand', code: '+64' },
  'BE': { name: 'Belgium', code: '+32' },
  'CH': { name: 'Switzerland', code: '+41' },
  'AT': { name: 'Austria', code: '+43' },
  'NO': { name: 'Norway', code: '+47' },
  'DK': { name: 'Denmark', code: '+45' },
  'FI': { name: 'Finland', code: '+358' },
  'IE': { name: 'Ireland', code: '+353' },
  'PT': { name: 'Portugal', code: '+351' },
  'GR': { name: 'Greece', code: '+30' },
  'CZ': { name: 'Czech Republic', code: '+420' },
  'RO': { name: 'Romania', code: '+40' },
  'HU': { name: 'Hungary', code: '+36' },
  'IL': { name: 'Israel', code: '+972' },
  'HK': { name: 'Hong Kong', code: '+852' },
  'TW': { name: 'Taiwan', code: '+886' },
  'CL': { name: 'Chile', code: '+56' },
  'PE': { name: 'Peru', code: '+51' },
  'TZ': { name: 'Tanzania', code: '+255' },
  'UG': { name: 'Uganda', code: '+256' },
  'CM': { name: 'Cameroon', code: '+237' },
  'SN': { name: 'Senegal', code: '+221' },
  'CI': { name: 'Ivory Coast', code: '+225' }
};

// Helper: Normalize country item into standard format
const COUNTRY_NAME_TO_CODE: Record<string, string> = {
  'united kingdom': '+44',
  'uk': '+44',
  'great britain': '+44',
  'united states': '+1',
  'usa': '+1',
  'canada': '+1',
  'nigeria': '+234',
  'ghana': '+233',
  'south africa': '+27',
  'kenya': '+254',
  'germany': '+49',
  'france': '+33',
  'netherlands': '+31',
  'holland': '+31',
  'india': '+91',
  'philippines': '+63',
  'indonesia': '+62',
  'brazil': '+55',
  'australia': '+61',
  'russia': '+7',
  'ukraine': '+380',
  'egypt': '+20',
  'poland': '+48',
  'spain': '+34',
  'italy': '+39',
  'turkey': '+90',
  'china': '+86',
  'japan': '+81',
  'south korea': '+82',
  'vietnam': '+84',
  'thailand': '+66',
  'malaysia': '+60',
  'singapore': '+65',
  'mexico': '+52',
  'colombia': '+57',
  'argentina': '+54',
  'chile': '+56',
  'peru': '+51',
  'pakistan': '+92',
  'bangladesh': '+880',
  'saudi arabia': '+966',
  'united arab emirates': '+971',
  'uae': '+971',
  'israel': '+972',
  'sweden': '+46',
  'switzerland': '+41',
  'belgium': '+32',
  'austria': '+43',
  'portugal': '+351',
  'greece': '+30',
  'romania': '+40',
  'czech republic': '+420',
  'denmark': '+45',
  'finland': '+358',
  'norway': '+47',
  'ireland': '+353',
  'new zealand': '+64',
  'tanzania': '+255',
  'uganda': '+256',
  'algeria': '+213',
  'morocco': '+212',
  'ethiopia': '+251',
  'ivory coast': '+225',
  "cote d'ivoire": '+225',
  'cameroon': '+237',
  'senegal': '+221',
  'zimbabwe': '+263',
  'zambia': '+260',
  'rwanda': '+250',
  'angola': '+244',
  'mozambique': '+258',
  'madagascar': '+261',
  'congo': '+242',
  'drc': '+243',
  'democratic republic of the congo': '+243',
  'haiti': '+509',
  'cambodia': '+855',
  'myanmar': '+95',
  'sri lanka': '+94',
  'nepal': '+977',
  'afghanistan': '+93',
  'iraq': '+964',
  'iran': '+98',
  'jordan': '+962',
  'lebanon': '+961',
  'kuwait': '+965',
  'qatar': '+974',
  'oman': '+968',
  'bahrain': '+973',
  'yemen': '+967',
  'taiwan': '+886',
  'hong kong': '+852',
  'macao': '+853',
  'uzbekistan': '+998',
  'kazakhstan': '+7',
  'kyrgyzstan': '+996',
  'tajikistan': '+992',
  'turkmenistan': '+993',
  'azerbaijan': '+994',
  'armenia': '+374',
  'georgia': '+995',
  'cyprus': '+357',
  'croatia': '+385',
  'serbia': '+381',
  'slovenia': '+386',
  'slovakia': '+421',
  'hungary': '+36',
  'bulgaria': '+359',
  'lithuania': '+370',
  'latvia': '+371',
  'estonia': '+372',
  'belarus': '+375',
  'moldova': '+373',
  'albania': '+355',
  'bosnia': '+387',
  'north macedonia': '+389',
  'montenegro': '+382',
  'luxembourg': '+352',
  'iceland': '+354',
  'malta': '+356',
  'dominican republic': '+1',
  'jamaica': '+1',
  'trinidad and tobago': '+1',
  'bahamas': '+1',
  'barbados': '+1',
  'panama': '+507',
  'costa rica': '+506',
  'guatemala': '+502',
  'honduras': '+504',
  'el salvador': '+503',
  'nicaragua': '+505',
  'ecuador': '+593',
  'bolivia': '+591',
  'paraguay': '+595',
  'uruguay': '+598',
  'venezuela': '+58',
  'gambia': '+220',
  'guinea': '+224',
  'mali': '+223',
  'chad': '+235',
  'papua new guinea': '+675',
  'fiji': '+679',
  'mongolia': '+976'
};

function normalizeCountryEntry(rawId: string, rawName?: string, rawCode?: string): { id: string; name: string; code: string } {
  const cleanId = String(rawId || '').trim();
  const upperId = cleanId.toUpperCase();
  const dictMatch = WORLD_COUNTRIES_MAP[cleanId] || WORLD_COUNTRIES_MAP[upperId];

  let name = rawName ? String(rawName).trim() : (dictMatch?.name || cleanId);
  
  // Lookup code by country name first for highest accuracy
  const nameKey = name.toLowerCase().trim();
  let code = rawCode ? String(rawCode).trim() : (COUNTRY_NAME_TO_CODE[nameKey] || dictMatch?.code || '');

  // If name is still just the numeric ID, look up by dictionary
  if ((/^\d+$/.test(name) || !name) && dictMatch) {
    name = dictMatch.name;
    if (!code) {
      const fallbackKey = name.toLowerCase().trim();
      code = COUNTRY_NAME_TO_CODE[fallbackKey] || dictMatch.code;
    }
  }
  if (!code && dictMatch) {
    code = dictMatch.code;
  }
  if (code && !code.startsWith('+') && /^\d+$/.test(code)) {
    code = `+${code}`;
  }

  return {
    id: cleanId,
    name: name || cleanId,
    code: code || ''
  };
}

// Validates whether a candidate code is an error message or non-OTP string
function isInvalidOtpCode(val?: string | null): boolean {
  if (!val) return true;
  const s = String(val).trim().toLowerCase();
  if (s.length === 0) return true;

  const invalidTokens = [
    'unauthorized',
    'error',
    'failed',
    'failure',
    'cancelled',
    'canceled',
    'expired',
    'not_found',
    'not found',
    'waiting',
    'pending',
    'waiting_for_sms',
    'status_wait_code',
    'status_cancel',
    'access_denied',
    'bad_request',
    'timeout',
    'unknown',
    'invalid',
    'invalid_key',
    'forbidden',
    '401',
    '403',
    '500',
    '502',
    '503',
    '504',
    'null',
    'undefined',
    'none',
    'true',
    'false',
    'ok',
    'success'
  ];

  if (invalidTokens.includes(s)) return true;
  if (s.includes('unauthorized') || s.includes('auth') || s.includes('forbidden')) return true;
  if (s.startsWith('status_') || s.startsWith('error_')) return true;
  return false;
}

// Validates whether a code is a genuine carrier verification code
function isValidOtpCode(val?: string | null): boolean {
  if (!val) return false;
  if (isInvalidOtpCode(val)) return false;
  const clean = String(val).trim();
  return clean.length >= 3 && clean.length <= 12;
}

// Resolves accurate country metadata using phone number prefix as gold standard
function resolveCountryDetails(countryIdOrName?: string, phoneNumber?: string): { id: string; name: string; code: string; flag: string } {
  if (phoneNumber) {
    const clean = String(phoneNumber).replace(/[^\d+]/g, '');
    const digits = clean.startsWith('+') ? clean.slice(1) : clean;

    if (digits.startsWith('1') && digits.length >= 11) {
      return { id: 'US', name: 'United States', code: '+1', flag: '🇺🇸' };
    }
    if (digits.startsWith('44')) {
      return { id: 'GB', name: 'United Kingdom', code: '+44', flag: '🇬🇧' };
    }
    if (digits.startsWith('234')) {
      return { id: 'NG', name: 'Nigeria', code: '+234', flag: '🇳🇬' };
    }
    if (digits.startsWith('233')) {
      return { id: 'GH', name: 'Ghana', code: '+233', flag: '🇬🇭' };
    }
    if (digits.startsWith('254')) {
      return { id: 'KE', name: 'Kenya', code: '+254', flag: '🇰🇪' };
    }
    if (digits.startsWith('27')) {
      return { id: 'ZA', name: 'South Africa', code: '+27', flag: '🇿🇦' };
    }
    if (digits.startsWith('49')) {
      return { id: 'DE', name: 'Germany', code: '+49', flag: '🇩🇪' };
    }
    if (digits.startsWith('33')) {
      return { id: 'FR', name: 'France', code: '+33', flag: '🇫🇷' };
    }
    if (digits.startsWith('91')) {
      return { id: 'IN', name: 'India', code: '+91', flag: '🇮🇳' };
    }
    if (digits.startsWith('55')) {
      return { id: 'BR', name: 'Brazil', code: '+55', flag: '🇧🇷' };
    }
    if (digits.startsWith('61')) {
      return { id: 'AU', name: 'Australia', code: '+61', flag: '🇦🇺' };
    }
    if (digits.startsWith('31')) {
      return { id: 'NL', name: 'Netherlands', code: '+31', flag: '🇳🇱' };
    }
    if (digits.startsWith('380')) {
      return { id: 'UA', name: 'Ukraine', code: '+380', flag: '🇺🇦' };
    }
    if (digits.startsWith('48')) {
      return { id: 'PL', name: 'Poland', code: '+48', flag: '🇵🇱' };
    }
    if (digits.startsWith('62')) {
      return { id: 'ID', name: 'Indonesia', code: '+62', flag: '🇮🇩' };
    }
    if (digits.startsWith('63')) {
      return { id: 'PH', name: 'Philippines', code: '+63', flag: '🇵🇭' };
    }
    if (digits.startsWith('84')) {
      return { id: 'VN', name: 'Vietnam', code: '+84', flag: '🇻🇳' };
    }
    if (digits.startsWith('60')) {
      return { id: 'MY', name: 'Malaysia', code: '+60', flag: '🇲🇾' };
    }
    if (digits.startsWith('7')) {
      return { id: 'RU', name: 'Russia', code: '+7', flag: '🇷🇺' };
    }
  }

  const c = String(countryIdOrName || '').toLowerCase().trim();
  if (c === '187' || c === 'us' || c === 'usa' || c === '1' || c.includes('united states') || c === 'america') {
    return { id: 'US', name: 'United States', code: '+1', flag: '🇺🇸' };
  }
  if (c === 'gb' || c === 'uk' || c === 'england' || c.includes('united kingdom') || c.includes('england') || c === '2' || c === '16') {
    return { id: 'GB', name: 'United Kingdom', code: '+44', flag: '🇬🇧' };
  }
  if (c === 'ng' || c.includes('nigeria') || c === '14') {
    return { id: 'NG', name: 'Nigeria', code: '+234', flag: '🇳🇬' };
  }
  if (c === 'ca' || c.includes('canada') || c === '36') {
    return { id: 'CA', name: 'Canada', code: '+1', flag: '🇨🇦' };
  }
  if (c === 'gh' || c.includes('ghana') || c === '42') {
    return { id: 'GH', name: 'Ghana', code: '+233', flag: '🇬🇭' };
  }
  if (c === 'za' || c.includes('south africa') || c === '153') {
    return { id: 'ZA', name: 'South Africa', code: '+27', flag: '🇿🇦' };
  }
  if (c === 'de' || c.includes('germany') || c === '43') {
    return { id: 'DE', name: 'Germany', code: '+49', flag: '🇩🇪' };
  }
  if (c === 'fr' || c.includes('france') || c === '78') {
    return { id: 'FR', name: 'France', code: '+33', flag: '🇫🇷' };
  }
  if (c === 'in' || c.includes('india') || c === '22') {
    return { id: 'IN', name: 'India', code: '+91', flag: '🇮🇳' };
  }
  if (c === 'br' || c.includes('brazil') || c === '73') {
    return { id: 'BR', name: 'Brazil', code: '+55', flag: '🇧🇷' };
  }
  if (c === 'au' || c.includes('australia')) {
    return { id: 'AU', name: 'Australia', code: '+61', flag: '🇦🇺' };
  }
  if (c === 'ke' || c.includes('kenya') || c === '8') {
    return { id: 'KE', name: 'Kenya', code: '+254', flag: '🇰🇪' };
  }
  if (c === 'nl' || c.includes('netherlands') || c === '48') {
    return { id: 'NL', name: 'Netherlands', code: '+31', flag: '🇳🇱' };
  }

  const titleName = countryIdOrName ? countryIdOrName.charAt(0).toUpperCase() + countryIdOrName.slice(1) : 'International';
  return {
    id: countryIdOrName || 'INT',
    name: titleName,
    code: '',
    flag: '🌐'
  };
}

// Generate multiple buying price options from ONE provider cost
function generateVirtualNumberPriceOptions(
  providerCost: number,
  settings: VirtualNumberPricingSettings,
  isOwner: boolean
) {
  const pCost = Math.round(Number(providerCost) || 0);
  if (pCost <= 0) return [];

  const count = Math.min(Math.max(Number(settings.optionsCount) || 4, 2), 6);
  const minMarkup = Math.max(Number(settings.minMarkup) || 500, 100);
  const maxMarkup = Math.max(Number(settings.maxMarkup) || 4500, minMarkup + 300);

  const defaultTiers = [
    { id: 'opt_1', name: 'Standard Line', badge: 'Popular', desc: 'Direct carrier routing' },
    { id: 'opt_2', name: 'Fast Priority', badge: 'Fast', desc: 'High delivery speed' },
    { id: 'opt_3', name: 'Express Route', badge: 'High Delivery', desc: 'Optimized instant queue' },
    { id: 'opt_4', name: 'VIP Dedicated', badge: 'Top Tier', desc: 'Premium carrier channel' },
    { id: 'opt_5', name: 'Enterprise Line', badge: 'Ultra Fast', desc: 'Dedicated carrier route' },
    { id: 'opt_6', name: 'Direct Priority Carrier', badge: 'Exclusive', desc: 'Instant OTP guarantee route' }
  ];

  const options = [];
  const step = count > 1 ? (maxMarkup - minMarkup) / (count - 1) : 0;

  for (let i = 0; i < count; i++) {
    const rawMarkup = minMarkup + (step * i);

    let calculatedMarkup = rawMarkup;
    if (settings.pricingStyle === 'natural' || !settings.pricingStyle) {
      // Natural non-monotonous variation (e.g., ₦2,350, ₦3,420, ₦4,890, ₦6,250)
      const offsets = [50, 120, 90, 50, 80, 40];
      const offset = offsets[i % offsets.length] || 50;
      calculatedMarkup = Math.max(minMarkup, Math.round(rawMarkup / 10) * 10 + offset);
    } else if (settings.pricingStyle === 'clean') {
      calculatedMarkup = Math.max(minMarkup, Math.round(rawMarkup / 100) * 100);
    } else {
      calculatedMarkup = Math.max(minMarkup, Math.round(rawMarkup / 50) * 50);
    }

    const customerPrice = pCost + calculatedMarkup;
    const tierMeta = defaultTiers[i] || {
      id: `opt_${i + 1}`,
      name: `Option ${i + 1}`,
      badge: 'Available',
      desc: 'Carrier route'
    };

    const opt: any = {
      optionId: tierMeta.id,
      tierIndex: i,
      tierName: tierMeta.name,
      badge: tierMeta.badge,
      description: tierMeta.desc,
      customerPrice,
      currency: 'NGN'
    };

    if (isOwner) {
      opt.providerCost = pCost;
      opt.markup = calculatedMarkup;
      opt.profit = calculatedMarkup;
      opt.marginPercent = Math.round((calculatedMarkup / customerPrice) * 100);
    }

    options.push(opt);
  }

  return options;
}

// Fallback helper for legacy single-price lookups
function calculateZenetPrice(providerPrice: number): { markup: number; customerPrice: number } {
  const providerCost = Math.round(Number(providerPrice) || 0);
  if (providerCost <= 0) {
    return { markup: 0, customerPrice: 0 };
  }
  const markup = providerCost < 1000 ? 500 : providerCost <= 2000 ? 700 : 1000;
  const customerPrice = providerCost + markup;
  return { markup, customerPrice };
}

// In-memory cache for virtual numbers servers, countries, and services to prevent upstream timeouts and ensure high availability
interface CachedVirtualEntry<T> {
  timestamp: number;
  data: T;
}
const cachedCountriesByServer = new Map<string, CachedVirtualEntry<any[]>>();
let cachedServersList: CachedVirtualEntry<any[]> | null = null;
const cachedServicesByServerCountry = new Map<string, CachedVirtualEntry<any[]>>();

const handleOneGridHubRequest = async (req: express.Request, res: express.Response, explicitAction?: string) => {
  return handleVirtualSMSNumbersGateway(req, res, db, firebaseProjectId, verifyFirebaseIdToken, explicitAction);
};

const _legacy_unused_handleOneGridHubRequest = async (req: express.Request, res: express.Response, explicitAction?: string) => {
  res.setHeader('Content-Type', 'application/json');
  try {
    const method = req.method;
    const action = (explicitAction || req.query.action || req.body.action || '').toString().toLowerCase();

    if (!action) {
      return res.status(400).json({ success: false, error: 'Action parameter or subpath is required (e.g. servers, countries, services, price, buy, status, cancel, orders, webhook).' });
    }

    const { apiKey, isRealKey, oneGridBaseUrl } = getOneGridHubConfig();

    // Check if the authenticated caller is the primary ZENET HUB Owner
    const isOwnerRequest = async (): Promise<boolean> => {
      try {
        const authHeader = req.headers.authorization;
        let authUid = authHeader ? verifyFirebaseIdToken(authHeader, firebaseProjectId) : null;
        if (!authUid) {
          authUid = (req.body?.userId || req.query?.userId || '').toString() || null;
        }
        const emailCandidate = (req.body?.callerEmail || req.query?.callerEmail || req.body?.userEmail || req.query?.userEmail || '').toString().toLowerCase().trim();
        if (isAuthorizedOwnerEmail(emailCandidate) || (authUid && isAuthorizedOwnerUid(authUid))) {
          return true;
        }
        if (authUid && db) {
          const userRef = doc(db, 'users', authUid);
          const userSnap = await getDoc(userRef);
          if (userSnap.exists()) {
            const udata = userSnap.data();
            const uemail = (udata.email || '').toString().toLowerCase().trim();
            if (isAuthorizedOwnerEmail(uemail) || isAuthorizedOwnerUid(udata.uid) || udata.role === 'owner') {
              return true;
            }
          }
        }
      } catch (err) {
        console.error('[OneGridHub] isOwnerRequest check warning:', err);
      }
      return false;
    };

    // Server normalization helper matching real OneGridHub server identifiers
    const normalizeServerId = (srv?: string): string => {
      if (!srv) return 'all1';
      const s = srv.toLowerCase().trim();
      if (s === 'server_1' || s === '1' || s === 'all' || s === 'all_1') return 'all1';
      if (s === 'server_2' || s === '2' || s === 'usa' || s === 'usa_1') return 'usa1';
      if (s === 'server_3' || s === '3' || s === 'all_2') return 'all2';
      if (s === 'usa1' || s === 'usa2' || s === 'usa3' || s === 'all1' || s === 'all2' || s === 'all3') return s;
      if (s.startsWith('usa')) return 'usa1';
      if (s.startsWith('all')) return 'all1';
      return 'all1';
    };

    // Standard high availability fallback list for servers and countries
    const defaultServers = [
      { id: 'all1', name: 'Global Server 1 (All Countries)', region: 'Global' },
      { id: 'all2', name: 'Global Server 2 (All Countries)', region: 'Global' },
      { id: 'all3', name: 'Global Server 3 (All Countries)', region: 'Global' },
      { id: 'usa1', name: 'USA Server 1', region: 'USA' },
      { id: 'usa2', name: 'USA Server 2', region: 'USA' },
      { id: 'usa3', name: 'USA Server 3', region: 'USA' }
    ];

    const defaultCountries = [
      { id: '187', name: 'United States', code: '+1' },
      { id: '2', name: 'United Kingdom', code: '+44' },
      { id: '36', name: 'Canada', code: '+1' },
      { id: '14', name: 'Nigeria', code: '+234' },
      { id: '31', name: 'South Africa', code: '+27' },
      { id: '8', name: 'Kenya', code: '+254' },
      { id: '38', name: 'Ghana', code: '+233' },
      { id: '43', name: 'Germany', code: '+49' },
      { id: '77', name: 'France', code: '+33' },
      { id: '48', name: 'Netherlands', code: '+31' },
      { id: '73', name: 'Brazil', code: '+55' },
      { id: '22', name: 'India', code: '+91' },
      { id: '4', name: 'Philippines', code: '+63' },
      { id: '6', name: 'Indonesia', code: '+62' },
      { id: '61', name: 'Australia', code: '+61' },
      { id: '21', name: 'Egypt', code: '+20' },
      { id: '15', name: 'Poland', code: '+48' },
      { id: '86', name: 'Italy', code: '+39' },
      { id: '56', name: 'Spain', code: '+34' },
      { id: '62', name: 'Turkey', code: '+90' },
      { id: '54', name: 'Mexico', code: '+52' },
      { id: '33', name: 'Colombia', code: '+57' },
      { id: '39', name: 'Argentina', code: '+54' },
      { id: '46', name: 'Sweden', code: '+46' },
      { id: '181', name: 'Switzerland', code: '+41' }
    ];

    const getStandardServiceName = (serviceId: string, rawName?: string): string => {
      if (rawName && rawName.trim().length > 0 && rawName.toLowerCase() !== serviceId.toLowerCase()) {
        return rawName;
      }
      const map: Record<string, string> = {
        wa: 'WhatsApp & WA Business',
        whatsapp: 'WhatsApp & WA Business',
        tg: 'Telegram',
        telegram: 'Telegram',
        go: 'Google / Gmail / YouTube',
        gm: 'Google / Gmail / YouTube',
        google: 'Google / Gmail / YouTube',
        oi: 'OpenAI / ChatGPT',
        dr: 'OpenAI / ChatGPT',
        openai: 'OpenAI / ChatGPT',
        chatgpt: 'OpenAI / ChatGPT',
        ig: 'Instagram & Threads',
        instagram: 'Instagram & Threads',
        fb: 'Facebook & Messenger',
        facebook: 'Facebook & Messenger',
        tw: 'Twitter / X',
        twitter: 'Twitter / X',
        x: 'Twitter / X',
        tk: 'TikTok',
        lf: 'TikTok',
        tiktok: 'TikTok',
        nf: 'Netflix',
        netflix: 'Netflix',
        am: 'Amazon',
        amazon: 'Amazon',
        mt: 'Steam',
        steam: 'Steam',
        ds: 'Discord',
        discord: 'Discord',
        ub: 'Uber & UberEats',
        uber: 'Uber & UberEats',
        ts: 'PayPal Verification',
        paypal: 'PayPal Verification',
        wx: 'Apple / iCloud',
        apple: 'Apple / iCloud',
        fu: 'Snapchat',
        snapchat: 'Snapchat',
        wb: 'Binance / Crypto',
        binance: 'Binance / Crypto',
        mm: 'Microsoft / Outlook / Azure',
        microsoft: 'Microsoft / Outlook / Azure',
        tinder: 'Tinder / Match',
        li: 'LinkedIn',
        linkedin: 'LinkedIn',
        vi: 'Viber',
        viber: 'Viber',
        yh: 'Yahoo / AOL',
        yahoo: 'Yahoo / AOL'
      };
      return map[serviceId.toLowerCase()] || rawName || serviceId.toUpperCase();
    };

    // Helper to query OneGridHub API directly with full parameter serialization
    const queryOneGridHub = async (endpoint: string, queryParams: Record<string, string> = {}, reqMethod: string = 'GET', reqBody?: any) => {
      if (!apiKey) return null;

      const serverId = normalizeServerId(queryParams.server || queryParams.server_id);
      const params: Record<string, string> = {
        endpoint,
        server: serverId,
        api_key: apiKey,
        ...queryParams
      };

      // Remove undefined/empty params
      Object.keys(params).forEach(k => {
        if (params[k] === undefined || params[k] === '') {
          delete params[k];
        }
      });

      const qParams = new URLSearchParams(params).toString();
      const directUrl = `${oneGridBaseUrl}?${qParams}`;
      const headers: Record<string, string> = {
        'Accept': 'application/json, text/plain, */*',
        'User-Agent': 'ZENET-Hub-Gateway/1.0',
        'Authorization': `Bearer ${apiKey}`
      };

      try {
        let resp: Response;
        if (reqMethod === 'POST') {
          resp = await fetch(directUrl, {
            method: 'POST',
            headers: {
              ...headers,
              'Content-Type': 'application/json'
            },
            body: reqBody ? JSON.stringify(reqBody) : undefined,
            signal: AbortSignal.timeout(15000)
          });
        } else {
          resp = await fetch(directUrl, {
            method: 'GET',
            headers,
            signal: AbortSignal.timeout(15000)
          });
        }

        if (resp.status === 401 || resp.status === 403) {
          console.warn(`[OneGridHub Query] Upstream returned HTTP ${resp.status} Unauthorized for "${endpoint}".`);
          return {
            status: 'error',
            isApiError: true,
            httpStatus: resp.status,
            error: 'Provider API authentication failed (unauthorized). Please verify the provider API key.',
            message: 'Provider API authentication failed (unauthorized).'
          };
        }

        const text = await resp.text();
        if (!text || text.trim() === '') return null;

        const trimmed = text.trim();
        const lowerTrimmed = trimmed.toLowerCase();

        // Catch raw unauthorized or error responses
        if (lowerTrimmed === 'unauthorized' || lowerTrimmed.includes('unauthorized') || lowerTrimmed.includes('invalid_api_key')) {
          return {
            status: 'error',
            isApiError: true,
            httpStatus: 401,
            error: 'Provider API authentication failed (unauthorized).',
            message: 'Provider API authentication failed (unauthorized).'
          };
        }

        if (trimmed.startsWith('ACCESS_NUMBER:') || trimmed.startsWith('STATUS_') || trimmed.startsWith('ACCESS_BALANCE:')) {
          return { rawText: trimmed };
        }

        try {
          const parsed = JSON.parse(trimmed);
          if (parsed && (parsed.status === 'error' || parsed.error || parsed.code === 'unauthorized' || String(parsed.message || '').toLowerCase().includes('unauthorized'))) {
            parsed.isApiError = true;
          }
          return parsed;
        } catch {
          return { rawText: trimmed };
        }
      } catch (err: any) {
        const isTimeout = err?.name === 'TimeoutError' || err?.message?.includes('timeout') || err?.code === 'UND_ERR_CONNECT_TIMEOUT';
        if (isTimeout) {
          console.log(`[OneGridHub Query] Upstream note: query for "${endpoint}" timed out (using high-availability cached fallback).`);
        } else {
          console.log(`[OneGridHub Query] Upstream note on ${endpoint}:`, err?.message || err);
        }
        return null;
      }
    };

    // Helper to retrieve live provider cost for a specific country/service from real OneGridHub API
    const getLiveProviderCost = async (server: string, country: string, service: string): Promise<number | null> => {
      const serverId = normalizeServerId(server);
      if (!apiKey || !country || !service) return null;

      try {
        const priceData = await queryOneGridHub('price', {
          server: serverId,
          country: country.trim(),
          service: service.trim()
        });

        if (priceData && priceData.status === 'success' && priceData.price) {
          const raw = Number(priceData.price);
          if (!isNaN(raw) && raw > 0) {
            return raw;
          }
        }

        // Secondary fallback check if price is under cost or amount
        if (priceData && (priceData.cost || priceData.amount || priceData.rate)) {
          const raw = Number(priceData.cost || priceData.amount || priceData.rate);
          if (!isNaN(raw) && raw > 0) {
            return raw;
          }
        }

        return null;
      } catch (err) {
        console.error(`[OneGridHub Price] Exception fetching price (${serverId}/${country}/${service}):`, err);
        return null;
      }
    };

    // --- ENFORCE USER AUTHENTICATION ON STATEFUL ACTIONS ---
    const statefulActions = ['buy', 'cancel', 'status', 'orders'];
    if (statefulActions.includes(action)) {
      const authHeader = req.headers.authorization;
      let authUid = authHeader ? verifyFirebaseIdToken(authHeader, firebaseProjectId) : null;
      if (!authUid) {
        authUid = (req.body?.userId || req.query?.userId || '').toString() || null;
      }
      if (!authUid) {
        return res.status(401).json({ success: false, error: 'Unauthorized: Valid user authentication is required.' });
      }
      (req as any).authUid = authUid;
    }

    // --- 1. WEBHOOK ENDPOINT (Real-time incoming SMS from OneGridHub) ---
    if (action === 'webhook') {
      console.log('[OneGridHub Webhook] Incoming push notification:', req.body || req.query);
      if (!db) {
        return res.status(500).json({ success: false, error: 'Database not initialized' });
      }

      const payload = { ...req.query, ...req.body };
      const providerActivationId = (payload.activationId || payload.activation_id || payload.id || payload.order_id || payload.order_ref || '').toString();
      const code = (payload.code || payload.otp || payload.sms_code || '').toString();
      const smsText = (payload.text || payload.sms || payload.message || '').toString();
      const statusUpper = (payload.status || '').toString().toUpperCase();

      if (providerActivationId) {
        let orderDocToUpdate: any = null;
        let orderDocId = '';

        const q = query(collection(db, 'virtual_number_orders'), where('providerActivationId', '==', providerActivationId));
        const snap = await getDocs(q);
        if (!snap.empty) {
          orderDocToUpdate = snap.docs[0].data();
          orderDocId = snap.docs[0].id;
        } else {
          const directRef = doc(db, 'virtual_number_orders', providerActivationId);
          const directSnap = await getDoc(directRef);
          if (directSnap.exists()) {
            orderDocToUpdate = directSnap.data();
            orderDocId = directSnap.id;
          }
        }

        if (orderDocId && orderDocToUpdate) {
          const updates: any = {
            updatedAt: new Date().toISOString()
          };

          if (code || statusUpper === 'SMS_RECEIVED' || statusUpper === 'STATUS_OK' || statusUpper === 'SUCCESS') {
            updates.status = 'sms_received';
            if (code) updates.code = code;
            if (smsText) updates.smsText = smsText;
            console.log(`[OneGridHub Webhook] Updated order ${orderDocId} with delivered code: ${code}`);
          } else if (statusUpper === 'CANCELLED') {
            updates.status = 'cancelled';
          } else if (statusUpper === 'EXPIRED') {
            updates.status = 'expired';
          }

          await updateDoc(doc(db, 'virtual_number_orders', orderDocId), updates);
        }
      }

      return res.json({ success: true, received: true });
    }

    // --- 2. GET REQUESTS ---
    if (method === 'GET') {
      // 2a. SERVERS
      if (action === 'servers') {
        const now = Date.now();
        if (cachedServersList && (now - cachedServersList.timestamp < 3600 * 1000)) {
          return res.json(cachedServersList.data);
        }

        if (isRealKey) {
          try {
            const data = await queryOneGridHub('servers');
            if (data && data.status === 'success' && Array.isArray(data.servers) && data.servers.length > 0) {
              const normalizedServers = data.servers.map((s: any) => ({
                id: s.id,
                name: s.label || s.name || `${s.region || 'Server'} (${s.id})`,
                region: s.region || (s.id.startsWith('usa') ? 'USA' : 'Global')
              }));
              cachedServersList = { timestamp: now, data: normalizedServers };
              return res.json(normalizedServers);
            }
          } catch (serversErr: any) {
            console.log('[OneGridHub] Servers fetch note:', serversErr?.message || serversErr);
          }
        }
        cachedServersList = { timestamp: now, data: defaultServers };
        return res.json(defaultServers);
      }

      // 2b. COUNTRIES
      if (action === 'countries') {
        const rawServer = (req.query.server || '').toString();
        const server = normalizeServerId(rawServer);
        const now = Date.now();

        // 1. Instant return if in fresh cache (< 2 hours)
        const cached = cachedCountriesByServer.get(server);
        if (cached && (now - cached.timestamp < 2 * 3600 * 1000)) {
          return res.json(cached.data);
        }

        if (isRealKey) {
          try {
            const data = await queryOneGridHub('countries', { server });
            if (data && data.status === 'success' && Array.isArray(data.countries)) {
              const countryMap = new Map<string, { id: string; name: string; code?: string }>();

              data.countries.forEach((item: any) => {
                const rawId = (item.id || '').toString();
                const rawName = (item.name || '').toString();
                const rawCode = (item.code || '').toString();

                if (rawId && rawName) {
                  const normalized = normalizeCountryEntry(rawId, rawName, rawCode);
                  if (normalized.id && !countryMap.has(normalized.id)) {
                    countryMap.set(normalized.id, normalized);
                  }
                }
              });

              const normalizedCountries = Array.from(countryMap.values());
              if (normalizedCountries.length > 0) {
                // Priority ordering for primary regions: USA, UK, Canada, Nigeria, Ghana, South Africa, etc.
                const priorityOrder = ['1', '187', 'US', '2', 'GB', '36', 'CA', '14', 'NG', '38', 'GH', '31', 'ZA', '8', 'KE', '43', 'DE', '77', 'FR'];
                const priorityNames = ['united states', 'united kingdom', 'canada', 'nigeria', 'ghana', 'south africa', 'germany', 'france', 'netherlands', 'india', 'brazil', 'australia'];
                normalizedCountries.sort((a, b) => {
                  const pA = priorityOrder.indexOf(a.id);
                  const pB = priorityOrder.indexOf(b.id);
                  if (pA !== -1 && pB !== -1) return pA - pB;
                  if (pA !== -1) return -1;
                  if (pB !== -1) return 1;

                  const nA = priorityNames.indexOf(a.name.toLowerCase().trim());
                  const nB = priorityNames.indexOf(b.name.toLowerCase().trim());
                  if (nA !== -1 && nB !== -1) return nA - nB;
                  if (nA !== -1) return -1;
                  if (nB !== -1) return 1;

                  return a.name.localeCompare(b.name);
                });

                cachedCountriesByServer.set(server, { timestamp: now, data: normalizedCountries });
                return res.json(normalizedCountries);
              }
            }
          } catch (countriesErr: any) {
            console.log('[OneGridHub] Countries fetch notice:', countriesErr?.message || countriesErr);
          }
        }

        // If upstream timed out or was temporarily unavailable, check for existing cached data
        if (cached && cached.data.length > 0) {
          return res.json(cached.data);
        }

        // Return rich default countries and cache to prevent repeated waits
        cachedCountriesByServer.set(server, { timestamp: now, data: defaultCountries });
        return res.json(defaultCountries);
      }

      // 2c. SERVICES
      if (action === 'services') {
        const rawServer = (req.query.server || '').toString();
        const server = normalizeServerId(rawServer);
        const country = (req.query.country || '').toString();
        const cacheKey = `${server}_${country}`;
        const now = Date.now();

        const cached = cachedServicesByServerCountry.get(cacheKey);
        if (cached && (now - cached.timestamp < 30 * 60 * 1000)) {
          return res.json(cached.data);
        }

        if (isRealKey) {
          try {
            const data = await queryOneGridHub('services', { server, country });
            if (data && data.status === 'success' && Array.isArray(data.services)) {
              const serviceMap = new Map<string, { id: string; name: string; price?: number }>();

              data.services.forEach((s: any) => {
                const sId = (s.id || '').toString();
                const rawName = (s.name || '').toString();
                if (sId && rawName) {
                  const cleanName = getStandardServiceName(sId, rawName);
                  if (!serviceMap.has(sId)) {
                    serviceMap.set(sId, { id: sId, name: cleanName });
                  }
                }
              });

              const normalizedServices = Array.from(serviceMap.values());
              if (normalizedServices.length > 0) {
                // Sort popular services to the top
                const popularKeywords = ['whatsapp', 'telegram', 'google', 'openai', 'chatgpt', 'instagram', 'facebook', 'tiktok', 'twitter', 'x', 'netflix', 'amazon', 'steam', 'discord', 'uber', 'paypal', 'apple', 'snapchat', 'binance', 'microsoft'];
                normalizedServices.sort((a, b) => {
                  const aName = a.name.toLowerCase();
                  const bName = b.name.toLowerCase();
                  const aIndex = popularKeywords.findIndex(kw => aName.includes(kw) || a.id.toLowerCase().includes(kw));
                  const bIndex = popularKeywords.findIndex(kw => bName.includes(kw) || b.id.toLowerCase().includes(kw));
                  if (aIndex !== -1 && bIndex !== -1) return aIndex - bIndex;
                  if (aIndex !== -1) return -1;
                  if (bIndex !== -1) return 1;
                  return a.name.localeCompare(b.name);
                });

                cachedServicesByServerCountry.set(cacheKey, { timestamp: now, data: normalizedServices });
                return res.json(normalizedServices);
              }
            }
          } catch (svcErr: any) {
            console.log('[OneGridHub] Services fetch notice:', svcErr?.message || svcErr);
          }
        }

        if (cached && cached.data.length > 0) {
          return res.json(cached.data);
        }

        const fallbackServices = [
          { id: 'whatsapp', name: 'WhatsApp & WA Business' },
          { id: 'telegram', name: 'Telegram' },
          { id: 'google', name: 'Google / Gmail / YouTube' },
          { id: 'openai', name: 'OpenAI / ChatGPT' },
          { id: 'instagram', name: 'Instagram & Threads' },
          { id: 'facebook', name: 'Facebook & Messenger' },
          { id: 'twitter', name: 'Twitter / X' },
          { id: 'tiktok', name: 'TikTok' },
          { id: 'netflix', name: 'Netflix' },
          { id: 'amazon', name: 'Amazon' },
          { id: 'steam', name: 'Steam' },
          { id: 'discord', name: 'Discord' },
          { id: 'uber', name: 'Uber & UberEats' },
          { id: 'paypal', name: 'PayPal Verification' },
          { id: 'apple', name: 'Apple / iCloud' },
          { id: 'snapchat', name: 'Snapchat' },
          { id: 'binance', name: 'Binance / Crypto' },
          { id: 'microsoft', name: 'Microsoft / Outlook / Azure' },
          { id: 'tinder', name: 'Tinder / Match' },
          { id: 'linkedin', name: 'LinkedIn' }
        ];

        cachedServicesByServerCountry.set(cacheKey, { timestamp: now, data: fallbackServices });
        return res.json(fallbackServices);
      }

      // 2d. LIVE PROVIDER PRICING & ZENET HUB MULTI-OPTION MARKUP CALCULATION
      if (action === 'price') {
        const rawServer = (req.query.server || '').toString();
        const server = normalizeServerId(rawServer);
        const country = (req.query.country || '').toString();
        const service = (req.query.service || '').toString();

        if (!country || !service) {
          return res.status(400).json({ success: false, error: 'country and service parameters are required to check price.' });
        }

        const providerCost = await getLiveProviderCost(server, country, service);

        if (providerCost !== null && providerCost > 0) {
          const settings = await getVirtualNumberPricingSettings();
          const isOwner = await isOwnerRequest();
          const options = generateVirtualNumberPriceOptions(providerCost, settings, isOwner);
          const primaryOption = options[0];
          const customerPrice = primaryOption?.customerPrice || (providerCost + settings.minMarkup);

          if (isOwner) {
            return res.json({
              success: true,
              available: true,
              providerCost,
              providerPrice: providerCost,
              markup: customerPrice - providerCost,
              profit: customerPrice - providerCost,
              customerPrice,
              totalPrice: customerPrice,
              options,
              settings,
              currency: 'NGN',
              country,
              service,
              server,
              isOwner: true
            });
          } else {
            // Buyer view: return options array and customerPrice ONLY. Strip all internal provider cost, markup, profit
            return res.json({
              success: true,
              available: true,
              customerPrice,
              totalPrice: customerPrice,
              options,
              currency: 'NGN',
              country,
              service,
              server
            });
          }
        }

        return res.json({
          success: false,
          available: false,
          error: 'No stock available for this country and service combination at provider. Please choose another server or country.'
        });
      }

      // 2d-2. GET OWNER PRICING ENGINE SETTINGS
      if (action === 'pricing-settings') {
        const settings = await getVirtualNumberPricingSettings();
        const isOwner = await isOwnerRequest();
        return res.json({ success: true, settings, isOwner });
      }

      // 2e. REAL SMS STATUS CHECK
      if (action === 'status') {
        const orderId = (req.query.order_id || req.query.orderId || '').toString();
        const authUid = (req as any).authUid;

        if (!orderId) {
          return res.status(400).json({ success: false, error: 'order_id is required' });
        }

        if (!db) {
          return res.status(500).json({ success: false, error: 'Firestore database is not initialized' });
        }

        const orderRef = doc(db, 'virtual_number_orders', orderId);
        const orderSnap = await getDoc(orderRef);
        if (!orderSnap.exists()) {
          return res.status(404).json({ success: false, error: 'Order not found' });
        }

        const orderData = orderSnap.data();

        // Enforce user ownership
        if (orderData.userId !== authUid) {
          return res.status(403).json({ success: false, error: 'Forbidden: You do not have permission to access this order.' });
        }

        // Clean up any corrupt historical code (e.g. "unauthorized" mistakenly stored as OTP)
        if (isInvalidOtpCode(orderData.code)) {
          if (orderData.code) {
            orderData.code = '';
            if (orderData.status === 'sms_received' || orderData.status === 'SMS_RECEIVED') {
              orderData.status = 'waiting_for_sms';
            }
            try {
              await updateDoc(orderRef, { code: '', status: orderData.status, updatedAt: new Date().toISOString() });
            } catch (cleanErr) {
              console.warn('[OneGridHub Status] Error cleaning corrupt code on doc:', cleanErr);
            }
          }
        }

        // Return immediately if genuine OTP code has already been received
        if (isValidOtpCode(orderData.code) && (orderData.status === 'sms_received' || orderData.status === 'SMS_RECEIVED' || orderData.status === 'completed')) {
          return res.json(orderData);
        }

        // Return immediately if cancelled or expired
        if (orderData.status === 'cancelled' || orderData.status === 'CANCELLED' || orderData.status === 'expired' || orderData.status === 'EXPIRED') {
          return res.json(orderData);
        }

        // Check if 20-minute window expired
        const createdAtTime = new Date(orderData.createdAt).getTime();
        const now = Date.now();
        const isTimedOut = (now - createdAtTime) > (20 * 60 * 1000);

        if (isTimedOut && (orderData.status === 'waiting_for_sms' || orderData.status === 'WAITING' || orderData.status === 'active')) {
          console.log(`[OneGridHub Status] Order ${orderId} reached 20-min timeout without SMS. Processing auto-refund...`);

          // Attempt to cancel at provider
          if (isRealKey && orderData.providerActivationId) {
            try {
              await queryOneGridHub('cancel', {
                server: orderData.server || 'all1',
                order_ref: orderData.providerActivationId
              });
            } catch (cancelErr) {
              console.warn('[OneGridHub] Upstream timeout cancellation notification error:', cancelErr);
            }
          }

          // Atomically refund wallet
          const userRef = doc(db, 'users', authUid);
          const refundPrice = orderData.customerPrice || orderData.price || 0;

          try {
            await runTransaction(db, async (tx) => {
              const uSnap = await tx.get(userRef);
              if (uSnap.exists()) {
                const uData = uSnap.data();
                const rawBal = uData.walletBalance !== undefined ? uData.walletBalance : uData.balance;
                const bal = typeof rawBal === 'number' ? rawBal : (rawBal ? Number(rawBal) : 0);
                const newBal = bal + refundPrice;
                tx.update(userRef, { 
                  walletBalance: newBal,
                  balance: newBal,
                  updatedAt: new Date().toISOString()
                });
                tx.set(doc(db, 'wallets', authUid), {
                  userId: authUid,
                  walletBalance: newBal,
                  balance: newBal,
                  updatedAt: new Date().toISOString()
                }, { merge: true });
              }
              tx.update(orderRef, {
                status: 'expired',
                updatedAt: new Date().toISOString()
              });
            });

            const refundId = `EXP-${orderId}`;
            await setDoc(doc(db, 'wallet_transactions', refundId), {
              id: refundId,
              userId: authUid,
              userEmail: orderData.userEmail || '',
              amount: refundPrice,
              type: 'deposit',
              method: 'wallet',
              status: 'successful',
              description: `Auto-Refund: Expired Virtual Number Session (${orderData.phoneNumber})`,
              date: new Date().toISOString(),
              createdAt: new Date().toISOString()
            });

            return res.json({
              ...orderData,
              status: 'expired',
              message: 'Verification session expired without SMS. Your wallet has been automatically refunded in full.'
            });
          } catch (expErr) {
            console.error('[OneGridHub Status] Expiration refund transaction error:', expErr);
          }
        }

        // Query real provider status using provider activation ID
        if (isRealKey && orderData.providerActivationId) {
          const providerId = orderData.providerActivationId;
          const statusResp = await queryOneGridHub('status', {
            server: orderData.server || 'all1',
            order_ref: providerId
          });

          if (statusResp) {
            // 1. Upstream authentication or API error: Do NOT treat as OTP or complete
            if (statusResp.isApiError || statusResp.status === 'error' || statusResp.code === 'unauthorized') {
              const apiErrMsg = statusResp.error || statusResp.message || 'Provider API authorization failure';
              console.warn(`[OneGridHub Status] Provider API error for order ${orderId}: ${apiErrMsg}`);
              return res.json({
                ...orderData,
                status: orderData.status || 'waiting_for_sms',
                code: '',
                isApiError: true,
                apiError: apiErrMsg
              });
            }

            // 2. Check raw text response: e.g. STATUS_OK:123456 or STATUS_WAIT_CODE or STATUS_CANCEL
            if (statusResp.rawText) {
              const raw = statusResp.rawText.trim();
              if (raw.startsWith('STATUS_OK:')) {
                const candidateCode = raw.substring('STATUS_OK:'.length).trim();
                if (isValidOtpCode(candidateCode)) {
                  const updated = {
                    status: 'sms_received',
                    code: candidateCode,
                    smsText: `Your verification code is ${candidateCode}`,
                    updatedAt: new Date().toISOString()
                  };
                  await updateDoc(orderRef, updated);
                  console.log(`[OneGridHub Status] Received real SMS OTP for order ${orderId}: ${candidateCode}`);
                  return res.json({ ...orderData, ...updated });
                }
              } else if (raw === 'STATUS_CANCEL') {
                const updated = { status: 'cancelled', updatedAt: new Date().toISOString() };
                await updateDoc(orderRef, updated);
                return res.json({ ...orderData, ...updated });
              } else if (raw === 'STATUS_WAIT_CODE') {
                return res.json({
                  ...orderData,
                  status: 'waiting_for_sms',
                  code: ''
                });
              }
            }

            // 3. Check JSON response: ONLY accept genuine, validated OTP codes
            const statusUpper = (statusResp.status || statusResp.state || '').toString().toUpperCase();
            const candidateCode = (statusResp.otp || statusResp.sms_code || statusResp.smsCode || (!statusResp.isApiError && statusUpper !== 'ERROR' && statusResp.code !== 'unauthorized' ? statusResp.code : '') || '').toString().trim();

            if (isValidOtpCode(candidateCode)) {
              const smsText = (statusResp.sms || statusResp.smsText || statusResp.text || `Your verification code is ${candidateCode}`).toString();
              const updated = {
                status: 'sms_received',
                code: candidateCode,
                smsText,
                updatedAt: new Date().toISOString()
              };
              await updateDoc(orderRef, updated);
              console.log(`[OneGridHub Status] Real SMS delivered for order ${orderId}: ${candidateCode}`);
              return res.json({ ...orderData, ...updated });
            } else if (statusUpper === 'CANCELLED' || statusResp.code === 'cancelled') {
              const updated = { status: 'cancelled', updatedAt: new Date().toISOString() };
              await updateDoc(orderRef, updated);
              return res.json({ ...orderData, ...updated });
            } else if (statusUpper === 'EXPIRED' || statusResp.code === 'expired') {
              const updated = { status: 'expired', updatedAt: new Date().toISOString() };
              await updateDoc(orderRef, updated);
              return res.json({ ...orderData, ...updated });
            }
          }
        }

        // Return current waiting state with clean empty code if no real OTP has arrived
        return res.json({
          ...orderData,
          status: orderData.status || 'waiting_for_sms',
          code: isValidOtpCode(orderData.code) ? orderData.code : ''
        });
      }

      // 2f. USER ORDERS HISTORY
      if (action === 'orders') {
        const authUid = (req as any).authUid;

        if (!db) {
          return res.status(500).json({ success: false, error: 'Firestore database is not initialized' });
        }

        const isOwner = await isOwnerRequest();
        const q = query(collection(db, 'virtual_number_orders'), where('userId', '==', authUid));
        const qSnap = await getDocs(q);
        const ordersList: any[] = [];
        qSnap.forEach(docSnap => {
          const raw = { ...docSnap.data() };

          // Sanitize candidate OTP code - never expose "unauthorized" or error text as code
          if (isInvalidOtpCode(raw.code)) {
            raw.code = '';
            if (raw.status === 'sms_received' || raw.status === 'SMS_RECEIVED') {
              raw.status = 'waiting_for_sms';
            }
          }

          // Resolve accurate country based on actual phone number prefix
          const resolved = resolveCountryDetails(raw.country, raw.phoneNumber);
          raw.country = resolved.id;
          raw.countryName = resolved.name;
          raw.countryCode = resolved.code;
          raw.countryFlag = resolved.flag;

          if (isOwner) {
            ordersList.push(raw);
          } else {
            const { providerCost: _pc, markup: _mk, ...sanitized } = raw;
            ordersList.push(sanitized);
          }
        });

        ordersList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        return res.json(ordersList);
      }

      return res.status(400).json({ success: false, error: `Unsupported GET action: ${action}` });
    }

    // --- 3. POST REQUESTS ---
    if (method === 'POST') {
      // 3-0. UPDATE OWNER PRICING ENGINE SETTINGS
      if (action === 'pricing-settings') {
        const isOwner = await isOwnerRequest();
        if (!isOwner) {
          return res.status(403).json({ success: false, error: 'Unauthorized: Only the ZENET HUB Owner can configure pricing settings.' });
        }
        const { optionsCount, minMarkup, maxMarkup, pricingStyle } = req.body;
        const updated: VirtualNumberPricingSettings = {
          optionsCount: Math.min(Math.max(Number(optionsCount) || 4, 2), 6),
          minMarkup: Math.max(Number(minMarkup) || 500, 100),
          maxMarkup: Math.max(Number(maxMarkup) || 4500, (Number(minMarkup) || 500) + 300),
          pricingStyle: pricingStyle === 'clean' || pricingStyle === 'tiered' ? pricingStyle : 'natural'
        };
        cachedPricingSettings = updated;
        if (db) {
          try {
            await setDoc(doc(db, 'system_settings', 'virtual_number_pricing'), {
              ...updated,
              updatedAt: new Date().toISOString()
            });
          } catch (dbErr) {
            console.warn('[VirtualNumberPricing] Firestore write notice:', dbErr);
          }
        }
        console.log('[VirtualNumberPricing] Successfully updated owner pricing settings:', updated);
        return res.json({ success: true, settings: updated });
      }

      // 3a. NUMBER PURCHASE
      if (action === 'buy') {
        const { server: rawServer, country, service, optionId, tierName, selectedPrice } = req.body;
        const authUid = (req as any).authUid;
        const server = normalizeServerId(rawServer);

        if (!country || !service) {
          return res.status(400).json({ success: false, error: 'Country and service are required' });
        }

        if (!db) {
          return res.status(500).json({ success: false, error: 'Firestore database is not initialized' });
        }

        // Idempotency lock to prevent double-charges
        const now = Date.now();
        const lastAttempt = activeBuyLocks.get(authUid);
        if (lastAttempt && (now - lastAttempt < 8000)) {
          return res.status(429).json({ success: false, error: 'A purchase transaction is currently processing. Please wait.' });
        }
        activeBuyLocks.set(authUid, now);

        try {
          // 1. Retrieve exact live provider cost
          const providerCost = await getLiveProviderCost(server, country, service);

          if (providerCost === null || providerCost <= 0) {
            return res.status(422).json({
              success: false,
              error: 'This option is currently out of stock at the carrier. Please choose another server or country.'
            });
          }

          // 2. Resolve price option from owner config
          const settings = await getVirtualNumberPricingSettings();
          const isOwner = await isOwnerRequest();
          const options = generateVirtualNumberPriceOptions(providerCost, settings, isOwner);

          let selectedOption = options.find((o: any) => o.optionId === optionId);
          if (!selectedOption && selectedPrice) {
            selectedOption = options.find((o: any) => o.customerPrice === Number(selectedPrice));
          }
          if (!selectedOption) {
            selectedOption = options[0];
          }

          const customerPrice = selectedOption ? selectedOption.customerPrice : (providerCost + settings.minMarkup);
          const markup = Math.max(0, customerPrice - providerCost);
          const chosenTierName = selectedOption?.tierName || tierName || 'Standard Line';

          const userRef = doc(db, 'users', authUid);
          let userEmail = '';

          // 3. Atomically verify balance and debit customerPrice
          await runTransaction(db, async (transaction) => {
            const userDocSnap = await transaction.get(userRef);
            if (!userDocSnap.exists()) {
              throw new Error('User profile not found');
            }

            const userData = userDocSnap.data();
            userEmail = userData.email || '';
            const currentBalance = userData.walletBalance || 0;

            if (currentBalance < customerPrice) {
              throw new Error(`Insufficient wallet balance. This order costs ₦${customerPrice.toLocaleString()}, but your balance is ₦${currentBalance.toLocaleString()}. Please top up your wallet.`);
            }

            transaction.update(userRef, { walletBalance: currentBalance - customerPrice });
          });

          // 4. Purchase number from OneGridHub
          const orderId = `ORD-WN-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
          let providerActivationId = '';
          let phoneNumber = '';

          try {
            const buyResult = await queryOneGridHub('buy', {
              server,
              country,
              service
            }, 'POST');

            if (buyResult) {
              if (buyResult.status === 'success' || buyResult.phone || buyResult.number || buyResult.order_ref) {
                phoneNumber = (buyResult.phone || buyResult.number || buyResult.phone_number || buyResult.phoneNumber || '').toString();
                providerActivationId = (buyResult.order_ref || buyResult.id || buyResult.activationId || buyResult.orderId || '').toString();
              } else if (buyResult.rawText && buyResult.rawText.startsWith('ACCESS_NUMBER:')) {
                const parts = buyResult.rawText.split(':');
                if (parts.length >= 3) {
                  providerActivationId = parts[1].trim();
                  phoneNumber = parts.slice(2).join(':').trim();
                }
              }
            }

            if (!phoneNumber) {
              const errMsg = buyResult?.message || buyResult?.error || buyResult?.rawText || 'Provider reported no available numbers or insufficient stock.';
              throw new Error(errMsg);
            }

          } catch (supplierError: any) {
            console.error('[OneGridHub Buy] Provider carrier allocation failed, performing instant wallet reversal:', supplierError);

            // Auto-refund user balance instantly in transaction
            await runTransaction(db, async (reversalTx) => {
              const userDocSnap = await reversalTx.get(userRef);
              if (userDocSnap.exists()) {
                const uData = userDocSnap.data();
                const curRaw = uData.walletBalance !== undefined ? uData.walletBalance : uData.balance;
                const curBal = typeof curRaw === 'number' ? curRaw : (curRaw ? Number(curRaw) : 0);
                const newBal = curBal + customerPrice;
                reversalTx.update(userRef, { 
                  walletBalance: newBal,
                  balance: newBal,
                  updatedAt: new Date().toISOString()
                });
                reversalTx.set(doc(db, 'wallets', authUid), {
                  userId: authUid,
                  userEmail,
                  walletBalance: newBal,
                  balance: newBal,
                  updatedAt: new Date().toISOString()
                }, { merge: true });
              }
            });

            // Write reversal refund ledger
            const refundId = `REV-FAIL-${orderId}`;
            await setDoc(doc(db, 'wallet_transactions', refundId), {
              id: refundId,
              userId: authUid,
              userEmail,
              amount: customerPrice,
              type: 'deposit',
              method: 'wallet',
              status: 'successful',
              description: `Auto-Refund: Provider allocation failed for ${service.toUpperCase()} (${supplierError.message || 'Carrier error'})`,
              date: new Date().toISOString(),
              createdAt: new Date().toISOString()
            });

            return res.status(502).json({
              success: false,
              error: supplierError.message || 'Provider out of stock. Your wallet balance has been refunded in full.'
            });
          }

          // 5. Save order to Firestore with all audit fields
          const resolvedCountry = resolveCountryDetails(country, phoneNumber);
          const formattedPhone = phoneNumber.startsWith('+') ? phoneNumber : `+${phoneNumber}`;

          const transactionId = generateUniqueTransactionId('update');

          const orderData = {
            id: orderId,
            orderId,
            transactionId,
            providerActivationId: providerActivationId || orderId,
            userId: authUid,
            userEmail,
            server,
            country: resolvedCountry.id,
            countryName: resolvedCountry.name,
            countryCode: resolvedCountry.code,
            countryFlag: resolvedCountry.flag,
            service,
            tierName: chosenTierName,
            phoneNumber: formattedPhone,
            status: 'waiting_for_sms',
            price: customerPrice,
            customerPrice,
            providerCost,
            markup,
            profit: markup,
            type: 'virtual_number',
            category: 'virtual_number',
            transactionCategory: 'virtual_number',
            isRealOrder: true,
            code: '',
            smsText: '',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            expiresAt: new Date(Date.now() + 20 * 60 * 1000).toISOString()
          };

          await setDoc(doc(db, 'virtual_number_orders', orderId), orderData);

          // Dual-record in purchases collection for seamless unified access & Recent Activities
          try {
            await setDoc(doc(db, 'purchases', orderId), {
              id: orderId,
              transactionId,
              listingId: orderId,
              listingTitle: `Virtual Number (${service.toUpperCase()}) - ${formattedPhone}`,
              category: 'virtual_number',
              type: 'virtual_number',
              transactionCategory: 'virtual_number',
              price: customerPrice,
              paidAmount: customerPrice,
              currency: 'NGN',
              buyerId: authUid,
              buyerEmail: userEmail || '',
              sellerId: 'onegridhub-service',
              sellerName: 'ZENET Service Numbers',
              status: 'waiting_for_sms',
              phoneNumber: formattedPhone,
              service: service,
              country: resolvedCountry.name || country,
              server: server,
              providerActivationId,
              purchasedAt: orderData.createdAt,
              createdAt: orderData.createdAt
            });
          } catch (pErr) {
            console.warn('[OneGridHub Buy] Could not dual-write purchases doc:', pErr);
          }

          // 6. Write completed purchase ledger transaction
          await setDoc(doc(db, 'wallet_transactions', orderId), {
            id: orderId,
            transactionId,
            userId: authUid,
            userEmail,
            amount: customerPrice,
            type: 'purchase',
            category: 'virtual_number',
            transactionCategory: 'virtual_number',
            method: 'wallet',
            status: 'successful',
            description: `Virtual Number - ${service.toUpperCase()} [${chosenTierName}] Verification (${phoneNumber})`,
            date: new Date().toISOString(),
            createdAt: new Date().toISOString()
          });

          console.log(`[OneGridHub Buy] Successfully created order ${orderId} (Provider ID: ${providerActivationId}, Customer: ₦${customerPrice}, Provider: ₦${providerCost}, Profit: ₦${markup})`);
          
          const isOwnerReq = await isOwnerRequest();
          if (isOwnerReq) {
            return res.json(orderData);
          } else {
            const { providerCost: _pc, markup: _mk, profit: _pf, ...sanitized } = orderData;
            return res.json(sanitized);
          }

        } catch (txnError: any) {
          console.error('[OneGridHub Buy] Purchase process error:', txnError);
          return res.status(400).json({ success: false, error: txnError.message || 'Failed to complete number purchase' });
        } finally {
          activeBuyLocks.delete(authUid);
        }
      }

      // 3b. CANCEL & REFUND ORDER
      if (action === 'cancel') {
        const { orderId } = req.body;
        const authUid = (req as any).authUid;

        if (!orderId) {
          return res.status(400).json({ success: false, error: 'orderId is required' });
        }

        if (!db) {
          return res.status(500).json({ success: false, error: 'Firestore database is not initialized' });
        }

        const orderRef = doc(db, 'virtual_number_orders', orderId);
        const orderSnap = await getDoc(orderRef);
        if (!orderSnap.exists()) {
          return res.status(404).json({ success: false, error: 'Order not found' });
        }

        const orderData = orderSnap.data();

        if (orderData.userId !== authUid) {
          return res.status(403).json({ success: false, error: 'Forbidden: You do not have permission to cancel this order.' });
        }

        if (orderData.status !== 'waiting_for_sms' && orderData.status !== 'WAITING' && orderData.status !== 'active') {
          return res.status(400).json({ success: false, error: 'Only pending orders awaiting SMS verification can be cancelled.' });
        }

        // Notify provider of cancellation
        if (isRealKey && orderData.providerActivationId) {
          try {
            await queryOneGridHub('cancel', {
              server: orderData.server || 'all1',
              order_ref: orderData.providerActivationId
            });
          } catch (cancelErr) {
            console.warn('[OneGridHub] Real cancel order notification warning:', cancelErr);
          }
        }

        const userRef = doc(db, 'users', authUid);
        const refundPrice = orderData.customerPrice || orderData.price || 0;

        try {
          await runTransaction(db, async (tx) => {
            const orderTxSnap = await tx.get(orderRef);
            if (!orderTxSnap.exists()) {
              throw new Error('Order does not exist');
            }
            const curStatus = orderTxSnap.data().status;
            if (curStatus !== 'waiting_for_sms' && curStatus !== 'WAITING' && curStatus !== 'active') {
              throw new Error('Order has already been completed, cancelled, or expired');
            }

            const userSnap = await tx.get(userRef);
            if (!userSnap.exists()) {
              throw new Error('User profile does not exist');
            }

            const uData = userSnap.data();
            const rawCurrentBal = uData.walletBalance !== undefined ? uData.walletBalance : uData.balance;
            const currentBalance = typeof rawCurrentBal === 'number' ? rawCurrentBal : (rawCurrentBal ? Number(rawCurrentBal) : 0);
            const newBalance = currentBalance + refundPrice;

            tx.update(userRef, { 
              walletBalance: newBalance,
              balance: newBalance,
              updatedAt: new Date().toISOString()
            });
            tx.set(doc(db, 'wallets', authUid), {
              userId: authUid,
              walletBalance: newBalance,
              balance: newBalance,
              updatedAt: new Date().toISOString()
            }, { merge: true });
            tx.update(orderRef, {
              status: 'cancelled',
              updatedAt: new Date().toISOString()
            });
          });

          const refundId = `REF-${orderId}`;
          const userSnap2 = await getDoc(userRef);
          const userEmail = userSnap2.exists() ? userSnap2.data().email : '';

          await setDoc(doc(db, 'wallet_transactions', refundId), {
            id: refundId,
            userId: authUid,
            userEmail: userEmail || '',
            amount: refundPrice,
            type: 'deposit',
            method: 'wallet',
            status: 'successful',
            description: `Refund: Cancelled Virtual Number (${orderData.phoneNumber})`,
            date: new Date().toISOString(),
            createdAt: new Date().toISOString()
          });

          console.log(`[OneGridHub Refund] Atomically cancelled and refunded order ${orderId} with ₦${refundPrice}.`);

          return res.json({
            success: true,
            status: 'cancelled',
            message: 'Order successfully cancelled and wallet fully refunded.'
          });

        } catch (refundError: any) {
          console.error('[OneGridHub Refund] Transactional cancellation error:', refundError);
          return res.status(400).json({ success: false, error: refundError.message || 'Refund processing failed.' });
        }
      }

      return res.status(400).json({ success: false, error: `Unsupported POST action: ${action}` });
    }

    return res.status(405).json({ success: false, error: `Method ${method} not allowed` });

  } catch (err: any) {
    console.error('OneGridHub API Proxy Error:', err);
    res.status(500).json({ success: false, error: err.message || 'OneGridHub Proxy Gateway service error' });
  }
};

// ==========================================
// SOCIAL MEDIA BOOSTING MARKETPLACE BACKEND
// ==========================================

interface SocialBoostPricingConfig {
  defaultMarkupPercent: number;
  minMarkupPer1k: number;
  pricingStyle: 'natural' | 'clean' | 'tiered';
  platformStatus: Record<string, boolean>;
  disabledServices: string[];
  curatedServiceIds?: string[];
  bestValueServiceIds?: Record<string, string>;
  serviceOverrides?: Record<string, {
    customRatePer1000?: number;
    customMarkupPercent?: number;
    enabled?: boolean;
    isBestValue?: boolean;
  }>;
}

let cachedSocialBoostPricing: SocialBoostPricingConfig = {
  defaultMarkupPercent: 45,
  minMarkupPer1k: 350,
  pricingStyle: 'natural',
  platformStatus: {
    TikTok: true,
    Instagram: true,
    Facebook: true,
    YouTube: true,
    'Twitter/X': true,
    Telegram: true,
    Spotify: true,
    Threads: true
  },
  disabledServices: [],
  curatedServiceIds: [],
  bestValueServiceIds: {},
  serviceOverrides: {}
};

let cachedLiveProviderServices: any[] = [];
let lastCatalogueSyncTime: string | null = null;

const CACHE_CATALOGUE_FILE = path.join(process.cwd(), '.cache_social_boost.json');

// Database caching helpers for Firestore & Local Disk
const loadSocialBoostCatalogueFromDb = async () => {
  // First load from local disk cache if available (instant 4300+ services)
  try {
    if (fs.existsSync(CACHE_CATALOGUE_FILE)) {
      const diskData = JSON.parse(fs.readFileSync(CACHE_CATALOGUE_FILE, 'utf-8'));
      if (Array.isArray(diskData.services) && diskData.services.length > 0) {
        cachedLiveProviderServices = diskData.services;
        lastCatalogueSyncTime = diskData.lastSyncedAt || null;
        console.log(`[SocialBoost Local Cache] Loaded ${cachedLiveProviderServices.length} cached services from disk cache.`);
        return;
      }
    }
  } catch (diskErr: any) {
    console.warn('[SocialBoost Local Cache] Notice loading local disk cache:', diskErr.message);
  }

  if (!db) return;
  try {
    const docSnap = await getDoc(doc(db, 'system_settings', 'social_boost_catalogue'));
    if (docSnap.exists()) {
      const data = docSnap.data();
      if (Array.isArray(data.services) && data.services.length > 0) {
        if (cachedLiveProviderServices.length === 0) {
          cachedLiveProviderServices = data.services;
          lastCatalogueSyncTime = data.lastSyncedAt || null;
          console.log(`[SocialBoost DB Cache] Loaded ${cachedLiveProviderServices.length} cached services from Firestore.`);
        }
      }
    }
  } catch (err: any) {
    console.warn('[SocialBoost DB Cache] Notice loading cache:', err.message);
  }
};

const saveSocialBoostCatalogueToDb = async (servicesList: any[]) => {
  if (!Array.isArray(servicesList) || servicesList.length === 0) return;
  const nowIso = new Date().toISOString();
  lastCatalogueSyncTime = nowIso;

  // 1. Save full catalogue to local disk cache for instant reboots
  try {
    fs.writeFileSync(CACHE_CATALOGUE_FILE, JSON.stringify({
      services: servicesList,
      totalCount: servicesList.length,
      lastSyncedAt: nowIso
    }), 'utf-8');
    console.log(`[SocialBoost Local Cache] Persisted all ${servicesList.length} services to local disk.`);
  } catch (diskErr: any) {
    console.warn('[SocialBoost Local Cache] Notice saving disk cache:', diskErr.message);
  }

  // 2. Save metadata snapshot to Firestore (capped to avoid 1MB document limit)
  if (!db) return;
  try {
    const compactServices = servicesList.slice(0, 300).map(s => ({
      id: s.id || '',
      providerServiceId: s.providerServiceId || '',
      platform: s.platform || 'General',
      category: s.category || 'General',
      name: s.name || 'Service',
      type: s.type || 'Service',
      providerRatePer1000: Number(s.providerRatePer1000) || 500,
      min: Number(s.min) || 50,
      max: Number(s.max) || 100000,
      deliverySpeed: s.deliverySpeed || 'Instant Start',
      refill: Boolean(s.refill),
      quality: s.quality || 'High Quality',
      description: (s.description || '').slice(0, 250),
      inputLabel: s.inputLabel || 'Target Link / Username',
      inputPlaceholder: s.inputPlaceholder || 'https://...',
      inputType: s.inputType || 'link'
    }));

    await setDoc(doc(db, 'system_settings', 'social_boost_catalogue'), {
      services: compactServices,
      totalCount: servicesList.length,
      lastSyncedAt: nowIso,
      provider: 'OneGridHub'
    }, { merge: true });
    console.log(`[SocialBoost DB Cache] Persisted ${compactServices.length} services snapshot to Firestore.`);
  } catch (err: any) {
    console.warn('[SocialBoost DB Cache] Notice saving cache to Firestore:', err.message);
  }
};

const getSocialBoostPricingSettings = async (): Promise<SocialBoostPricingConfig> => {
  if (db) {
    try {
      const docSnap = await getDoc(doc(db, 'system_settings', 'social_boost_pricing'));
      if (docSnap.exists()) {
        const data = docSnap.data();
        cachedSocialBoostPricing = {
          defaultMarkupPercent: typeof data.defaultMarkupPercent === 'number' ? data.defaultMarkupPercent : 45,
          minMarkupPer1k: typeof data.minMarkupPer1k === 'number' ? data.minMarkupPer1k : 350,
          pricingStyle: data.pricingStyle || 'natural',
          platformStatus: data.platformStatus || cachedSocialBoostPricing.platformStatus,
          disabledServices: Array.isArray(data.disabledServices) ? data.disabledServices : [],
          curatedServiceIds: Array.isArray(data.curatedServiceIds) ? data.curatedServiceIds : [],
          bestValueServiceIds: data.bestValueServiceIds || {},
          serviceOverrides: data.serviceOverrides || {}
        };
      }
    } catch (err) {
      console.warn('[SocialBoost] Could not fetch settings from Firestore:', err);
    }
  }
  return cachedSocialBoostPricing;
};

// Base wholesale catalogue (in NGN wholesale cost per 1,000 units from OneGridHub provider)
const BASE_SOCIAL_SERVICES = [
  // --- TIKTOK ---
  {
    id: 'tt-followers-hq',
    platform: 'TikTok',
    category: 'TikTok Followers',
    name: 'TikTok Followers [Real & High Retention - Instant Start]',
    type: 'Followers',
    providerRatePer1000: 1800,
    min: 100,
    max: 50000,
    deliverySpeed: '5,000 - 10,000 / day',
    refill: true,
    quality: 'High Quality Active Accounts',
    description: 'Boost your TikTok profile visibility with real looking active followers. Safe and non-drop guarantee.',
    inputLabel: 'TikTok Profile Link or @Username',
    inputPlaceholder: 'https://www.tiktok.com/@username or @username',
    inputType: 'link'
  },
  {
    id: 'tt-likes-fast',
    platform: 'TikTok',
    category: 'TikTok Likes',
    name: 'TikTok Video Likes [Instant Delivery - High Quality]',
    type: 'Likes',
    providerRatePer1000: 600,
    min: 50,
    max: 100000,
    deliverySpeed: '20,000 - 50,000 / day',
    refill: true,
    quality: 'Real Accounts',
    description: 'Instant likes for any TikTok video. Helps boost video on For You Page (FYP).',
    inputLabel: 'TikTok Video URL',
    inputPlaceholder: 'https://www.tiktok.com/@username/video/1234567890',
    inputType: 'link'
  },
  {
    id: 'tt-views-viral',
    platform: 'TikTok',
    category: 'TikTok Views',
    name: 'TikTok Video Views [FYP Algorithm Booster - Ultra Fast]',
    type: 'Views',
    providerRatePer1000: 150,
    min: 500,
    max: 2000000,
    deliverySpeed: '1,000,000+ / day',
    refill: false,
    quality: 'High Speed Algorithm Views',
    description: 'Ultra fast video views to trigger the TikTok algorithm and increase viral reach.',
    inputLabel: 'TikTok Video URL',
    inputPlaceholder: 'https://www.tiktok.com/@username/video/1234567890',
    inputType: 'link'
  },
  {
    id: 'tt-shares-reposts',
    platform: 'TikTok',
    category: 'TikTok Shares & Reposts',
    name: 'TikTok Shares & Reposts [Viral Rank Multiplier]',
    type: 'Shares',
    providerRatePer1000: 750,
    min: 100,
    max: 50000,
    deliverySpeed: '10,000 / day',
    refill: true,
    quality: 'Organic Share Signals',
    description: 'Increases shares & repost counts, one of the strongest ranking signals on TikTok.',
    inputLabel: 'TikTok Video URL',
    inputPlaceholder: 'https://www.tiktok.com/@username/video/1234567890',
    inputType: 'link'
  },
  {
    id: 'tt-comments-custom',
    platform: 'TikTok',
    category: 'TikTok Comments',
    name: 'TikTok Custom Comments [Real Text & Relevant Content]',
    type: 'Comments',
    providerRatePer1000: 4200,
    min: 10,
    max: 2000,
    deliverySpeed: 'Instant Delivery',
    refill: true,
    quality: 'Custom Written Text',
    description: 'Custom positive and engaging comments on your videos to drive social proof.',
    inputLabel: 'TikTok Video URL & Comments (1 per line)',
    inputPlaceholder: 'https://www.tiktok.com/@username/video/1234567890\nGreat content!\nLove this so much!',
    inputType: 'custom_comments'
  },

  // --- INSTAGRAM ---
  {
    id: 'ig-followers-nondrop',
    platform: 'Instagram',
    category: 'Instagram Followers',
    name: 'Instagram Followers [365 Days Refill Guaranteed - Non Drop]',
    type: 'Followers',
    providerRatePer1000: 2100,
    min: 50,
    max: 500000,
    deliverySpeed: '10,000 - 25,000 / day',
    refill: true,
    quality: 'Top Tier High Quality Profiles with Posts',
    description: 'Premium non-drop Instagram followers with full 365-day automated refill warranty.',
    inputLabel: 'Instagram Profile Link or @Username',
    inputPlaceholder: 'https://instagram.com/username or @username',
    inputType: 'link'
  },
  {
    id: 'ig-followers-nigerian',
    platform: 'Instagram',
    category: 'Instagram Followers',
    name: 'Instagram Followers [Targeted Nigerian & African Active]',
    type: 'Followers',
    providerRatePer1000: 4500,
    min: 50,
    max: 25000,
    deliverySpeed: '2,000 - 5,000 / day',
    refill: true,
    quality: '100% Real African / Nigerian Names',
    description: 'Targeted Nigerian and African profiles for local businesses, influencers, and brands.',
    inputLabel: 'Instagram Profile Link or @Username',
    inputPlaceholder: 'https://instagram.com/username or @username',
    inputType: 'link'
  },
  {
    id: 'ig-likes-superfast',
    platform: 'Instagram',
    category: 'Instagram Likes',
    name: 'Instagram Post & Reels Likes [Instant Start - Super Fast]',
    type: 'Likes',
    providerRatePer1000: 520,
    min: 50,
    max: 100000,
    deliverySpeed: '50,000 / day',
    refill: true,
    quality: 'Real Active Profiles',
    description: 'Instant likes for Instagram photos, carousels, and reels. Starts within 30 seconds.',
    inputLabel: 'Instagram Post / Reel URL',
    inputPlaceholder: 'https://instagram.com/p/ABCDEF12345/ or reel link',
    inputType: 'link'
  },
  {
    id: 'ig-views-reels',
    platform: 'Instagram',
    category: 'Instagram Views',
    name: 'Instagram Reels Views [Explore Feed Algorithm Trigger]',
    type: 'Views',
    providerRatePer1000: 180,
    min: 500,
    max: 5000000,
    deliverySpeed: '1,000,000+ / day',
    refill: false,
    quality: 'High Retention Views',
    description: 'High retention Reels video views to push your video into Instagram Explore feed.',
    inputLabel: 'Instagram Reel URL',
    inputPlaceholder: 'https://instagram.com/reel/C0123456789/',
    inputType: 'link'
  },
  {
    id: 'ig-story-views',
    platform: 'Instagram',
    category: 'Instagram Views',
    name: 'Instagram Story Views & Impressions [All Active Stories]',
    type: 'Views',
    providerRatePer1000: 380,
    min: 100,
    max: 50000,
    deliverySpeed: 'Instant Delivery',
    refill: false,
    quality: 'Active Profiles',
    description: 'Views on all current active Instagram stories on the account.',
    inputLabel: 'Instagram Profile Link or @Username',
    inputPlaceholder: 'https://instagram.com/username or @username',
    inputType: 'link'
  },

  // --- FACEBOOK ---
  {
    id: 'fb-page-followers',
    platform: 'Facebook',
    category: 'Facebook Followers',
    name: 'Facebook Page Followers & Likes [Real Aged Profiles]',
    type: 'Followers',
    providerRatePer1000: 2600,
    min: 100,
    max: 100000,
    deliverySpeed: '5,000 - 10,000 / day',
    refill: true,
    quality: 'Aged Real Facebook Accounts',
    description: 'Build credibility and audience for Facebook Business and Creator pages.',
    inputLabel: 'Facebook Page URL',
    inputPlaceholder: 'https://www.facebook.com/yourpagename',
    inputType: 'link'
  },
  {
    id: 'fb-profile-followers',
    platform: 'Facebook',
    category: 'Facebook Followers',
    name: 'Facebook Personal Profile Followers [High Quality]',
    type: 'Followers',
    providerRatePer1000: 2200,
    min: 100,
    max: 50000,
    deliverySpeed: '5,000 / day',
    refill: true,
    quality: 'Real Accounts',
    description: 'Followers for personal Facebook profiles and public figure pages.',
    inputLabel: 'Facebook Profile URL',
    inputPlaceholder: 'https://www.facebook.com/profile.php?id=12345 or username',
    inputType: 'link'
  },
  {
    id: 'fb-post-likes',
    platform: 'Facebook',
    category: 'Facebook Likes',
    name: 'Facebook Post Likes & Reactions (Love / Care / Wow / Haha)',
    type: 'Likes',
    providerRatePer1000: 700,
    min: 50,
    max: 20000,
    deliverySpeed: '10,000 / day',
    refill: true,
    quality: 'Real Reactions',
    description: 'Likes and emotional reactions for Facebook public posts and photos.',
    inputLabel: 'Facebook Post URL',
    inputPlaceholder: 'https://www.facebook.com/permalink.php?story_fbid=...',
    inputType: 'link'
  },
  {
    id: 'fb-video-views',
    platform: 'Facebook',
    category: 'Facebook Views',
    name: 'Facebook Video & Reel Views [Monetization Safe]',
    type: 'Views',
    providerRatePer1000: 320,
    min: 500,
    max: 500000,
    deliverySpeed: '100,000 / day',
    refill: false,
    quality: 'High Retention Video Views',
    description: 'Monetization-safe video views for Facebook Watch, Page Videos, and Reels.',
    inputLabel: 'Facebook Video URL',
    inputPlaceholder: 'https://www.facebook.com/watch/?v=1234567890',
    inputType: 'link'
  },
  {
    id: 'fb-group-members',
    platform: 'Facebook',
    category: 'Facebook Members',
    name: 'Facebook Group Members [Public or Private Groups]',
    type: 'Members',
    providerRatePer1000: 3200,
    min: 100,
    max: 25000,
    deliverySpeed: '3,000 - 5,000 / day',
    refill: true,
    quality: 'Active Profiles',
    description: 'Add active members to grow your Facebook community group.',
    inputLabel: 'Facebook Group URL',
    inputPlaceholder: 'https://www.facebook.com/groups/yourgroupname',
    inputType: 'link'
  },

  // --- YOUTUBE ---
  {
    id: 'yt-subscribers-hq',
    platform: 'YouTube',
    category: 'YouTube Subscribers',
    name: 'YouTube Subscribers [Non-Drop 30 Days Refill Guarantee]',
    type: 'Subscribers',
    providerRatePer1000: 8900,
    min: 50,
    max: 100000,
    deliverySpeed: '500 - 1,500 / day',
    refill: true,
    quality: 'Real Accounts with Activity',
    description: 'Organic speed subscribers to grow your YouTube channel safely without drops.',
    inputLabel: 'YouTube Channel URL',
    inputPlaceholder: 'https://www.youtube.com/@channelname or channel link',
    inputType: 'link'
  },
  {
    id: 'yt-views-retention',
    platform: 'YouTube',
    category: 'YouTube Views',
    name: 'YouTube High Retention Views [Monetization & Ads Safe]',
    type: 'Views',
    providerRatePer1000: 1500,
    min: 500,
    max: 1000000,
    deliverySpeed: '10,000 - 25,000 / day',
    refill: true,
    quality: 'Monetization Safe Worldwide Views',
    description: 'High watch-time retention views to boost YouTube search ranking and suggested videos.',
    inputLabel: 'YouTube Video URL',
    inputPlaceholder: 'https://www.youtube.com/watch?v=ABCDEF12345',
    inputType: 'link'
  },
  {
    id: 'yt-watch-hours',
    platform: 'YouTube',
    category: 'YouTube Watch Hours',
    name: 'YouTube 4,000 Watch Hours Package [Monetization Enabler]',
    type: 'Watch Hours',
    providerRatePer1000: 24000,
    min: 100,
    max: 4000,
    deliverySpeed: '500 - 1,000 Hours / day',
    refill: true,
    quality: 'Monetization Approved Watch-time',
    description: 'Complete the YouTube Partner Program (YPP) 4,000 hours requirement. Requires 60+ min video.',
    inputLabel: 'YouTube 60+ Min Video URL',
    inputPlaceholder: 'https://www.youtube.com/watch?v=ABCDEF12345 (Video must be 60+ minutes)',
    inputType: 'link'
  },
  {
    id: 'yt-likes-instant',
    platform: 'YouTube',
    category: 'YouTube Likes',
    name: 'YouTube Video Likes [Instant High Retention]',
    type: 'Likes',
    providerRatePer1000: 1100,
    min: 50,
    max: 50000,
    deliverySpeed: '10,000 / day',
    refill: true,
    quality: 'Real Accounts',
    description: 'Instant likes on any YouTube video to build instant credibility.',
    inputLabel: 'YouTube Video URL',
    inputPlaceholder: 'https://www.youtube.com/watch?v=ABCDEF12345',
    inputType: 'link'
  },
  {
    id: 'yt-shorts-views',
    platform: 'YouTube',
    category: 'YouTube Views',
    name: 'YouTube Shorts Views [Viral Algorithm Boost]',
    type: 'Views',
    providerRatePer1000: 280,
    min: 500,
    max: 1000000,
    deliverySpeed: '100,000+ / day',
    refill: false,
    quality: 'Ultra Fast Shorts Views',
    description: 'Instant YouTube Shorts views to hit the shorts feed algorithm.',
    inputLabel: 'YouTube Shorts URL',
    inputPlaceholder: 'https://youtube.com/shorts/ABCDEF12345',
    inputType: 'link'
  },

  // --- TWITTER / X ---
  {
    id: 'x-followers-hq',
    platform: 'Twitter / X',
    category: 'X / Twitter Followers',
    name: 'X (Twitter) Followers [HQ Aged Profiles with Bio & PFP]',
    type: 'Followers',
    providerRatePer1000: 4200,
    min: 50,
    max: 50000,
    deliverySpeed: '2,000 - 5,000 / day',
    refill: true,
    quality: 'Aged Active Accounts',
    description: 'Authentic-looking X (Twitter) followers to enhance profile authority.',
    inputLabel: 'X / Twitter Profile Link or @Username',
    inputPlaceholder: 'https://x.com/username or @username',
    inputType: 'link'
  },
  {
    id: 'x-likes-retweets',
    platform: 'Twitter / X',
    category: 'X / Twitter Engagement',
    name: 'X (Twitter) Post Likes & Retweets [Instant Speed]',
    type: 'Likes',
    providerRatePer1000: 1600,
    min: 50,
    max: 25000,
    deliverySpeed: '10,000 / day',
    refill: true,
    quality: 'Instant Real Profiles',
    description: 'Instant likes and reposts for tweets to trigger timeline trends.',
    inputLabel: 'X / Twitter Post (Tweet) URL',
    inputPlaceholder: 'https://x.com/username/status/1234567890',
    inputType: 'link'
  },
  {
    id: 'x-views-impressions',
    platform: 'Twitter / X',
    category: 'X / Twitter Views',
    name: 'X (Twitter) Tweet Impressions & Views [Creator Monetization]',
    type: 'Views',
    providerRatePer1000: 140,
    min: 1000,
    max: 10000000,
    deliverySpeed: '500,000+ / day',
    refill: false,
    quality: 'Organic Impressing Counts',
    description: 'Massive impressions to meet the 5M impressions requirement for X Creator Revenue Sharing.',
    inputLabel: 'X / Twitter Post (Tweet) URL',
    inputPlaceholder: 'https://x.com/username/status/1234567890',
    inputType: 'link'
  },

  // --- TELEGRAM ---
  {
    id: 'tg-members-nondrop',
    platform: 'Telegram',
    category: 'Telegram Members',
    name: 'Telegram Channel / Group Members [Zero Drop 90 Days Guarantee]',
    type: 'Members',
    providerRatePer1000: 1300,
    min: 100,
    max: 100000,
    deliverySpeed: '20,000 / day',
    refill: true,
    quality: 'Zero Drop Real Accounts',
    description: 'Non-drop active channel and group members with 90 days automatic refill.',
    inputLabel: 'Telegram Channel / Group Link or @Handle',
    inputPlaceholder: 'https://t.me/channelname or @channelname',
    inputType: 'link'
  },
  {
    id: 'tg-post-views',
    platform: 'Telegram',
    category: 'Telegram Views',
    name: 'Telegram Post Views [Instant View Counts]',
    type: 'Views',
    providerRatePer1000: 110,
    min: 500,
    max: 500000,
    deliverySpeed: 'Instant Delivery',
    refill: false,
    quality: 'Instant Views',
    description: 'Add views to any Telegram channel post instantly.',
    inputLabel: 'Telegram Post Link',
    inputPlaceholder: 'https://t.me/channelname/123',
    inputType: 'link'
  },
  {
    id: 'tg-reactions-positive',
    platform: 'Telegram',
    category: 'Telegram Reactions',
    name: 'Telegram Positive Reactions (👍 / ❤️ / 🔥 / 🚀 / 👏)',
    type: 'Likes',
    providerRatePer1000: 400,
    min: 100,
    max: 20000,
    deliverySpeed: 'Instant Delivery',
    refill: false,
    quality: 'Natural Mix of Top Emojis',
    description: 'Boost engagement with natural emoji reactions on Telegram posts.',
    inputLabel: 'Telegram Post Link',
    inputPlaceholder: 'https://t.me/channelname/123',
    inputType: 'link'
  },

  // --- SPOTIFY & MUSIC ---
  {
    id: 'sp-artist-followers',
    platform: 'Spotify & Music',
    category: 'Spotify Followers',
    name: 'Spotify Artist Followers [Real Music Listeners]',
    type: 'Followers',
    providerRatePer1000: 3100,
    min: 100,
    max: 50000,
    deliverySpeed: '2,000 / day',
    refill: true,
    quality: 'Active Spotify Accounts',
    description: 'Grow your Spotify Artist profile followers to boost algorithmic playlist placement.',
    inputLabel: 'Spotify Artist URL',
    inputPlaceholder: 'https://open.spotify.com/artist/ABCDEF12345',
    inputType: 'link'
  },
  {
    id: 'sp-track-plays',
    platform: 'Spotify & Music',
    category: 'Spotify Plays',
    name: 'Spotify Track Streams / Plays [Royalty & Algorithmic Mix]',
    type: 'Plays',
    providerRatePer1000: 1100,
    min: 1000,
    max: 500000,
    deliverySpeed: '10,000 / day',
    refill: true,
    quality: 'USA / Europe / Global High Retention',
    description: 'High retention streams to trigger Release Radar and Discover Weekly algorithms.',
    inputLabel: 'Spotify Track / Album URL',
    inputPlaceholder: 'https://open.spotify.com/track/ABCDEF12345',
    inputType: 'link'
  },

  // --- THREADS ---
  {
    id: 'thr-followers-meta',
    platform: 'Threads',
    category: 'Threads Followers',
    name: 'Threads Followers [Meta Integrated Real Profiles]',
    type: 'Followers',
    providerRatePer1000: 3600,
    min: 50,
    max: 25000,
    deliverySpeed: '3,000 / day',
    refill: true,
    quality: 'High Quality Meta Linked Profiles',
    description: 'Grow your Threads audience fast with real-looking meta accounts.',
    inputLabel: 'Threads Profile URL or @Username',
    inputPlaceholder: 'https://www.threads.net/@username or @username',
    inputType: 'link'
  },
  {
    id: 'thr-likes-reposts',
    platform: 'Threads',
    category: 'Threads Likes',
    name: 'Threads Post Likes & Reposts [Instant Delivery]',
    type: 'Likes',
    providerRatePer1000: 890,
    min: 50,
    max: 20000,
    deliverySpeed: '5,000 / day',
    refill: true,
    quality: 'Real Accounts',
    description: 'Instant engagement for Threads posts.',
    inputLabel: 'Threads Post URL',
    inputPlaceholder: 'https://www.threads.net/@username/post/ABCDEF123',
    inputType: 'link'
  },

  // --- LINKEDIN ---
  {
    id: 'li-followers-connections',
    platform: 'LinkedIn',
    category: 'LinkedIn Followers',
    name: 'LinkedIn Profile & Company Page Followers [HQ Professional Accounts]',
    type: 'Followers',
    providerRatePer1000: 5200,
    min: 50,
    max: 20000,
    deliverySpeed: '1,000 - 2,000 / day',
    refill: true,
    quality: 'Aged Business & Professional Profiles',
    description: 'Elevate your B2B credibility and professional network with high quality profile followers.',
    inputLabel: 'LinkedIn Profile / Company Page URL',
    inputPlaceholder: 'https://www.linkedin.com/in/username or company page',
    inputType: 'link'
  },
  {
    id: 'li-post-likes',
    platform: 'LinkedIn',
    category: 'LinkedIn Likes',
    name: 'LinkedIn Post Likes & Celebrates [Instant Algorithm Boost]',
    type: 'Likes',
    providerRatePer1000: 1850,
    min: 25,
    max: 10000,
    deliverySpeed: '2,000 / day',
    refill: true,
    quality: 'Real Business Profiles',
    description: 'Boost engagement on LinkedIn articles and posts to expand feed reach.',
    inputLabel: 'LinkedIn Post URL',
    inputPlaceholder: 'https://www.linkedin.com/posts/...',
    inputType: 'link'
  },

  // --- DISCORD ---
  {
    id: 'dc-server-members',
    platform: 'Discord',
    category: 'Discord Members',
    name: 'Discord Server Members [Online & Offline Mix - High Quality]',
    type: 'Members',
    providerRatePer1000: 2900,
    min: 100,
    max: 50000,
    deliverySpeed: '5,000 / day',
    refill: true,
    quality: 'Realistic Avatars & Nicknames',
    description: 'Grow your Discord gaming or Web3 server population instantly.',
    inputLabel: 'Discord Server Invite Link (Never Expiring)',
    inputPlaceholder: 'https://discord.gg/yourinvitecode',
    inputType: 'link'
  },

  // --- TWITCH & STREAMING ---
  {
    id: 'tw-channel-followers',
    platform: 'Twitch & Streaming',
    category: 'Twitch Followers',
    name: 'Twitch Channel Followers [Affiliate & Partner Booster]',
    type: 'Followers',
    providerRatePer1000: 2400,
    min: 50,
    max: 50000,
    deliverySpeed: '5,000 / day',
    refill: true,
    quality: 'Real Gamer Profiles',
    description: 'Reach Twitch Affiliate status faster with high retention channel followers.',
    inputLabel: 'Twitch Channel URL',
    inputPlaceholder: 'https://twitch.tv/channelname',
    inputType: 'link'
  },

  // --- SNAPCHAT ---
  {
    id: 'sc-public-followers',
    platform: 'Snapchat',
    category: 'Snapchat Followers',
    name: 'Snapchat Public Profile Followers [High Quality Global]',
    type: 'Followers',
    providerRatePer1000: 4800,
    min: 50,
    max: 20000,
    deliverySpeed: '1,000 / day',
    refill: true,
    quality: 'HQ Active Snapchat Profiles',
    description: 'Grow your Snapchat public creator profile audience and reach.',
    inputLabel: 'Snapchat Profile URL or @Username',
    inputPlaceholder: 'https://www.snapchat.com/add/username or @username',
    inputType: 'link'
  },

  // --- REDDIT ---
  {
    id: 'rd-post-upvotes',
    platform: 'Reddit',
    category: 'Reddit Upvotes',
    name: 'Reddit Post Upvotes [Frontpage & Subreddit Top Booster]',
    type: 'Likes',
    providerRatePer1000: 6500,
    min: 20,
    max: 5000,
    deliverySpeed: '500 / hour',
    refill: false,
    quality: 'Aged Reddit Accounts with Karma',
    description: 'Send upvotes to any Reddit submission to rank higher on Hot and Top feeds.',
    inputLabel: 'Reddit Post URL',
    inputPlaceholder: 'https://reddit.com/r/subreddit/comments/...',
    inputType: 'link'
  },

  // --- REVIEWS & RATINGS ---
  {
    id: 'rev-google-5star',
    platform: 'Reviews & Ratings',
    category: 'Google Maps Reviews',
    name: 'Google Maps Business 5-Star Reviews [Custom Written & Geo-Targeted]',
    type: 'Reviews',
    providerRatePer1000: 18000,
    min: 5,
    max: 500,
    deliverySpeed: '3 - 5 / day (Natural Drip)',
    refill: true,
    quality: 'Aged Local Google Accounts (100% Non-Drop Guarantee)',
    description: 'Boost local business trust and SEO ranking with custom high-rating reviews.',
    inputLabel: 'Google Maps Business Link + Custom Review Text',
    inputPlaceholder: 'https://maps.app.goo.gl/... \nInclude review details per line',
    inputType: 'custom_comments'
  },

  // --- WEBSITE TRAFFIC & SEO ---
  {
    id: 'web-traffic-organic',
    platform: 'Website Traffic & SEO',
    category: 'Website Visitors',
    name: 'High Quality Organic Web Traffic [Google Search Keywords - Google Analytics Tracked]',
    type: 'Website Visits',
    providerRatePer1000: 850,
    min: 1000,
    max: 5000000,
    deliverySpeed: '50,000 / day',
    refill: false,
    quality: '100% Google Analytics 4 (GA4) Trackable Visitors',
    description: 'Real desktop and mobile visitors with 60s+ session duration to lower bounce rate and boost SEO.',
    inputLabel: 'Website URL (Must include https://)',
    inputPlaceholder: 'https://yourwebsite.com',
    inputType: 'link'
  },

  // --- WHATSAPP ---
  {
    id: 'wa-channel-members',
    platform: 'WhatsApp',
    category: 'WhatsApp Channel Members',
    name: 'WhatsApp Channel Followers & Members [Real Active Nigerian & Global]',
    type: 'Members',
    providerRatePer1000: 2200,
    min: 50,
    max: 50000,
    deliverySpeed: '5,000 / day',
    refill: true,
    quality: 'Active WhatsApp Mobile Numbers',
    description: 'Boost WhatsApp Channel subscriber counts to build social proof and reach.',
    inputLabel: 'WhatsApp Channel Invite Link',
    inputPlaceholder: 'https://whatsapp.com/channel/0029Va...',
    inputType: 'link'
  }
];

let activeSmmFetchPromise: Promise<any[]> | null = null;

// Helper: Fetch ALL services from OneGridHub SMM API with full multi-page pagination
const fetchAllOneGridHubSmmServices = async (): Promise<any[]> => {
  if (activeSmmFetchPromise) {
    return activeSmmFetchPromise;
  }

  activeSmmFetchPromise = (async () => {
    const isReal = isRealOneGridHubKey();
    if (!isReal) {
      console.log('[SocialBoost] Provider API key not configured or demo key used.');
      return [];
    }
    const apiKey = getOneGridHubApiKey();
    const baseUrl = getOneGridHubConfig().oneGridBaseUrl;

    try {
      console.log('[SocialBoost] Checking SMM services catalogue...');
      const q1 = new URLSearchParams({
        endpoint: 'smm_services',
        page: '1',
        limit: '200',
        api_key: apiKey
      }).toString();

      let res1: Response | null = null;
      try {
        res1 = await fetch(`${baseUrl}?${q1}`, {
          headers: { 'Accept': 'application/json', 'User-Agent': 'ZENET-Hub/1.0' },
          signal: AbortSignal.timeout(8000)
        });
      } catch {
        res1 = null;
      }

      if (!res1 || !res1.ok) {
        if (cachedLiveProviderServices.length > 0) {
          console.log(`[SocialBoost] Upstream provider unreachable; continuing with ${cachedLiveProviderServices.length} cached services.`);
          return cachedLiveProviderServices;
        }
        return [];
      }

      const data1: any = await res1.json().catch(() => null);
      if (!data1 || (data1.status !== 'success' && !Array.isArray(data1.services) && !Array.isArray(data1))) {
        console.warn('[SocialBoost] Unexpected response structure from SMM services API');
        return cachedLiveProviderServices.length > 0 ? cachedLiveProviderServices : [];
      }

      const rawList1 = Array.isArray(data1) ? data1 : (data1.services || data1.data || []);
      const totalCount = Number(data1.total) || rawList1.length;
      const totalPages = Number(data1.pages) || Math.ceil(totalCount / 200) || 1;

      console.log(`[SocialBoost] OneGridHub reports ${totalCount} total services across ${totalPages} pages (limit 200/page).`);

      let allRawServices: any[] = [...rawList1];

      if (totalPages > 1) {
        const pageNumbers: number[] = [];
        for (let p = 2; p <= totalPages; p++) {
          pageNumbers.push(p);
        }

        // Fetch remaining pages gently in batches of 3 with exponential backoff and inter-batch pause
        const batchSize = 3;
        for (let i = 0; i < pageNumbers.length; i += batchSize) {
          const batch = pageNumbers.slice(i, i + batchSize);
          const batchPromises = batch.map(async (pageNum) => {
            const maxAttempts = 3;
            for (let attempt = 1; attempt <= maxAttempts; attempt++) {
              try {
                const q = new URLSearchParams({
                  endpoint: 'smm_services',
                  page: String(pageNum),
                  limit: '200',
                  api_key: apiKey
                }).toString();

                const r = await fetch(`${baseUrl}?${q}`, {
                  headers: { 'Accept': 'application/json', 'User-Agent': 'ZENET-Hub/1.0' },
                  signal: AbortSignal.timeout(15000)
                }).catch(() => null);

                if (r && r.ok) {
                  const d: any = await r.json().catch(() => null);
                  if (!d) return [];
                  const items = Array.isArray(d) ? d : (d.services || d.data || []);
                  if (Array.isArray(items)) {
                    return items;
                  }
                } else if (r && (r.status === 404 || r.status === 400)) {
                  // Page index beyond available count, stop retrying
                  return [];
                }
              } catch {
                if (attempt === maxAttempts) {
                  console.log(`[SocialBoost] Note: SMM page ${pageNum} omitted (upstream unreachable)`);
                } else {
                  const backoffMs = (attempt * 1000) + Math.floor(Math.random() * 300);
                  await new Promise(resolve => setTimeout(resolve, backoffMs));
                }
              }
            }
            return [];
          });

          const batchResults = await Promise.all(batchPromises);
          for (const pageServices of batchResults) {
            if (Array.isArray(pageServices) && pageServices.length > 0) {
              allRawServices.push(...pageServices);
            }
          }

          // Gentle pause between batches to prevent upstream connection throttling
          if (i + batchSize < pageNumbers.length) {
            await new Promise(resolve => setTimeout(resolve, 300));
          }
        }
      }

      console.log(`[SocialBoost] Successfully fetched all ${allRawServices.length} raw services from OneGridHub API.`);

      if (allRawServices.length > 0) {
        // Normalize all services
        const normalized = allRawServices.map((item, idx) => normalizeOneGridHubService(item, idx));

        // If a few individual pages dropped under network jitter, merge with existing cache to keep 100% of services
        if (cachedLiveProviderServices.length > 0 && normalized.length < cachedLiveProviderServices.length) {
          const existingMap = new Map(cachedLiveProviderServices.map(s => [s.providerServiceId || s.id, s]));
          for (const item of normalized) {
            existingMap.set(item.providerServiceId || item.id, item);
          }
          cachedLiveProviderServices = Array.from(existingMap.values());
        } else {
          cachedLiveProviderServices = normalized;
        }

        lastCatalogueSyncTime = new Date().toISOString();
        
        // Save metadata snapshot
        await saveSocialBoostCatalogueToDb(cachedLiveProviderServices);

        return cachedLiveProviderServices;
      }
      return cachedLiveProviderServices.length > 0 ? cachedLiveProviderServices : [];
    } catch (err: any) {
      const safeMsg = err?.message?.includes('fetch failed') ? 'upstream provider currently unreachable' : (err?.message || 'sync notice');
      console.log('[SocialBoost] SMM services sync note:', safeMsg);
      return cachedLiveProviderServices.length > 0 ? cachedLiveProviderServices : [];
    } finally {
      activeSmmFetchPromise = null;
    }
  })();

  return activeSmmFetchPromise;
};

// Helper: Query OneGridHub SMM upstream endpoint for orders, status, services, and balance
const queryOneGridHubSmm = async (action: string, params: Record<string, any> = {}) => {
  const isReal = isRealOneGridHubKey();
  if (!isReal) {
    return null;
  }
  const apiKey = getOneGridHubApiKey();

  // If requesting services, use the comprehensive multi-page fetcher
  if (action === 'services' || action === 'smm_services' || action === 'getServicesList') {
    return await fetchAllOneGridHubSmmServices();
  }

  const baseUrl = getOneGridHubConfig().oneGridBaseUrl;

  // 1. Placing an SMM Order (action === 'add' or 'order' or 'smm_order')
  if (action === 'add' || action === 'order' || action === 'smm_order') {
    const serviceId = params.service || params.service_id || params.serviceId;
    const targetLink = params.link || params.target || params.url;
    const qty = params.quantity || params.qty || params.amount;
    const comments = params.comments || params.custom_comments;

    const requestParams: Record<string, string> = {
      endpoint: 'smm_order',
      api_key: apiKey,
      service: String(serviceId),
      link: String(targetLink),
      quantity: String(qty)
    };
    if (comments) {
      requestParams.comments = String(comments);
    }

    try {
      // Try GET query string
      const q = new URLSearchParams(requestParams).toString();
      const res = await fetch(`${baseUrl}?${q}`, {
        headers: { 'Accept': 'application/json' },
        signal: AbortSignal.timeout(7000)
      });
      if (res.ok) {
        const text = await res.text();
        try {
          const parsed = JSON.parse(text);
          if (parsed && (parsed.order || parsed.order_id || parsed.status === 'success')) {
            return parsed;
          }
        } catch {}
      }

      // Try POST form
      const form = new URLSearchParams(requestParams);
      const postRes = await fetch(baseUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': 'application/json'
        },
        body: form.toString(),
        signal: AbortSignal.timeout(7000)
      });
      if (postRes.ok) {
        const text = await postRes.text();
        try {
          return JSON.parse(text);
        } catch {
          return { rawText: text };
        }
      }
    } catch (e: any) {
      const msg = e?.message?.includes('fetch failed') ? 'upstream unreachable' : (e?.message || 'notice');
      console.warn('[SocialBoost SMM Order] Upstream dispatch note:', msg);
    }
    return null;
  }

  // 2. Checking SMM Order Status (action === 'status' or 'smm_status')
  if (action === 'status' || action === 'smm_status' || action === 'order_status') {
    const orderId = params.order || params.order_id || params.orderId || params.id;
    try {
      const q = new URLSearchParams({
        endpoint: 'smm_status',
        api_key: apiKey,
        order: String(orderId)
      }).toString();

      const res = await fetch(`${baseUrl}?${q}`, {
        headers: { 'Accept': 'application/json' },
        signal: AbortSignal.timeout(6000)
      });
      if (res.ok) {
        const parsed = await res.json();
        return parsed;
      }
    } catch (e: any) {
      const msg = e?.message?.includes('fetch failed') ? 'upstream unreachable' : (e?.message || 'notice');
      console.warn('[SocialBoost SMM Status] Status query note:', msg);
    }
    return null;
  }

  // 3. Checking SMM Balance
  if (action === 'balance' || action === 'getBalance') {
    try {
      const q = new URLSearchParams({
        endpoint: 'balance',
        api_key: apiKey
      }).toString();

      const res = await fetch(`${baseUrl}?${q}`, {
        headers: { 'Accept': 'application/json' },
        signal: AbortSignal.timeout(5000)
      });
      if (res.ok) {
        return await res.json();
      }
    } catch {}
    return null;
  }

  return null;
};

// Helper: Clean emoji & decorative symbols
const cleanEmojiSymbols = (str: string): string => {
  return (str || '').replace(/[🔵🔴🟢🟡🟣⚫⚪⭐🔥⚡✨💥👑🎯🏆💎✔️✔\uD83C-\uDBFF\uDC00-\uDFFF]/g, '').trim();
};

// Helper: Dynamically extract platform from category/service name without dropping any service
const extractDynamicPlatform = (category: string, name: string): string => {
  const cat = (category || '').trim();
  const cleanName = (name || '').trim();
  const combined = (cat + ' ' + cleanName).toLowerCase();
  
  if (combined.includes('instagram') || combined.includes('ig ') || combined.includes(' ig') || combined.includes('ig-') || combined.includes('ig reels') || combined.includes('ig story') || combined.includes('ig followers')) {
    return 'Instagram';
  }
  if (combined.includes('facebook') || combined.includes('fb ') || combined.includes('fb-') || combined.includes('meta ') || combined.includes('fb page') || combined.includes('fb post')) {
    return 'Facebook';
  }
  if (combined.includes('tiktok') || combined.includes('tt ') || combined.includes('douyin') || combined.includes('tiktok followers') || combined.includes('tiktok likes')) {
    return 'TikTok';
  }
  if (combined.includes('youtube') || combined.includes('yt ') || combined.includes('yt-') || combined.includes('shorts') || combined.includes('watch hour') || combined.includes('subscribers')) {
    return 'YouTube';
  }
  if (combined.includes('twitter') || combined.includes(' x ') || combined.includes('x.com') || combined.includes('tweet') || combined.includes('x views') || combined.includes('x followers') || combined.includes('x likes') || combined.includes('x retweets') || combined.includes('x poll')) {
    return 'Twitter / X';
  }
  if (combined.includes('telegram') || combined.includes('tg ') || combined.includes('tg-') || combined.includes('t.me')) {
    return 'Telegram';
  }
  if (combined.includes('linkedin') || combined.includes('linked in')) {
    return 'LinkedIn';
  }
  if (combined.includes('spotify') || combined.includes('audiomack') || combined.includes('soundcloud') || combined.includes('apple music') || combined.includes('deezer') || combined.includes('boomplay') || combined.includes('mixcloud') || combined.includes('shazam') || combined.includes('hypeddit')) {
    return 'Spotify & Music';
  }
  if (combined.includes('threads')) {
    return 'Threads';
  }
  if (combined.includes('discord')) {
    return 'Discord';
  }
  if (combined.includes('twitch') || combined.includes('kick') || combined.includes('rumble') || combined.includes('vimeo') || combined.includes('trovo') || combined.includes('streamers') || combined.includes('sooplive') || combined.includes('openrec') || combined.includes('panda.tv') || combined.includes('mixch') || combined.includes('live stream')) {
    return 'Twitch & Streaming';
  }
  if (combined.includes('snapchat')) {
    return 'Snapchat';
  }
  if (combined.includes('reddit')) {
    return 'Reddit';
  }
  if (combined.includes('pinterest')) {
    return 'Pinterest';
  }
  if (combined.includes('quora')) {
    return 'Quora';
  }
  if (combined.includes('bluesky')) {
    return 'BlueSky';
  }
  if (combined.includes('steam') || combined.includes('roblox') || combined.includes('pubg') || combined.includes('riot games') || combined.includes('valorant') || combined.includes('league of legends') || combined.includes('brawl stars') || combined.includes('free fire') || combined.includes('ea play') || combined.includes('xbox') || combined.includes('gaming') || combined.includes('gamers')) {
    return 'Gaming & Accounts';
  }
  if (combined.includes('behance') || combined.includes('dribbble') || combined.includes('canva') || combined.includes('freepik') || combined.includes('envato') || combined.includes('capcut')) {
    return 'Design & Creative';
  }
  if (combined.includes('trustpilot') || combined.includes('google reviews') || combined.includes('tripadvisor') || combined.includes('review') || combined.includes('rating') || combined.includes('google maps')) {
    return 'Reviews & Ratings';
  }
  if (combined.includes('traffic') || combined.includes('website') || combined.includes('seo ') || combined.includes('backlinks') || combined.includes('visitors') || combined.includes('google search')) {
    return 'Website Traffic & SEO';
  }
  if (combined.includes('whatsapp')) {
    return 'WhatsApp';
  }

  return 'Other Services';
};

// Helper: Normalize upstream OneGridHub service dynamically preserving full fidelity
const normalizeOneGridHubService = (item: any, index: number) => {
  const rawId = String(item.service || item.id || `ogh-${index + 1}`);
  const rawName = String(item.name || item.service_name || 'Social Media Boosting Service').trim();
  const rawCategory = String(item.category || 'General').trim();
  const rawRate = Number(item.rate_per_1000 || item.rate || item.price) || 0;
  // Rates in NGN from OneGridHub SMM endpoint
  const providerRateNgn = Math.max(1, Math.round(rawRate));

  const platform = extractDynamicPlatform(rawCategory, rawName);
  
  // Extract provider description or clean default
  const description = item.desc || item.description || `Automated fast delivery for ${rawName}. Direct provider routing from OneGridHub network.`;

  const minQty = Math.max(1, Number(item.min) || 50);
  const maxQty = Math.max(minQty, Number(item.max) || 100000);

  // Type extraction
  const lowerAll = (rawCategory + ' ' + rawName).toLowerCase();
  let type = item.type || 'Service';
  if (lowerAll.includes('follower')) type = 'Followers';
  else if (lowerAll.includes('like')) type = 'Likes';
  else if (lowerAll.includes('view') || lowerAll.includes('impression')) type = 'Views';
  else if (lowerAll.includes('subscriber') || lowerAll.includes('sub ')) type = 'Subscribers';
  else if (lowerAll.includes('member')) type = 'Members';
  else if (lowerAll.includes('comment')) type = 'Comments';
  else if (lowerAll.includes('share') || lowerAll.includes('repost') || lowerAll.includes('retweet')) type = 'Shares';
  else if (lowerAll.includes('watch hour') || lowerAll.includes('watchtime') || lowerAll.includes('watch time')) type = 'Watch Hours';
  else if (lowerAll.includes('play') || lowerAll.includes('stream') || lowerAll.includes('listener')) type = 'Plays & Streams';
  else if (lowerAll.includes('reaction') || lowerAll.includes('poll')) type = 'Reactions';
  else if (lowerAll.includes('review') || lowerAll.includes('rating')) type = 'Reviews';
  else if (lowerAll.includes('traffic') || lowerAll.includes('visit')) type = 'Website Visits';

  const isCustomComments = item.type === 'Custom Comments' || item.type === 'custom_comments' || lowerAll.includes('custom comment');
  const refillGuarantee = Boolean(item.refill && item.refill !== '0' && item.refill !== 'false' && item.refill !== false);

  return {
    id: `ogh-svc-${rawId}`,
    providerServiceId: rawId,
    platform,
    category: rawCategory,
    name: rawName,
    type,
    providerRatePer1000: Math.max(1, providerRateNgn),
    min: minQty,
    max: maxQty,
    deliverySpeed: item.dripfeed ? 'Drip-feed Capable' : (item.deliverySpeed || 'Instant Start Delivery'),
    refill: refillGuarantee,
    quality: item.quality || 'Verified High Quality',
    description,
    inputLabel: isCustomComments ? 'Target Link + Custom Comments' : `${platform} Target URL or @Username`,
    inputPlaceholder: isCustomComments ? 'Enter 1 comment per line' : `https://${platform.toLowerCase().replace(/[^a-z0-9]/g, '')}.com/... or @username`,
    inputType: isCustomComments ? 'custom_comments' : 'link'
  };
};

// Background live sync on startup: load DB cache immediately, then sync fresh upstream catalogue if needed
setTimeout(async () => {
  try {
    await loadSocialBoostCatalogueFromDb();
    
    // Check if we already have a robust cache (>= 500 services)
    if (cachedLiveProviderServices.length >= 500) {
      console.log(`[SocialBoost] Warm cache active with ${cachedLiveProviderServices.length} services (last synced: ${lastCatalogueSyncTime || 'local cache'}).`);
      return;
    }

    const live = await fetchAllOneGridHubSmmServices();
    if (Array.isArray(live) && live.length > 0) {
      console.log(`[SocialBoost] Auto-synced & cached ${live.length} dynamic live services from OneGridHub.`);
    }
  } catch (e: any) {
    const msg = e?.message?.includes('fetch failed') ? 'upstream offline' : (e?.message || 'sync pending');
    console.log('[SocialBoost] Background sync note:', msg);
  }
}, 1000);

// ============================================================================
// VOIKER BOOSTING GATEWAY & SOCIAL BOOST ROUTES
// ============================================================================
const handleVoikerRequest = async (req: express.Request, res: express.Response, explicitAction?: string) => {
  return handleVoikerGateway(req, res, db, firebaseProjectId, verifyFirebaseIdToken, explicitAction);
};

// Dedicated Voiker routes
app.all('/api/voiker', (req, res) => handleVoikerRequest(req, res));
app.all('/api/voiker/:action', (req, res) => handleVoikerRequest(req, res, req.params.action));

// Social Boost routes routed directly to Voiker Boosting Gateway
app.all('/api/social-boost', (req, res) => handleVoikerRequest(req, res));
app.all('/api/social-boost/status/:orderId', (req, res) => {
  req.query.orderId = req.params.orderId;
  return handleVoikerRequest(req, res, 'status');
});
app.all('/api/social-boost/:action', (req, res) => handleVoikerRequest(req, res, req.params.action));
app.all('/.netlify/functions/social-boost', (req, res) => handleVoikerRequest(req, res));
app.all('/.netlify/functions/social-boost/:action', (req, res) => handleVoikerRequest(req, res, req.params.action));

// 1. GET /api/social-boost/services
app.get('/api/social-boost/services', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const callerEmail = (req.query.callerEmail || req.headers['x-caller-email'] || req.headers['x-admin-email'] || '').toString().toLowerCase().trim();
    let isOwner = callerEmail === 'azeezmusharaf4@gmail.com';
    if (!isOwner && authHeader) {
      const uid = verifyFirebaseIdToken(authHeader, firebaseProjectId);
      if (uid && db) {
        try {
          const userDoc = await getDoc(doc(db, 'users', uid));
          if (userDoc.exists()) {
            const data = userDoc.data();
            const email = (data.email || '').toLowerCase();
            isOwner = email === 'azeezmusharaf4@gmail.com' || data.role === 'owner' || data.role === 'admin';
          }
        } catch {}
      }
    }

    if (cachedLiveProviderServices.length === 0) {
      await loadSocialBoostCatalogueFromDb();
      if (cachedLiveProviderServices.length === 0) {
        await fetchAllOneGridHubSmmServices();
      }
    }

    const settings = await getSocialBoostPricingSettings();

    // Source services: prioritize live/cached provider services containing all services
    let rawServicePool = cachedLiveProviderServices.length > 0 
      ? [...cachedLiveProviderServices] 
      : [...BASE_SOCIAL_SERVICES];

    // Ensure rawServicePool is NEVER empty: if for any reason it is empty, seed with BASE_SOCIAL_SERVICES
    if (!Array.isArray(rawServicePool) || rawServicePool.length === 0) {
      rawServicePool = [...BASE_SOCIAL_SERVICES];
    }

    // Helper to check platform active status flexibly with alias matching
    const checkPlatformActive = (plat: string): boolean => {
      if (!settings.platformStatus) return true;
      if (settings.platformStatus[plat] !== undefined) return settings.platformStatus[plat] !== false;
      const normalized = plat.toLowerCase().replace(/[^a-z0-9]/g, '');
      for (const [k, v] of Object.entries(settings.platformStatus)) {
        if (k.toLowerCase().replace(/[^a-z0-9]/g, '') === normalized) {
          return v !== false;
        }
      }
      return true;
    };

    // Check whether curatedServiceIds actually contains valid IDs in the current pool
    const hasCuratedMatch = Array.isArray(settings.curatedServiceIds) && settings.curatedServiceIds.length > 0 &&
      rawServicePool.some(s => settings.curatedServiceIds!.includes(s.id));

    // Map and apply price calculations + overrides
    const computedServices = rawServicePool.map(svc => {
      const providerRate = Number(svc.providerRatePer1000) || 500;
      const override = (settings.serviceOverrides && settings.serviceOverrides[svc.id]) || {};
      
      const effectiveMarkupPercent = typeof override.customMarkupPercent === 'number' 
        ? override.customMarkupPercent 
        : (settings.defaultMarkupPercent || 45);

      let customerRate = typeof override.customRatePer1000 === 'number'
        ? override.customRatePer1000
        : Math.round(providerRate * (1 + effectiveMarkupPercent / 100));

      const minMarkup = typeof settings.minMarkupPer1k === 'number' ? settings.minMarkupPer1k : 350;
      if (customerRate - providerRate < minMarkup) {
        customerRate = providerRate + minMarkup;
      }

      // Apply pricing style if configured
      if (settings.pricingStyle === 'clean') {
        customerRate = Math.round(customerRate / 100) * 100;
      } else if (settings.pricingStyle === 'tiered') {
        customerRate = Math.ceil(customerRate / 50) * 50;
      }

      const markupPer1k = customerRate - providerRate;
      const platformName = svc.platform || 'General';
      const isPlatformActive = checkPlatformActive(platformName);
      const isSvcDisabled = Array.isArray(settings.disabledServices) ? (settings.disabledServices.includes(svc.id) || override.enabled === false) : override.enabled === false;
      const isCurated = hasCuratedMatch ? settings.curatedServiceIds!.includes(svc.id) : true;

      const isActive = isPlatformActive && !isSvcDisabled && isCurated;

      if (isOwner) {
        return {
          ...svc,
          platform: platformName,
          category: svc.category || 'General',
          name: svc.name || 'Service',
          ratePer1000: customerRate,
          providerRatePer1000: providerRate,
          markupPer1000: markupPer1k,
          isActive,
          isCurated,
          customMarkupPercent: override.customMarkupPercent,
          customRatePer1000: override.customRatePer1000
        };
      } else {
        const { providerRatePer1000: _p, providerServiceId: _ps, ...cleanSvc } = svc as any;
        return {
          ...cleanSvc,
          platform: platformName,
          category: svc.category || 'General',
          name: svc.name || 'Service',
          ratePer1000: customerRate,
          isActive
        };
      }
    });

    // Tag the Best Value / Cheapest option per platform
    const platformCheapestMap: Record<string, { serviceId: string; rate: number }> = {};
    computedServices.forEach(s => {
      if (s.isActive) {
        if (!platformCheapestMap[s.platform] || s.ratePer1000 < platformCheapestMap[s.platform].rate) {
          platformCheapestMap[s.platform] = { serviceId: s.id, rate: s.ratePer1000 };
        }
      }
    });

    const finalServices = computedServices.map(s => {
      const isPinnedBest = settings.bestValueServiceIds?.[s.platform] === s.id;
      const isAutoCheapest = platformCheapestMap[s.platform]?.serviceId === s.id;
      const isBest = isPinnedBest || isAutoCheapest;
      return {
        ...s,
        isBestValue: Boolean(isBest),
        isCheapest: Boolean(isAutoCheapest)
      };
    });

    // Priority order for platform display matching OneGridHub & user expectations
    const PLATFORM_PRIORITY = [
      'Instagram',
      'Facebook',
      'TikTok',
      'YouTube',
      'Twitter / X',
      'Telegram',
      'LinkedIn',
      'Spotify & Music',
      'Threads',
      'Discord',
      'Twitch & Streaming',
      'Snapchat',
      'Reddit',
      'Pinterest',
      'Quora',
      'Reviews & Ratings',
      'Website Traffic & SEO',
      'WhatsApp',
      'Other Services'
    ];

    const getPlatformPriorityIndex = (p: string) => {
      const idx = PLATFORM_PRIORITY.findIndex(item => item.toLowerCase() === (p || '').toLowerCase());
      return idx === -1 ? 999 : idx;
    };

    // 3-Level Ordering:
    // Level 1: Platform (Priority order, then A-Z)
    // Level 2: Customer price (ratePer1000) LOWEST to HIGHEST (cheapest first)
    // Level 3: Category (A-Z), Service Name (A-Z)
    const sortedServices = [...finalServices].sort((a, b) => {
      const pA = getPlatformPriorityIndex(a.platform);
      const pB = getPlatformPriorityIndex(b.platform);
      if (pA !== pB) return pA - pB;
      const platformCmp = (a.platform || '').localeCompare(b.platform || '');
      if (platformCmp !== 0) return platformCmp;
      
      const priceA = Number(a.ratePer1000) || 0;
      const priceB = Number(b.ratePer1000) || 0;
      if (priceA !== priceB) return priceA - priceB;

      const catCmp = (a.category || '').localeCompare(b.category || '');
      if (catCmp !== 0) return catCmp;
      return (a.name || '').localeCompare(b.name || '');
    });

    // Return all sorted services so customers & owners receive the complete live provider catalogue
    let visibleServices = sortedServices.filter(s => s.isActive !== false);

    // If for any reason active filtering returned nothing, preserve all sorted services
    if (visibleServices.length === 0 && sortedServices.length > 0) {
      visibleServices = sortedServices.map(s => ({ ...s, isActive: true }));
    }

    if (visibleServices.length === 0) {
      // Ultimate safety fallback if pool was empty
      visibleServices = BASE_SOCIAL_SERVICES.map(s => ({
        ...s,
        ratePer1000: Math.round(s.providerRatePer1000 * 1.45),
        isActive: true,
        isBestValue: false,
        isCheapest: false
      }));
    }

    // Ensure unique IDs in visibleServices
    const seenSvcIds = new Set<string>();
    visibleServices = visibleServices.filter(s => {
      if (!s.id || seenSvcIds.has(s.id)) return false;
      seenSvcIds.add(s.id);
      return true;
    });

    // Extract dynamic list of Level 1 platforms (ordered by priority)
    const dynamicPlatforms = Array.from(new Set(visibleServices.map(s => s.platform || 'Other Services'))).sort((a, b) => {
      const pA = getPlatformPriorityIndex(a);
      const pB = getPlatformPriorityIndex(b);
      if (pA !== pB) return pA - pB;
      return a.localeCompare(b);
    });

    // Extract dynamic map of Level 2 categories per platform (A-Z)
    const platformCategoriesMap: Record<string, string[]> = {};
    dynamicPlatforms.forEach(plat => {
      const cats = Array.from(new Set(visibleServices.filter(s => (s.platform || 'General') === plat).map(s => s.category || 'General'))).sort((a, b) => a.localeCompare(b));
      platformCategoriesMap[plat] = cats;
    });

    res.json({
      success: true,
      services: visibleServices,
      platforms: dynamicPlatforms,
      categoriesByPlatform: platformCategoriesMap,
      platformStatus: settings.platformStatus || {},
      bestValueServiceIds: settings.bestValueServiceIds || {},
      lastSyncedAt: lastCatalogueSyncTime,
      totalCount: visibleServices.length,
      isOwner
    });

  } catch (err: any) {
    console.error('[SocialBoost] Error fetching services:', err);
    // Graceful fallback with BASE_SOCIAL_SERVICES rather than returning 500 error
    const fallbackServices = BASE_SOCIAL_SERVICES.map(s => ({
      ...s,
      ratePer1000: Math.round(s.providerRatePer1000 * 1.45),
      isActive: true,
      isBestValue: false,
      isCheapest: false
    }));
    const dynamicPlatforms = Array.from(new Set(fallbackServices.map(s => s.platform || 'Other Services')));
    const platformCategoriesMap: Record<string, string[]> = {};
    dynamicPlatforms.forEach(plat => {
      platformCategoriesMap[plat] = Array.from(new Set(fallbackServices.filter(s => s.platform === plat).map(s => s.category || 'General')));
    });

    res.json({ 
      success: true, 
      services: fallbackServices,
      platforms: dynamicPlatforms,
      categoriesByPlatform: platformCategoriesMap,
      totalCount: fallbackServices.length,
      isOwner: false,
      note: 'Loaded built-in baseline catalog'
    });
  }
});

// 1b. GET /api/social-boost/provider-services (Owner: view all provider services + sync status)
app.get('/api/social-boost/provider-services', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ success: false, error: 'Authentication required' });
    const uid = verifyFirebaseIdToken(authHeader, firebaseProjectId);
    if (!uid || !db) return res.status(403).json({ success: false, error: 'Unauthorized' });

    const userDoc = await getDoc(doc(db, 'users', uid));
    if (!userDoc.exists()) return res.status(403).json({ success: false, error: 'User profile not found' });
    const email = (userDoc.data().email || '').toLowerCase();
    const role = userDoc.data().role;
    if (email !== 'azeezmusharaf4@gmail.com' && role !== 'owner' && role !== 'admin') {
      return res.status(403).json({ success: false, error: 'Forbidden: Owner permission required.' });
    }

    const settings = await getSocialBoostPricingSettings();
    const isRealKey = isRealOneGridHubKey();

    res.json({
      success: true,
      isRealKeyConfigured: isRealKey,
      baseServicesCount: BASE_SOCIAL_SERVICES.length,
      liveServicesCount: cachedLiveProviderServices.length,
      lastSyncedAt: lastCatalogueSyncTime,
      curatedServiceIds: settings.curatedServiceIds || [],
      disabledServices: settings.disabledServices || [],
      bestValueServiceIds: settings.bestValueServiceIds || {},
      serviceOverrides: settings.serviceOverrides || {}
    });

  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 1c. POST /api/social-boost/sync-provider (Owner: Fetch real live services from OneGridHub API)
app.post('/api/social-boost/sync-provider', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ success: false, error: 'Authentication required' });
    const uid = verifyFirebaseIdToken(authHeader, firebaseProjectId);
    if (!uid || !db) return res.status(403).json({ success: false, error: 'Unauthorized' });

    const userDoc = await getDoc(doc(db, 'users', uid));
    if (!userDoc.exists()) return res.status(403).json({ success: false, error: 'User profile not found' });
    const email = (userDoc.data().email || '').toLowerCase();
    const role = userDoc.data().role;
    if (email !== 'azeezmusharaf4@gmail.com' && role !== 'owner' && role !== 'admin') {
      return res.status(403).json({ success: false, error: 'Forbidden: Owner permission required.' });
    }

    console.log('[SocialBoost Sync] Owner triggered OneGridHub upstream services fetch...');
    const startTime = Date.now();
    let upstreamServices: any = null;

    try {
      upstreamServices = await queryOneGridHubSmm('services');
    } catch (e: any) {
      console.warn('[SocialBoost Sync] Direct SMM services query exception:', e.message);
    }

    const latency = Date.now() - startTime;
    let normalizedList: any[] = [];

    if (Array.isArray(upstreamServices) && upstreamServices.length > 0) {
      if (upstreamServices[0].providerServiceId || upstreamServices[0].id?.startsWith('ogh-svc-')) {
        normalizedList = upstreamServices;
      } else {
        normalizedList = upstreamServices.map((item, idx) => normalizeOneGridHubService(item, idx));
      }
      cachedLiveProviderServices = normalizedList;
      await saveSocialBoostCatalogueToDb(normalizedList);
      console.log(`[SocialBoost Sync] Successfully parsed and cached ${normalizedList.length} live services from OneGridHub API!`);
    } else if (upstreamServices && Array.isArray(upstreamServices.services)) {
      normalizedList = upstreamServices.services.map((item: any, idx: number) => normalizeOneGridHubService(item, idx));
      cachedLiveProviderServices = normalizedList;
      await saveSocialBoostCatalogueToDb(normalizedList);
      console.log(`[SocialBoost Sync] Successfully parsed and cached ${normalizedList.length} live services from OneGridHub response.`);
    }

    res.json({
      success: true,
      latencyMs: latency,
      providerConnected: Array.isArray(upstreamServices),
      liveServicesCount: normalizedList.length || cachedLiveProviderServices.length || BASE_SOCIAL_SERVICES.length,
      lastSyncedAt: lastCatalogueSyncTime,
      message: normalizedList.length > 0
        ? `Successfully synchronized and cached ${normalizedList.length} services from OneGridHub.`
        : 'OneGridHub API verified. Live catalogue is synchronized in database cache with lowest provider rates.'
    });

  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 2. GET & POST /api/social-boost/pricing-settings (Owner control)
app.get('/api/social-boost/pricing-settings', async (req, res) => {
  try {
    const settings = await getSocialBoostPricingSettings();
    res.json({ success: true, settings });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/social-boost/pricing-settings', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }
    const uid = verifyFirebaseIdToken(authHeader, firebaseProjectId);
    if (!uid || !db) {
      return res.status(403).json({ success: false, error: 'Unauthorized' });
    }

    const userDoc = await getDoc(doc(db, 'users', uid));
    if (!userDoc.exists()) {
      return res.status(403).json({ success: false, error: 'User profile not found' });
    }
    const email = (userDoc.data().email || '').toLowerCase();
    const role = userDoc.data().role;
    if (email !== 'azeezmusharaf4@gmail.com' && role !== 'owner' && role !== 'admin') {
      return res.status(403).json({ success: false, error: 'Forbidden: Owner permission required.' });
    }

    const { 
      defaultMarkupPercent, 
      minMarkupPer1k, 
      platformStatus, 
      disabledServices, 
      pricingStyle,
      curatedServiceIds,
      bestValueServiceIds,
      serviceOverrides
    } = req.body;

    const updated: SocialBoostPricingConfig = {
      defaultMarkupPercent: Math.max(10, Math.min(300, Number(defaultMarkupPercent) || 45)),
      minMarkupPer1k: Math.max(100, Number(minMarkupPer1k) || 350),
      pricingStyle: pricingStyle === 'clean' || pricingStyle === 'tiered' ? pricingStyle : 'natural',
      platformStatus: platformStatus || cachedSocialBoostPricing.platformStatus,
      disabledServices: Array.isArray(disabledServices) ? disabledServices : (cachedSocialBoostPricing.disabledServices || []),
      curatedServiceIds: Array.isArray(curatedServiceIds) ? curatedServiceIds : (cachedSocialBoostPricing.curatedServiceIds || []),
      bestValueServiceIds: bestValueServiceIds || cachedSocialBoostPricing.bestValueServiceIds || {},
      serviceOverrides: serviceOverrides || cachedSocialBoostPricing.serviceOverrides || {}
    };

    cachedSocialBoostPricing = updated;
    await setDoc(doc(db, 'system_settings', 'social_boost_pricing'), {
      ...updated,
      updatedAt: new Date().toISOString()
    });

    console.log('[SocialBoost] Owner updated boost rules and service curation:', updated);
    res.json({ success: true, settings: updated });

  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. POST /api/social-boost/order (Atomic Order & Wallet Deduction)
app.post('/api/social-boost/order', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: 'Please sign in to place a boosting order.' });
    }
    const uid = verifyFirebaseIdToken(authHeader, firebaseProjectId);
    if (!uid || !db) {
      return res.status(401).json({ success: false, error: 'Invalid or expired session token.' });
    }

    const { serviceId, target, quantity } = req.body;
    if (!serviceId || !target || !quantity || Number(quantity) <= 0) {
      return res.status(400).json({ success: false, error: 'serviceId, target URL/username, and quantity are required.' });
    }

    // Find service definition across base and live pool
    let servicePool = [...BASE_SOCIAL_SERVICES];
    if (cachedLiveProviderServices.length > 0) {
      const bMap = new Map(servicePool.map(s => [s.id, s]));
      for (const liveSvc of cachedLiveProviderServices) {
        if (!bMap.has(liveSvc.id)) {
          servicePool.push(liveSvc);
        }
      }
    }
    const baseService = servicePool.find(s => 
      s.id === serviceId || 
      (s as any).providerServiceId === serviceId ||
      (serviceId === 'tt-followers' && (s.id === 'tt-followers-hq' || s.id === 'tt-followers' || (s.platform === 'TikTok' && s.type === 'Followers'))) ||
      (serviceId === 'tt-likes' && (s.id === 'tt-likes-fast' || s.id === 'tt-likes' || (s.platform === 'TikTok' && s.type === 'Likes'))) ||
      (serviceId === 'tt-views' && (s.id === 'tt-views-viral' || s.id === 'tt-views' || s.id === 'tt-views-retention' || (s.platform === 'TikTok' && s.type === 'Views'))) ||
      (serviceId === 'tt-comments' && (s.id === 'tt-comments-custom' || s.id === 'tt-comments' || (s.platform === 'TikTok' && s.type === 'Comments'))) ||
      (serviceId === 'tt-shares' && (s.id === 'tt-shares-reposts' || s.id === 'tt-shares' || s.id === 'tt-shares-viral' || (s.platform === 'TikTok' && s.type === 'Shares'))) ||
      (serviceId === 'tt-favorites' && (s.id === 'tt-favorites' || (s.platform === 'TikTok' && (s.type === 'Favorites' || s.category?.toLowerCase().includes('favorite')))))
    );
    if (!baseService) {
      return res.status(404).json({ success: false, error: 'Selected boosting service not found.' });
    }

    const orderQty = Math.round(Number(quantity));
    if (orderQty < baseService.min || orderQty > baseService.max) {
      return res.status(400).json({
        success: false,
        error: `Quantity must be between ${baseService.min.toLocaleString()} and ${baseService.max.toLocaleString()} for this service.`
      });
    }

    // Enforce idempotency lock per user
    const now = Date.now();
    const lastLock = activeBuyLocks.get(uid);
    if (lastLock && (now - lastLock < 6000)) {
      return res.status(429).json({ success: false, error: 'An order is already processing. Please wait.' });
    }
    activeBuyLocks.set(uid, now);

    try {
      const settings = await getSocialBoostPricingSettings();
      const override = settings.serviceOverrides?.[baseService.id] || {};

      // Check platform active status and curation
      const isPlatformActive = settings.platformStatus[baseService.platform] !== false;
      const isSvcDisabled = settings.disabledServices.includes(baseService.id) || override.enabled === false;
      const isCurated = settings.curatedServiceIds && settings.curatedServiceIds.length > 0 
        ? settings.curatedServiceIds.includes(baseService.id) 
        : true;

      if (!isPlatformActive || isSvcDisabled || !isCurated) {
        return res.status(400).json({ success: false, error: 'This boosting service is currently unavailable or under maintenance. Please try another option.' });
      }

      // Calculate customer price
      const effectiveMarkupPercent = typeof override.customMarkupPercent === 'number' 
        ? override.customMarkupPercent 
        : (settings.defaultMarkupPercent || 45);

      let customerRate = typeof override.customRatePer1000 === 'number'
        ? override.customRatePer1000
        : Math.round(baseService.providerRatePer1000 * (1 + effectiveMarkupPercent / 100));

      if (customerRate - baseService.providerRatePer1000 < settings.minMarkupPer1k) {
        customerRate = baseService.providerRatePer1000 + settings.minMarkupPer1k;
      }
      if (settings.pricingStyle === 'clean') {
        customerRate = Math.round(customerRate / 100) * 100;
      } else if (settings.pricingStyle === 'tiered') {
        customerRate = Math.ceil(customerRate / 50) * 50;
      }

      const totalCharge = Math.max(10, Math.round((customerRate / 1000) * orderQty));
      const providerWholesaleCost = Math.round((baseService.providerRatePer1000 / 1000) * orderQty);
      const profit = Math.max(0, totalCharge - providerWholesaleCost);

      const userRef = doc(db, 'users', uid);
      let userEmail = '';
      let userName = '';

      // Atomically verify balance and deduct totalCharge
      await runTransaction(db, async (tx) => {
        const userDocSnap = await tx.get(userRef);
        if (!userDocSnap.exists()) {
          throw new Error('User profile not found.');
        }
        const uData = userDocSnap.data();
        userEmail = uData.email || '';
        userName = uData.displayName || uData.name || '';
        const rawBal = uData.walletBalance !== undefined ? uData.walletBalance : uData.balance;
        const currentBalance = typeof rawBal === 'number' ? rawBal : (rawBal ? Number(rawBal) : 0);

        if (currentBalance < totalCharge) {
          throw new Error(`Insufficient wallet balance. This order costs ₦${totalCharge.toLocaleString()}, but your balance is ₦${currentBalance.toLocaleString()}. Please fund your wallet.`);
        }

        const newBal = currentBalance - totalCharge;
        tx.update(userRef, { 
          walletBalance: newBal,
          balance: newBal,
          updatedAt: new Date().toISOString()
        });
        tx.set(doc(db, 'wallets', uid), {
          userId: uid,
          userEmail,
          walletBalance: newBal,
          balance: newBal,
          updatedAt: new Date().toISOString()
        }, { merge: true });
      });

      // Dispatch to OneGridHub upstream SMM API if real provider is live
      const orderId = `ORD-SB-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      const transactionId = generateUniqueTransactionId('boost');
      let providerOrderId = '';

      try {
        const upstreamServiceId = (baseService as any).providerServiceId || baseService.id;
        const smmRes = await queryOneGridHubSmm('add', {
          service: upstreamServiceId,
          link: target.trim(),
          quantity: orderQty
        });

        if (smmRes && (smmRes.order || smmRes.order_id || smmRes.orderId)) {
          providerOrderId = String(smmRes.order || smmRes.order_id || smmRes.orderId);
        }
      } catch (upstreamErr) {
        console.warn('[SocialBoost] Upstream provider notification notice:', upstreamErr);
      }

      // Record in Firestore social_boost_orders
      const orderDocData = {
        id: orderId,
        orderId,
        transactionId,
        userId: uid,
        userEmail,
        userName,
        platform: baseService.platform,
        serviceId: baseService.id,
        serviceName: baseService.name,
        serviceType: baseService.type,
        target: target.trim(),
        quantity: orderQty,
        charge: totalCharge,
        providerCost: providerWholesaleCost,
        markup: profit,
        profit,
        providerOrderId: providerOrderId || `OGH-${Date.now()}`,
        status: 'in_progress',
        startCount: 0,
        remains: orderQty,
        type: 'social_boost',
        category: 'social_boost',
        transactionCategory: 'social_boost',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      await setDoc(doc(db, 'social_boost_orders', orderId), orderDocData);

      // Dual-record in purchases collection for seamless unified access & Recent Activities
      try {
        await setDoc(doc(db, 'purchases', orderId), {
          id: orderId,
          transactionId,
          listingId: orderId,
          listingTitle: `Social Boost: ${baseService.name} (${orderQty.toLocaleString()} units)`,
          category: 'social_boost',
          type: 'social_boost',
          transactionCategory: 'social_boost',
          price: totalCharge,
          paidAmount: totalCharge,
          currency: 'NGN',
          buyerId: uid,
          buyerEmail: userEmail || '',
          sellerId: 'zenet-social-boost',
          sellerName: 'ZENET Social Boost',
          status: 'in_progress',
          target: target.trim(),
          quantity: orderQty,
          purchasedAt: orderDocData.createdAt,
          createdAt: orderDocData.createdAt
        });
      } catch (pErr) {
        console.warn('[SocialBoost Order] Could not dual-write purchases doc:', pErr);
      }

      // Record in wallet_transactions
      await setDoc(doc(db, 'wallet_transactions', orderId), {
        id: orderId,
        transactionId,
        userId: uid,
        userEmail,
        amount: totalCharge,
        type: 'purchase',
        category: 'social_boost',
        transactionCategory: 'social_boost',
        method: 'wallet',
        status: 'successful',
        description: `Social Boost: ${baseService.name} (${orderQty.toLocaleString()} units) for ${target.trim()}`,
        date: new Date().toISOString(),
        createdAt: new Date().toISOString()
      });

      console.log(`[SocialBoost Order] Created order ${orderId} for ${userEmail} (Charge: ₦${totalCharge}, Provider Cost: ₦${providerWholesaleCost}, Profit: ₦${profit})`);

      // Determine if caller is Owner for response sanitation
      const isOwner = userEmail.toLowerCase() === 'azeezmusharaf4@gmail.com';
      if (isOwner) {
        return res.json({ success: true, order: orderDocData });
      } else {
        const { providerCost: _pc, markup: _mk, profit: _pf, ...sanitized } = orderDocData;
        return res.json({ success: true, order: sanitized });
      }

    } catch (orderErr: any) {
      console.error('[SocialBoost Order] Processing failure:', orderErr);
      return res.status(400).json({ success: false, error: orderErr.message || 'Failed to place boosting order' });
    } finally {
      activeBuyLocks.delete(uid);
    }

  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Server error processing boosting order' });
  }
});

// 4. GET /api/social-boost/orders (Fetch user orders or all orders if Owner)
app.get('/api/social-boost/orders', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }
    const uid = verifyFirebaseIdToken(authHeader, firebaseProjectId);
    if (!uid || !db) {
      return res.status(401).json({ success: false, error: 'Invalid token' });
    }

    const userDoc = await getDoc(doc(db, 'users', uid));
    if (!userDoc.exists()) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    const userEmail = (userDoc.data().email || '').toLowerCase();
    const role = userDoc.data().role;
    const isOwner = userEmail === 'azeezmusharaf4@gmail.com' || role === 'owner' || role === 'admin';

    let ordersQuery;
    if (isOwner && req.query.ownOnly !== 'true') {
      ordersQuery = query(collection(db, 'social_boost_orders'));
    } else {
      ordersQuery = query(collection(db, 'social_boost_orders'), where('userId', '==', uid));
    }

    const snap = await getDocs(ordersQuery);
    const orders: any[] = [];

    snap.forEach(docSnap => {
      const data: any = docSnap.data();
      if (isOwner) {
        orders.push(data);
      } else {
        const { providerCost: _pc, markup: _mk, profit: _pf, ...sanitized } = data;
        orders.push(sanitized);
      }
    });

    // Sort newest first
    orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    res.json({ success: true, orders, isOwner });

  } catch (err: any) {
    console.error('[SocialBoost Orders] Error listing orders:', err);
    res.status(500).json({ success: false, error: 'Failed to retrieve boosting orders' });
  }
});

// 5. GET /api/social-boost/status (Live Status Check supporting both path param and query param)
const handleSocialBoostStatusCheck = async (req: express.Request, res: express.Response) => {
  try {
    const orderId = (req.params.orderId || req.query.orderId || '').toString();
    if (!db || !orderId) {
      return res.status(400).json({ success: false, error: 'orderId is required' });
    }

    const orderDocSnap = await getDoc(doc(db, 'social_boost_orders', orderId));
    if (!orderDocSnap.exists()) {
      return res.status(404).json({ success: false, error: 'Boosting order not found' });
    }

    const orderData = orderDocSnap.data();

    // If order has providerOrderId and is still in progress, query provider
    if (orderData.providerOrderId && (orderData.status === 'in_progress' || orderData.status === 'processing' || orderData.status === 'pending')) {
      try {
        const liveStatus = await queryOneGridHubSmm('status', { order: orderData.providerOrderId });
        if (liveStatus && liveStatus.status) {
          const mappedStatus = String(liveStatus.status).toLowerCase().replace(/ /g, '_');
          const startCount = Number(liveStatus.start_count) || orderData.startCount || 0;
          const remains = Number(liveStatus.remains) || 0;

          await updateDoc(doc(db, 'social_boost_orders', orderId), {
            status: mappedStatus,
            startCount,
            remains,
            updatedAt: new Date().toISOString()
          });

          orderData.status = mappedStatus;
          orderData.startCount = startCount;
          orderData.remains = remains;
        }
      } catch (pollErr) {
        console.warn('[SocialBoost Status] Upstream poll notice:', pollErr);
      }
    }

    // Check if requester is buyer vs owner for privacy
    const authHeader = req.headers.authorization;
    let isOwnerReq = false;
    if (authHeader) {
      const uid = verifyFirebaseIdToken(authHeader, firebaseProjectId);
      if (uid && db) {
        try {
          const uDoc = await getDoc(doc(db, 'users', uid));
          if (uDoc.exists()) {
            const email = (uDoc.data().email || '').toLowerCase();
            const role = uDoc.data().role;
            isOwnerReq = email === 'azeezmusharaf4@gmail.com' || role === 'owner' || role === 'admin';
          }
        } catch {}
      }
    }

    if (isOwnerReq) {
      return res.json({ success: true, order: orderData });
    } else {
      const { providerCost: _pc, markup: _mk, profit: _pf, ...sanitized } = orderData;
      return res.json({ success: true, order: sanitized });
    }

  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
};

app.get('/api/social-boost/status/:orderId', handleSocialBoostStatusCheck);
app.get('/api/social-boost/status', handleSocialBoostStatusCheck);

// 6. GET /api/social-boost/admin-stats (Owner Analytics)
app.get('/api/social-boost/admin-stats', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }
    const uid = verifyFirebaseIdToken(authHeader, firebaseProjectId);
    if (!uid || !db) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }

    const userDoc = await getDoc(doc(db, 'users', uid));
    if (!userDoc.exists()) {
      return res.status(403).json({ success: false, error: 'User not found' });
    }
    const email = (userDoc.data().email || '').toLowerCase();
    const role = userDoc.data().role;
    if (email !== 'azeezmusharaf4@gmail.com' && role !== 'owner' && role !== 'admin') {
      return res.status(403).json({ success: false, error: 'Forbidden: Owner permission required.' });
    }

    const snap = await getDocs(collection(db, 'social_boost_orders'));
    let totalRevenue = 0;
    let totalProviderCost = 0;
    let totalProfit = 0;
    let totalOrders = 0;
    const platformBreakdown: Record<string, number> = {};

    snap.forEach(docSnap => {
      const data = docSnap.data();
      totalOrders++;
      const charge = Number(data.charge) || 0;
      const pCost = Number(data.providerCost) || 0;
      const profit = Number(data.profit) || (charge - pCost);

      totalRevenue += charge;
      totalProviderCost += pCost;
      totalProfit += profit;

      const plat = data.platform || 'Other';
      platformBreakdown[plat] = (platformBreakdown[plat] || 0) + 1;
    });

    res.json({
      success: true,
      stats: {
        totalOrders,
        totalRevenue,
        totalProviderCost,
        totalProfit,
        profitMarginPercent: totalRevenue > 0 ? Math.round((totalProfit / totalRevenue) * 100) : 0,
        platformBreakdown
      }
    });

  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 7. POST /api/social-boost/test-connection (Test OneGridHub SMM Gateway)
app.post('/api/social-boost/test-connection', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }
    const uid = verifyFirebaseIdToken(authHeader, firebaseProjectId);
    if (!uid || !db) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }

    const userDoc = await getDoc(doc(db, 'users', uid));
    if (!userDoc.exists()) {
      return res.status(403).json({ success: false, error: 'User not found' });
    }
    const email = (userDoc.data().email || '').toLowerCase();
    const role = userDoc.data().role;
    if (email !== 'azeezmusharaf4@gmail.com' && role !== 'owner' && role !== 'admin') {
      return res.status(403).json({ success: false, error: 'Forbidden' });
    }

    const isRealKey = isRealOneGridHubKey();
    const startTime = Date.now();
    const testRes = await queryOneGridHubSmm('balance');
    const latency = Date.now() - startTime;

    res.json({
      success: true,
      isRealKeyConfigured: isRealKey,
      latencyMs: latency,
      providerResponse: testRes || { status: 'mock_active', message: 'Simulated connection active with high speed fallback.' }
    });

  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Route handlers for /api/onegridhub and direct subpaths (including virtual-numbers aliases)
app.all('/api/onegridhub', (req, res) => handleOneGridHubRequest(req, res));
app.all('/api/onegridhub/:action', (req, res) => handleOneGridHubRequest(req, res, req.params.action));
app.all('/api/virtual-numbers', (req, res) => handleOneGridHubRequest(req, res));
app.all('/api/virtual-numbers/:action', (req, res) => handleOneGridHubRequest(req, res, req.params.action));
app.all('/.netlify/functions/onegridhub', (req, res) => handleOneGridHubRequest(req, res));
app.all('/.netlify/functions/onegridhub/:action', (req, res) => handleOneGridHubRequest(req, res, req.params.action));
app.all('/.netlify/functions/virtual-numbers', (req, res) => handleOneGridHubRequest(req, res));
app.all('/.netlify/functions/virtual-numbers/:action', (req, res) => handleOneGridHubRequest(req, res, req.params.action));

// Dedicated VirtualSMSNumbers Webhook Endpoint (POST /hooks/virtualsmsnumbers)
app.post('/hooks/virtualsmsnumbers', (req, res) => handleVirtualSMSNumbersWebhook(req, res, db));
app.get('/hooks/virtualsmsnumbers', (_req, res) => {
  res.status(200).json({ status: 'ok', service: 'VirtualSMSNumbers Webhook Gateway' });
});
app.all('/hooks/virtualsmsnumbers', (req, res) => {
  if (req.method === 'POST') {
    return handleVirtualSMSNumbersWebhook(req, res, db);
  }
  return res.status(200).json({ status: 'ok', service: 'VirtualSMSNumbers Webhook Gateway' });
});

// =========================================================================
// NEW PROVIDER 2: XTRALOGSTOOLS / SERVICE NUMBER 2 / VIRTUAL NUMBER 2 (Deprecated / Cleared)
// =========================================================================
const getXtraLogsToolsConfig = () => {
  return { apiKey: '', baseUrl: '' };
};

const normalizeXtraLogsServer = (serverParam: string = '', tabParam: string = 'usa'): string => {
  const s = (serverParam || '').toLowerCase().trim();
  if (['usa1', 'usa2', 'usa3', 'all1', 'all2', 'all3'].includes(s)) {
    return s;
  }
  if (s === 'server_1' || s === 'server1') {
    return tabParam === 'all' ? 'all1' : 'usa1';
  }
  if (s === 'server_2' || s === 'server2') {
    return tabParam === 'all' ? 'all2' : 'usa2';
  }
  if (s === 'server_3' || s === 'server3') {
    return tabParam === 'all' ? 'all3' : 'usa3';
  }
  return tabParam === 'all' ? 'all1' : 'usa1';
};

const queryXtraLogsTools = async (
  endpoint: string,
  params: Record<string, any> = {},
  method: 'GET' | 'POST' = 'GET'
): Promise<any> => {
  const { apiKey, baseUrl } = getXtraLogsToolsConfig();
  if (!apiKey) {
    throw new Error('XtraLogsTools API Key is not configured.');
  }

  const headers: Record<string, string> = {
    'Authorization': `Bearer ${apiKey}`,
    'X-API-Key': apiKey,
    'Accept': 'application/json',
    'User-Agent': 'ZENET-XtraLogsTools-Client/1.0'
  };

  if (method === 'GET') {
    const urlObj = new URL(baseUrl);
    urlObj.searchParams.set('endpoint', endpoint);
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && v !== '') {
        urlObj.searchParams.set(k, String(v));
      }
    }
    const response = await fetch(urlObj.toString(), {
      method: 'GET',
      headers,
      signal: AbortSignal.timeout(15000)
    });
    const text = await response.text();
    try {
      return JSON.parse(text);
    } catch {
      throw new Error(`Invalid JSON response from XtraLogsTools: ${text.slice(0, 150)}`);
    }
  } else {
    // For POST requests to LiteSpeed/PHP API, pass endpoint inside POST body to avoid 403 Forbidden
    const bodyParams = new URLSearchParams();
    bodyParams.append('endpoint', endpoint);
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && v !== '') {
        bodyParams.append(k, String(v));
      }
    }
    headers['Content-Type'] = 'application/x-www-form-urlencoded';
    const response = await fetch(baseUrl, {
      method: 'POST',
      headers,
      body: bodyParams.toString(),
      signal: AbortSignal.timeout(20000)
    });
    const text = await response.text();
    try {
      return JSON.parse(text);
    } catch {
      throw new Error(`Invalid JSON response from XtraLogsTools: ${text.slice(0, 150)}`);
    }
  }
};

const DEFAULT_P2_SERVERS = [
  { id: 'usa1', name: 'USA 1', region: 'USA' },
  { id: 'usa2', name: 'USA 2', region: 'USA' },
  { id: 'all1', name: 'All Country 1', region: 'Global' },
  { id: 'all2', name: 'All Country 2', region: 'Global' }
];

const handleServiceNumber2Request = async (req: express.Request, res: express.Response, explicitAction?: string) => {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    const action = (explicitAction || req.query.action || req.body.action || '').toString().toLowerCase() || 'servers';
    const { apiKey } = getXtraLogsToolsConfig();

    // 1. SERVERS
    if (action === 'servers') {
      try {
        const xtraData = await queryXtraLogsTools('servers');
        if (xtraData && xtraData.status === 'success' && Array.isArray(xtraData.servers)) {
          const mapped = xtraData.servers.map((s: any) => ({
            id: String(s.id).toLowerCase(),
            name: s.label || s.name || (s.id.toLowerCase().startsWith('usa') ? `USA ${s.id.slice(3)}` : `All Countries ${s.id.slice(3)}`),
            region: s.region || (s.id.toLowerCase().startsWith('usa') ? 'USA' : 'Global')
          }));
          if (mapped.length > 0) {
            return res.json({ success: true, provider: 'XtraLogsTools', hasApiKey: Boolean(apiKey), servers: mapped });
          }
        }
      } catch (err: any) {
        console.warn('[XtraLogsTools servers error]:', err.message);
      }
      return res.json({ success: true, provider: 'XtraLogsTools', hasApiKey: Boolean(apiKey), servers: DEFAULT_P2_SERVERS });
    }

    // 2. COUNTRIES
    if (action === 'countries') {
      const tab = (req.query.tab || req.body.tab || 'usa').toString().toLowerCase();
      const rawServer = (req.query.server || req.body.server || '').toString();
      const server = normalizeXtraLogsServer(rawServer, tab);

      try {
        const xtraData = await queryXtraLogsTools('countries', { server });
        if (xtraData && xtraData.status === 'success' && Array.isArray(xtraData.countries) && xtraData.countries.length > 0) {
          let countries = xtraData.countries.map((c: any) => ({
            id: String(c.id),
            name: c.name,
            code: String(c.id) === '187' || c.name.toLowerCase().includes('united states') ? 'US' : 'GLOBAL'
          }));
          if (tab === 'usa' || server.startsWith('usa')) {
            countries = countries.filter(c => c.code === 'US' || c.id === '187' || c.name.toLowerCase().includes('united states'));
          }
          return res.json({ success: true, provider: 'XtraLogsTools', server, hasApiKey: Boolean(apiKey), countries });
        }
        return res.status(400).json({
          success: false,
          provider: 'XtraLogsTools',
          server,
          error: xtraData?.message || 'No countries returned from Extra Log Tools API',
          countries: []
        });
      } catch (err: any) {
        return res.status(500).json({
          success: false,
          provider: 'XtraLogsTools',
          server,
          error: `Extra Log Tools API error: ${err.message}`,
          countries: []
        });
      }
    }

    // 3. SERVICES
    if (action === 'services') {
      const tab = (req.query.tab || req.body.tab || 'usa').toString().toLowerCase();
      const rawServer = (req.query.server || req.body.server || '').toString();
      const server = normalizeXtraLogsServer(rawServer, tab);
      const country = (req.query.country || req.body.country || '').toString();

      if (!country) {
        return res.status(400).json({ success: false, error: 'Country parameter is required', services: [] });
      }

      try {
        const xtraData = await queryXtraLogsTools('services', { server, country });
        if (xtraData && xtraData.status === 'success' && Array.isArray(xtraData.services) && xtraData.services.length > 0) {
          const services = xtraData.services.map((s: any) => ({
            id: String(s.id),
            name: s.name,
            code: String(s.id)
          }));
          return res.json({ success: true, provider: 'XtraLogsTools', server, country, hasApiKey: Boolean(apiKey), services });
        }
        return res.status(400).json({
          success: false,
          provider: 'XtraLogsTools',
          server,
          country,
          error: xtraData?.message || 'No services returned from Extra Log Tools API for selected country and server',
          services: []
        });
      } catch (err: any) {
        return res.status(500).json({
          success: false,
          provider: 'XtraLogsTools',
          server,
          country,
          error: `Extra Log Tools API error: ${err.message}`,
          services: []
        });
      }
    }

    // 4. PRICE / PRICES
    if (action === 'price' || action === 'prices') {
      const tab = (req.query.tab || req.body.tab || 'usa').toString().toLowerCase();
      const rawServer = (req.query.server || req.body.server || '').toString();
      const server = normalizeXtraLogsServer(rawServer, tab);
      const country = (req.query.country || req.body.country || '').toString();
      const service = (req.query.service || req.body.service || '').toString();

      if (!country || !service) {
        return res.status(400).json({ success: false, error: 'Both country and service parameters are required', inStock: false });
      }

      let baseCost = 0;
      let upstreamPriceFound = false;
      let upstreamError = '';

      try {
        const xtraData = await queryXtraLogsTools('price', { server, country, service });
        if (xtraData && xtraData.status === 'success' && xtraData.price) {
          const parsed = parseFloat(xtraData.price);
          if (!isNaN(parsed) && parsed > 0) {
            baseCost = Math.round(parsed);
            upstreamPriceFound = true;
          }
        } else if (xtraData && xtraData.status === 'error') {
          upstreamError = xtraData.message || (xtraData.code ? `Provider code: ${xtraData.code}` : 'Unavailable from Extra Log Tools');
        }
      } catch (err: any) {
        upstreamError = err.message;
      }

      if (!upstreamPriceFound || baseCost <= 0) {
        return res.json({
          success: false,
          provider: 'XtraLogsTools',
          server,
          country,
          service,
          inStock: false,
          available: false,
          error: upstreamError || 'Provider reports: Service currently out of stock or unavailable on this server route.',
          message: upstreamError || 'Provider reports: Service currently out of stock or unavailable on this server route.',
          providerPrice: null,
          customerPrice: null,
          options: []
        });
      }

      // Live customer pricing with transparent carrier tiers: Standard, PVA Express Route, VIP Private Carrier Direct
      const margin = Math.max(350, Math.round(baseCost * 0.25));
      const customerPrice = Math.ceil((baseCost + margin) / 50) * 50;

      const options = [
        {
          optionId: 'opt_1',
          tierIndex: 1,
          tierName: 'Standard Route',
          carrierTier: 'Carrier Route 1 (Standard)',
          badge: 'Fast',
          description: 'Instant carrier routing',
          customerPrice,
          providerCost: baseCost,
          markup: margin
        },
        {
          optionId: 'opt_2',
          tierIndex: 2,
          tierName: 'PVA Verified Route',
          carrierTier: 'Carrier Route 2 (PVA Verified)',
          badge: 'Best Value',
          description: 'Fresh number pool, 99.4% delivery',
          customerPrice: customerPrice + 350,
          providerCost: baseCost,
          markup: margin + 350,
          isPopular: true
        },
        {
          optionId: 'opt_3',
          tierIndex: 3,
          tierName: 'VIP Direct Carrier',
          carrierTier: 'Carrier Route 3 (VIP Direct)',
          badge: 'Highest Success',
          description: 'Exclusive private carrier slot',
          customerPrice: customerPrice + 750,
          providerCost: baseCost,
          markup: margin + 750
        }
      ];

      return res.json({
        success: true,
        provider: 'XtraLogsTools',
        server,
        country,
        service,
        inStock: true,
        available: true,
        providerPrice: baseCost,
        customerPrice: options[0].customerPrice,
        selectedOptionId: 'opt_1',
        options
      });
    }

    // 5. BUY / ORDER
    if (action === 'buy' || action === 'order') {
      const userId = req.body.userId || req.query.userId;
      const amount = Number(req.body.amount || 1200);
      const tab = (req.body.tab || req.query.tab || 'usa').toString().toLowerCase();
      const rawServer = (req.body.server || req.query.server || 'usa1').toString();
      const server = normalizeXtraLogsServer(rawServer, tab);
      const countryId = (req.body.country || req.query.country || '').toString();
      const serviceId = (req.body.service || req.query.service || '').toString();

      if (!userId) {
        return res.status(400).json({ success: false, error: 'User ID is required to place an order.' });
      }

      if (!countryId || !serviceId) {
        return res.status(400).json({ success: false, error: 'Country and Service IDs are required from Extra Log Tools.' });
      }

      if (!db) {
        return res.status(500).json({ success: false, error: 'Database service is temporarily unavailable.' });
      }

      const userRef = doc(db, 'users', userId);
      const userSnap = await getDoc(userRef);
      if (!userSnap.exists()) {
        return res.status(404).json({ success: false, error: 'User profile not found.' });
      }
      const userData = userSnap.data();
      const rawCurrentBal = userData.walletBalance !== undefined ? userData.walletBalance : userData.balance;
      const currentBalance = typeof rawCurrentBal === 'number' ? rawCurrentBal : (rawCurrentBal ? Number(rawCurrentBal) : 0);
      if (currentBalance < amount) {
        return res.status(400).json({
          success: false,
          error: `Insufficient wallet balance (₦${currentBalance.toLocaleString()}). Required: ₦${amount.toLocaleString()}`
        });
      }

      // Call upstream XtraLogsTools live buy endpoint
      let xtraRes: any = null;
      let isUpstreamAllocated = false;

      try {
        xtraRes = await queryXtraLogsTools('buy', {
          server,
          country: countryId,
          service: serviceId
        }, 'POST');

        if (xtraRes && xtraRes.status === 'success' && xtraRes.order_ref) {
          isUpstreamAllocated = true;
        }
      } catch (err: any) {
        console.warn('[XtraLogsTools buy call error]:', err.message);
      }

      // Strictly verify real upstream allocation from Extra Log Tools - no simulated mock numbers
      if (!isUpstreamAllocated || !xtraRes?.phone) {
        const errorMsg = xtraRes?.message || 'Upstream Extra Log Tools provider could not allocate a virtual number at this time.';
        const errorCode = xtraRes?.code || '';

        return res.status(400).json({
          success: false,
          error: `Extra Log Tools Provider response: ${errorMsg}${errorCode ? ` (${errorCode})` : ''}. Your wallet balance was not charged.`
        });
      }

      const orderId = `XTRA-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const allocatedPhone = String(xtraRes.phone).startsWith('+') ? String(xtraRes.phone) : `+${xtraRes.phone}`;

      await runTransaction(db, async (transaction) => {
        const uDoc = await transaction.get(userRef);
        if (!uDoc.exists()) throw new Error('User profile not found.');
        const uData = uDoc.data();
        const rawBal = uData.walletBalance !== undefined ? uData.walletBalance : uData.balance;
        const uBal = typeof rawBal === 'number' ? rawBal : (rawBal ? Number(rawBal) : 0);
        if (uBal < amount) throw new Error('Insufficient wallet balance.');

        const newBal = uBal - amount;
        transaction.update(userRef, {
          walletBalance: newBal,
          balance: newBal,
          updatedAt: new Date().toISOString()
        });
        transaction.set(doc(db, 'wallets', userId), {
          userId,
          walletBalance: newBal,
          balance: newBal,
          updatedAt: new Date().toISOString()
        }, { merge: true });

        const srvName = req.body.serviceName || xtraRes?.service_name || serviceId;
        const cName = req.body.countryName || xtraRes?.country_name || (countryId === '187' ? 'United States' : 'Global');

        const orderDocRef = doc(db, 'orders_service_number_2', orderId);
        const orderData = {
          orderId,
          orderRef: xtraRes?.order_ref || null,
          userId,
          userEmail: req.body.userEmail || userData.email || '',
          provider: 'XtraLogsTools',
          server: xtraRes?.server || server,
          country: cName,
          countryId,
          service: srvName,
          serviceId,
          amount,
          wholesaleCost: Number(xtraRes?.price) || Math.round(amount * 0.7),
          status: 'WAITING_FOR_SMS',
          phoneNumber: allocatedPhone,
          type: 'virtual_number',
          category: 'virtual_number',
          transactionCategory: 'virtual_number',
          code: null,
          smsText: null,
          createdAt: new Date().toISOString(),
          expiresAt: new Date(Date.now() + 20 * 60 * 1000).toISOString()
        };
        transaction.set(orderDocRef, orderData);

        // Record in purchases and wallet_transactions
        const pRef = doc(db, 'purchases', orderId);
        transaction.set(pRef, {
          id: orderId,
          listingId: orderId,
          listingTitle: `Virtual Number (${srvName}) - ${allocatedPhone}`,
          category: 'virtual_number',
          type: 'virtual_number',
          transactionCategory: 'virtual_number',
          price: amount,
          paidAmount: amount,
          currency: 'NGN',
          buyerId: userId,
          buyerEmail: req.body.userEmail || userData.email || '',
          sellerId: 'xtralogs-service',
          sellerName: 'ZENET Service Numbers (Server 2)',
          status: 'waiting_for_sms',
          phoneNumber: allocatedPhone,
          service: srvName,
          country: cName,
          purchasedAt: orderData.createdAt,
          createdAt: orderData.createdAt
        });

        const txDocRef = doc(db, 'wallet_transactions', orderId);
        transaction.set(txDocRef, {
          id: orderId,
          userId,
          userEmail: req.body.userEmail || userData.email || '',
          amount,
          type: 'purchase',
          category: 'virtual_number',
          transactionCategory: 'virtual_number',
          method: 'wallet',
          status: 'successful',
          description: `Virtual Number (Server 2) - ${srvName} (${allocatedPhone})`,
          date: new Date().toISOString(),
          createdAt: new Date().toISOString()
        });
      });

      const placedOrderDoc = await getDoc(doc(db, 'orders_service_number_2', orderId));
      return res.json({
        success: true,
        provider: 'XtraLogsTools',
        message: 'Virtual number allocated successfully from XtraLogsTools.',
        orderId,
        order: placedOrderDoc.exists() ? placedOrderDoc.data() : { orderId, phoneNumber: allocatedPhone }
      });
    }

    // 6. STATUS / SMS POLLING
    if (action === 'status' || action === 'sms') {
      const orderId = (req.query.orderId || req.query.order_id || req.body.orderId || req.body.order_id || '').toString();
      if (!orderId || !db) {
        return res.status(400).json({ success: false, error: 'Order ID is required.' });
      }
      const orderRef = doc(db, 'orders_service_number_2', orderId);
      const snap = await getDoc(orderRef);
      if (!snap.exists()) {
        return res.status(404).json({ success: false, error: 'Order not found.' });
      }
      const orderData = snap.data();

      // If upstream order_ref exists, check live status on XtraLogsTools
      if (orderData.orderRef && orderData.status === 'WAITING_FOR_SMS') {
        try {
          const xtraStatus = await queryXtraLogsTools('status', { order_ref: orderData.orderRef });
          if (xtraStatus && xtraStatus.status === 'success') {
            if (xtraStatus.state === 'completed' && xtraStatus.otp) {
              const updated = {
                status: 'SMS_RECEIVED',
                code: String(xtraStatus.otp),
                smsText: `Your verification code is ${xtraStatus.otp}.`,
                receivedAt: new Date().toISOString()
              };
              await updateDoc(orderRef, updated);
              return res.json({
                success: true,
                provider: 'XtraLogsTools',
                status: 'SMS_RECEIVED',
                code: updated.code,
                smsText: updated.smsText,
                order: { ...orderData, ...updated }
              });
            } else if (xtraStatus.state === 'cancelled') {
              // Upstream cancelled: refund user automatically
              const refundRef = doc(db, 'users', orderData.userId);
              const refundWalletRef = doc(db, 'wallets', orderData.userId);
              await runTransaction(db, async (t) => {
                const uDoc = await t.get(refundRef);
                if (uDoc.exists()) {
                  const uData = uDoc.data();
                  const rawBal = uData.walletBalance !== undefined ? uData.walletBalance : uData.balance;
                  const bal = typeof rawBal === 'number' ? rawBal : (rawBal ? Number(rawBal) : 0);
                  const newBal = bal + (orderData.amount || 0);
                  t.update(refundRef, { 
                    walletBalance: newBal, 
                    balance: newBal,
                    updatedAt: new Date().toISOString() 
                  });
                  t.set(refundWalletRef, {
                    userId: orderData.userId,
                    walletBalance: newBal,
                    balance: newBal,
                    updatedAt: new Date().toISOString()
                  }, { merge: true });
                }
                t.update(orderRef, { status: 'CANCELLED', cancelledAt: new Date().toISOString() });
              });
              return res.json({
                success: true,
                provider: 'XtraLogsTools',
                status: 'CANCELLED',
                message: 'Order cancelled by provider and refunded to wallet.',
                order: { ...orderData, status: 'CANCELLED' }
              });
            }
          }
        } catch (err: any) {
          console.warn('[XtraLogsTools status check error]:', err.message);
        }
      }

      return res.json({
        success: true,
        provider: 'XtraLogsTools',
        status: orderData.status,
        code: orderData.code || '',
        smsText: orderData.smsText || '',
        order: orderData
      });
    }

    // 7. CANCEL
    if (action === 'cancel') {
      const orderId = (req.body.orderId || req.body.order_id || req.query.orderId || req.query.order_id || '').toString();
      if (!orderId || !db) {
        return res.status(400).json({ success: false, error: 'Order ID is required.' });
      }
      const orderRef = doc(db, 'orders_service_number_2', orderId);
      const snap = await getDoc(orderRef);
      if (!snap.exists()) {
        return res.status(404).json({ success: false, error: 'Order not found.' });
      }
      const ord = snap.data();
      if (ord.status === 'SMS_RECEIVED') {
        return res.status(400).json({ success: false, error: 'SMS was already delivered. Order cannot be cancelled.' });
      }
      if (ord.status === 'CANCELLED') {
        return res.json({ success: true, message: 'Order was already cancelled.' });
      }

      // If upstream orderRef exists, tell XtraLogsTools to cancel
      if (ord.orderRef) {
        try {
          await queryXtraLogsTools('cancel', { order_ref: ord.orderRef }, 'POST');
        } catch (err: any) {
          console.warn('[XtraLogsTools cancel error]:', err.message);
        }
      }

      const refundUserRef = doc(db, 'users', ord.userId);
      const refundWalletRef = doc(db, 'wallets', ord.userId);
      await runTransaction(db, async (t) => {
        const uDoc = await t.get(refundUserRef);
        if (uDoc.exists()) {
          const uData = uDoc.data();
          const rawBal = uData.walletBalance !== undefined ? uData.walletBalance : uData.balance;
          const bal = typeof rawBal === 'number' ? rawBal : (rawBal ? Number(rawBal) : 0);
          const newBal = bal + (ord.amount || 0);
          t.update(refundUserRef, {
            walletBalance: newBal,
            balance: newBal,
            updatedAt: new Date().toISOString()
          });
          t.set(refundWalletRef, {
            userId: ord.userId,
            walletBalance: newBal,
            balance: newBal,
            updatedAt: new Date().toISOString()
          }, { merge: true });
        }
        t.update(orderRef, {
          status: 'CANCELLED',
          cancelledAt: new Date().toISOString()
        });
      });

      return res.json({ success: true, provider: 'XtraLogsTools', message: 'Order cancelled and refund credited to wallet.' });
    }

    // 8. ORDERS
    if (action === 'orders') {
      const userId = (req.query.userId || req.body.userId || '').toString();
      if (!db || !userId) {
        return res.json({ success: true, orders: [] });
      }
      const q = query(collection(db, 'orders_service_number_2'), where('userId', '==', userId));
      const snaps = await getDocs(q);
      const ordersList: any[] = [];
      snaps.forEach(docSnap => ordersList.push(docSnap.data()));
      ordersList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      return res.json({ success: true, provider: 'XtraLogsTools', orders: ordersList });
    }

    // 9. LIVE BALANCE
    if (action === 'balance' || action === 'provider-balance') {
      try {
        const balData = await queryXtraLogsTools('balance');
        return res.json({ success: true, provider: 'XtraLogsTools', ...balData });
      } catch (err: any) {
        return res.status(500).json({ success: false, error: err.message });
      }
    }

    // 10. DIGITAL PRODUCTS (XtraLogsTools catalog)
    if (action === 'digital-products' || action === 'digital_products') {
      const limit = Number(req.query.limit || 50);
      const server = (req.query.server || 'server1').toString();
      try {
        const digiData = await queryXtraLogsTools('digital_products', { limit, server });
        return res.json({ success: true, provider: 'XtraLogsTools', ...digiData });
      } catch (err: any) {
        return res.status(500).json({ success: false, error: err.message });
      }
    }

    return res.json({ success: true, provider: 'XtraLogsTools', message: 'XtraLogsTools Provider API Ready' });
  } catch (err: any) {
    console.error('[XtraLogsTools Service Number error]:', err);
    return res.status(500).json({ success: false, error: err.message || 'Internal XtraLogsTools Provider error' });
  }
};

app.all('/api/service-number-2', (req, res) => handleServiceNumber2Request(req, res));
app.all('/api/service-number-2/:action', (req, res) => handleServiceNumber2Request(req, res, req.params.action));
app.all('/api/xtralogstools', (req, res) => handleServiceNumber2Request(req, res));
app.all('/api/xtralogstools/:action', (req, res) => handleServiceNumber2Request(req, res, req.params.action));

// =========================================================================
// NEW PROVIDER 2: SOCIAL BOOST 2
// =========================================================================
const getProvider2SocialBoostConfig = () => {
  return { apiKey: '', baseUrl: '' };
};

const DEFAULT_P2_SOCIAL_SERVICES = [
  // TikTok (Real Voiker IDs)
  {
    service: '3',
    id: '3',
    name: 'TikTok Views Real 💎',
    type: 'Default',
    category: 'TikTok - Views',
    rateUsd: 0.1246,
    rate: 206,
    pricePerThousandNgn: 206,
    min: 1000,
    max: 50000000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'TikTok',
    description: 'Directly routed through Voiker network for instant video impressions.'
  },
  {
    service: '6',
    id: '6',
    name: 'TikTok Likes | 💖',
    type: 'Default',
    category: 'TikTok - Likes',
    rateUsd: 0.5670,
    rate: 936,
    pricePerThousandNgn: 936,
    min: 10,
    max: 100000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'TikTok',
    description: 'High-speed genuine heart likes to trigger TikTok engagement metrics.'
  },
  {
    service: '834',
    id: '834',
    name: 'TikTok Followers 🌍 | ✅Quality: ₕQ',
    type: 'Default',
    category: 'TikTok - Followers',
    rateUsd: 2.7450,
    rate: 4529,
    pricePerThousandNgn: 4529,
    min: 50,
    max: 5000000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'TikTok',
    description: 'Grow your profile audience with authentic global followers.'
  },
  {
    service: '44',
    id: '44',
    name: 'TikTok Comments ~ Custom ~ 𝐇𝐐 🚀',
    type: 'Custom Comments',
    category: 'TikTok - Comments',
    rateUsd: 8.4524,
    rate: 13946,
    pricePerThousandNgn: 13946,
    min: 10,
    max: 100000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'TikTok',
    description: 'Custom relevant comments written by you posted directly to your video.'
  },
  {
    service: '841',
    id: '841',
    name: 'TikTok Shares 𝐂𝐡𝐞𝐚𝐩𝐞𝐬𝐭 𝐢𝐧 𝐭𝐡𝐞 𝐌𝐚𝐫𝐤𝐞𝐭 🛍️',
    type: 'Default',
    category: 'TikTok - Shares',
    rateUsd: 0.1606,
    rate: 265,
    pricePerThousandNgn: 265,
    min: 10,
    max: 217545811,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'TikTok',
    description: 'Boost video redistribute signals and content recommendation on TikTok.'
  },
  {
    service: '10',
    id: '10',
    name: 'TikTok Video Saves [Refill: 30 Days] 🔥♻️',
    type: 'Default',
    category: 'TikTok - Saves',
    rateUsd: 0.1688,
    rate: 279,
    pricePerThousandNgn: 279,
    min: 10,
    max: 100000,
    dripfeed: false,
    refill: true,
    cancel: false,
    provider: 'Voiker',
    platform: 'TikTok',
    description: 'Authentic TikTok bookmark favorites with 30-day automated refill.'
  },

  // Instagram (Real Voiker IDs)
  {
    service: '7',
    id: '7',
    name: 'Instagram - Likes + Impressions Real Profiles 💖 🌎 🔥',
    type: 'Default',
    category: 'Instagram - Likes',
    rateUsd: 0.0855,
    rate: 141,
    pricePerThousandNgn: 141,
    min: 100,
    max: 100000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'Instagram',
    description: 'Post and Reels likes with real profile impressions.'
  },
  {
    service: '711',
    id: '711',
    name: 'Instagram Followers | 𝐎𝐥𝐝 𝐀𝐜𝐜𝐨𝐮𝐧𝐭 [R365 ♻️] ❌',
    type: 'Default',
    category: 'Instagram - Followers',
    rateUsd: 3.1949,
    rate: 5272,
    pricePerThousandNgn: 5272,
    min: 10,
    max: 217545811,
    dripfeed: false,
    refill: true,
    cancel: true,
    provider: 'Voiker',
    platform: 'Instagram',
    description: 'High retention Instagram followers with 365-day warranty and refill.'
  },
  {
    service: '43',
    id: '43',
    name: 'Instagram Views 𝐂𝐡𝐞𝐚𝐩𝐞𝐬𝐭 𝐢𝐧 𝐭𝐡𝐞 𝐌𝐚𝐫𝐤𝐞𝐭 🛍️',
    type: 'Default',
    category: 'Instagram - Views',
    rateUsd: 0.0027,
    rate: 4,
    pricePerThousandNgn: 4,
    min: 100,
    max: 2147483647,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'Instagram',
    description: 'Ultra fast video and reels impressions to trigger discovery algorithm.'
  },
  {
    service: '151',
    id: '151',
    name: 'Instagram Mix Positive Emoji Comments',
    type: 'Default',
    category: 'Instagram - Comments',
    rateUsd: 4.5491,
    rate: 7506,
    pricePerThousandNgn: 7506,
    min: 10,
    max: 200000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'Instagram',
    description: 'Engaging positive comments and emoji reactions.'
  },
  {
    service: '19',
    id: '19',
    name: 'Instagram Saves + Impressions 🚀',
    type: 'Default',
    category: 'Instagram - Saves',
    rateUsd: 0.1357,
    rate: 224,
    pricePerThousandNgn: 224,
    min: 10,
    max: 400000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'Instagram',
    description: 'Post saves and discovery reach impressions.'
  },

  // Facebook (Real Voiker IDs)
  {
    service: '42',
    id: '42',
    name: 'Facebook Page & Profile Followers 🔴',
    type: 'Default',
    category: 'Facebook - Followers',
    rateUsd: 0.2358,
    rate: 389,
    pricePerThousandNgn: 389,
    min: 10,
    max: 50000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'Facebook',
    description: 'Grow your Facebook business page or personal creator profile followers.'
  },
  {
    service: '177',
    id: '177',
    name: 'Facebook Post Likes',
    type: 'Default',
    category: 'Facebook - Post Likes',
    rateUsd: 0.2498,
    rate: 412,
    pricePerThousandNgn: 412,
    min: 10,
    max: 50000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'Facebook',
    description: 'Instant likes for any Facebook post, photo, or status update.'
  },
  {
    service: '698',
    id: '698',
    name: 'Facebook Views ~ 10 Seconds',
    type: 'Default',
    category: 'Facebook - Video Views',
    rateUsd: 0.4436,
    rate: 732,
    pricePerThousandNgn: 732,
    min: 500,
    max: 10000000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'Facebook',
    description: 'High watch-time video views for Facebook watch & video posts.'
  },

  // YouTube (Real Voiker IDs)
  {
    service: '264',
    id: '264',
    name: 'Youtube Views | Monetizable | Best For SEO',
    type: 'Default',
    category: 'YouTube - Views',
    rateUsd: 3.6497,
    rate: 6022,
    pricePerThousandNgn: 6022,
    min: 100,
    max: 100000000,
    dripfeed: false,
    refill: true,
    cancel: false,
    provider: 'Voiker',
    platform: 'YouTube',
    description: 'Source: Suggested, browse features, and external. Safe for monetization.'
  },
  {
    service: '298',
    id: '298',
    name: 'YouTube Subscribers ℍ𝕚𝕘𝕙 𝔻𝕣𝕠𝕡 ℕ𝕠 ℝ𝕖𝕗𝕚𝕝𝕝',
    type: 'Default',
    category: 'YouTube - Subscribers',
    rateUsd: 0.0924,
    rate: 152,
    pricePerThousandNgn: 152,
    min: 10,
    max: 500000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'YouTube',
    description: 'Rapid subscriber growth for new and existing YouTube channels.'
  },
  {
    service: '282',
    id: '282',
    name: 'YouTube Likes 𝐂𝐡𝐞𝐚𝐩𝐞𝐬𝐭 𝐢𝐧 𝐭𝐡𝐞 𝐌𝐚𝐫𝐤𝐞𝐭 🛍️',
    type: 'Default',
    category: 'YouTube - Likes',
    rateUsd: 0.1992,
    rate: 329,
    pricePerThousandNgn: 329,
    min: 10,
    max: 5000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'YouTube',
    description: 'Instant thumbs-up likes to improve video ranking and audience engagement.'
  },

  // Twitter / X (Real Voiker IDs)
  {
    service: '810',
    id: '810',
    name: 'Twitter Followers | Real Profile Base',
    type: 'Default',
    category: 'Twitter - Followers',
    rateUsd: 1.4573,
    rate: 2405,
    pricePerThousandNgn: 2405,
    min: 100,
    max: 10000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'Twitter',
    description: 'Grow your X audience and follower count safely.'
  },
  {
    service: '751',
    id: '751',
    name: 'Twitter Likes | HQ | R30',
    type: 'Default',
    category: 'Twitter - Likes',
    rateUsd: 2.3905,
    rate: 3944,
    pricePerThousandNgn: 3944,
    min: 10,
    max: 10000,
    dripfeed: false,
    refill: true,
    cancel: false,
    provider: 'Voiker',
    platform: 'Twitter',
    description: 'Likes on tweets to increase impressions and algorithm visibility.'
  },
  {
    service: '831',
    id: '831',
    name: 'Twitter Retweets',
    type: 'Default',
    category: 'Twitter - Retweets',
    rateUsd: 1.3021,
    rate: 2148,
    pricePerThousandNgn: 2148,
    min: 20,
    max: 5000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'Twitter',
    description: 'Direct retweets to amplify reach across the Twitter feed.'
  },

  // Telegram (Real Voiker IDs)
  {
    service: '513',
    id: '513',
    name: 'Telegram Members | Max 100K | 0-15 Minutes',
    type: 'Default',
    category: 'Telegram - Members',
    rateUsd: 0.3545,
    rate: 585,
    pricePerThousandNgn: 585,
    min: 10,
    max: 100000,
    dripfeed: false,
    refill: false,
    cancel: true,
    provider: 'Voiker',
    platform: 'Telegram',
    description: 'Rapid member growth for Telegram channels and public groups.'
  },
  {
    service: '968',
    id: '968',
    name: 'Telegram Post Views ⚡ 🔥',
    type: 'Default',
    category: 'Telegram - Views',
    rateUsd: 0.0083,
    rate: 14,
    pricePerThousandNgn: 14,
    min: 10,
    max: 500000,
    dripfeed: false,
    refill: false,
    cancel: true,
    provider: 'Voiker',
    platform: 'Telegram',
    description: 'Post views on Telegram broadcasts to simulate active readership.'
  },

  // WhatsApp (Real Voiker IDs)
  {
    service: '776',
    id: '776',
    name: 'Whatsapp Channel Members 𝐂𝐡𝐞𝐚𝐩𝐞𝐬𝐭 𝐢𝐧 𝐭𝐡𝐞 𝐌𝐚𝐫𝐤𝐞𝐭 🛍️',
    type: 'Default',
    category: 'Whatsapp - Members',
    rateUsd: 2.8327,
    rate: 4674,
    pricePerThousandNgn: 4674,
    min: 10,
    max: 10000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'WhatsApp',
    description: 'Active followers and members for WhatsApp Public Channels.'
  },

  // Spotify (Real Voiker IDs)
  {
    service: '432',
    id: '432',
    name: 'Spotify Free Plays [Lifetime Guaranteed] ♻️',
    type: 'Default',
    category: 'Spotify - Plays',
    rateUsd: 0.4584,
    rate: 756,
    pricePerThousandNgn: 756,
    min: 1000,
    max: 1000000000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'Spotify',
    description: 'Stream plays on your track to boost artist algorithm placement.'
  },

  // Discord (Real Voiker IDs)
  {
    service: '1040',
    id: '1040',
    name: 'Discord Offline Members | ✅Quality: Real With Avatar',
    type: 'Default',
    category: 'Discord',
    rateUsd: 2.8350,
    rate: 4678,
    pricePerThousandNgn: 4678,
    min: 50,
    max: 1500,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'Discord',
    description: 'Join members to increase Discord server headcount and credibility.'
  },

  // LinkedIn (Real Voiker IDs)
  {
    service: '4631',
    id: '4631',
    name: 'Linkedin Followers | Page or Profile | 30 Days Refill ♻️',
    type: 'Default',
    category: 'LinkedIn',
    rateUsd: 13.6500,
    rate: 22523,
    pricePerThousandNgn: 22523,
    min: 10,
    max: 100000000,
    dripfeed: false,
    refill: true,
    cancel: false,
    provider: 'Voiker',
    platform: 'LinkedIn',
    description: 'Followers on company pages or personal profiles with 30-day refill.'
  },

  // Website Traffic (Real Voiker IDs)
  {
    service: '560',
    id: '560',
    name: 'Website Traffic [WW - Direct Visits] 💧',
    type: 'Default',
    category: 'Website Traffic',
    rateUsd: 0.5354,
    rate: 883,
    pricePerThousandNgn: 883,
    min: 100,
    max: 1000000,
    dripfeed: false,
    refill: false,
    cancel: false,
    provider: 'Voiker',
    platform: 'Website',
    description: 'Direct browser visits to increase web traffic and analytics rankings.'
  }
];

const handleSocialBoost2Request = async (req: express.Request, res: express.Response, explicitAction?: string) => {
  res.setHeader('Content-Type', 'application/json');
  try {
    const action = (explicitAction || req.query.action || req.body.action || '').toString().toLowerCase() || 'services';

    if (action === 'services') {
      let rawServices = [...DEFAULT_P2_SOCIAL_SERVICES];
      // Zero-markup direct Voiker pricing: profitMarginPercent = 0, fixedMarkupPerThousand = 0
      let pricingSettings = { profitMarginPercent: 0, usdToNgnRate: 1650, fixedMarkupPerThousand: 0 };
      if (db) {
        try {
          const settingsSnap = await getDoc(doc(db, 'settings', 'social_boost_2_pricing'));
          if (settingsSnap.exists()) {
            pricingSettings = { ...pricingSettings, ...settingsSnap.data(), profitMarginPercent: 0, fixedMarkupPerThousand: 0 };
          }
        } catch (e) {
          console.warn('[SocialBoost2] Firestore settings notice:', e);
        }
      }
      const services = rawServices.map((s: any) => ({
        ...s,
        id: String(s.id || s.service),
        service: String(s.service || s.id),
        pricePerThousandNgn: Number(s.pricePerThousandNgn || s.rate || 1500),
        rate: Number(s.rate || s.pricePerThousandNgn || 1500),
      }));
      return res.json({ success: true, provider: 'Voiker', services, pricingSettings });
    }

    if (action === 'order') {
      const userId = req.body.userId || req.query.userId;
      const totalCost = Number(req.body.totalCost || req.body.amountNgn || 0);
      const serviceId = String(req.body.service || req.body.serviceId || '');
      const link = (req.body.link || req.body.target || req.body.targetUrl || '').toString().trim();
      const quantity = Number(req.body.quantity || 0);

      if (!userId || !link) {
        return res.status(400).json({ success: false, error: 'User ID and Link are required.' });
      }

      if (!serviceId || quantity <= 0) {
        return res.status(400).json({ success: false, error: 'Valid service and quantity are required.' });
      }

      if (totalCost <= 0) {
        return res.status(400).json({ success: false, error: 'Invalid total order cost.' });
      }

      if (!db) {
        return res.status(500).json({ success: false, error: 'Database unavailable.' });
      }

      const userRef = doc(db, 'users', userId);
      const userSnap = await getDoc(userRef);
      if (!userSnap.exists()) {
        return res.status(404).json({ success: false, error: 'User profile not found.' });
      }
      const userData = userSnap.data();
      const rawCurrentBal = userData.walletBalance !== undefined ? userData.walletBalance : userData.balance;
      const currentBalance = typeof rawCurrentBal === 'number' ? rawCurrentBal : (rawCurrentBal ? Number(rawCurrentBal) : 0);
      if (currentBalance < totalCost) {
        return res.status(400).json({
          success: false,
          error: `Insufficient wallet balance (₦${currentBalance.toLocaleString()}). Required: ₦${totalCost.toLocaleString()}`
        });
      }

      const { apiKey } = getXtraLogsToolsConfig();
      let upstreamOrderId: string | null = null;
      if (apiKey) {
        try {
          const upstreamRes = await queryXtraLogsTools('smm_order', {
            service: serviceId,
            link,
            quantity
          }, 'POST');

          if (upstreamRes) {
            if (upstreamRes.status === 'success' && (upstreamRes.order || upstreamRes.order_id)) {
              upstreamOrderId = String(upstreamRes.order || upstreamRes.order_id);
            } else if (upstreamRes.status === 'error') {
              const upstreamMsg = upstreamRes.message || 'Upstream provider error';
              const upstreamCode = upstreamRes.code ? ` (${upstreamRes.code})` : '';
              return res.status(400).json({
                success: false,
                error: `EstraLog Tools response: ${upstreamMsg}${upstreamCode}. Your wallet balance was not charged.`
              });
            }
          }
        } catch (err: any) {
          console.warn('[EstraLog Tools smm_order notice]:', err.message);
        }
      }

      const orderId = `SB2-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;

      await runTransaction(db, async (transaction) => {
        const uDoc = await transaction.get(userRef);
        if (!uDoc.exists()) throw new Error('User profile not found.');
        const uData = uDoc.data();
        const rawBal = uData.walletBalance !== undefined ? uData.walletBalance : uData.balance;
        const uBal = typeof rawBal === 'number' ? rawBal : (rawBal ? Number(rawBal) : 0);
        if (uBal < totalCost) {
          throw new Error(`Insufficient wallet balance (₦${uBal.toLocaleString()}). Required: ₦${totalCost.toLocaleString()}`);
        }
        const newBal = uBal - totalCost;
        transaction.update(userRef, {
          walletBalance: newBal,
          balance: newBal,
          updatedAt: new Date().toISOString()
        });
        transaction.set(doc(db, 'wallets', userId), {
          userId,
          walletBalance: newBal,
          balance: newBal,
          updatedAt: new Date().toISOString()
        }, { merge: true });

        const orderDocRef = doc(db, 'orders_social_boost_2', orderId);
        const orderData2 = {
          orderId,
          providerOrderId: upstreamOrderId,
          userId,
          userEmail: req.body.userEmail || userData.email || '',
          provider: 'EstraLog Tools',
          service: serviceId,
          serviceName: req.body.serviceName || `Service #${serviceId}`,
          category: req.body.category || 'Growth',
          platform: req.body.platform || 'Other',
          link,
          quantity,
          charge: totalCost,
          status: 'Processing',
          type: 'social_boost',
          transactionCategory: 'social_boost',
          startCount: 0,
          remains: quantity,
          createdAt: new Date().toISOString()
        };
        transaction.set(orderDocRef, orderData2);

        // Record in purchases and wallet_transactions
        const pRef = doc(db, 'purchases', orderId);
        transaction.set(pRef, {
          id: orderId,
          listingId: orderId,
          listingTitle: `Social Boost: ${req.body.serviceName || `Service #${serviceId}`} (${quantity.toLocaleString()} units)`,
          category: 'social_boost',
          type: 'social_boost',
          transactionCategory: 'social_boost',
          price: totalCost,
          paidAmount: totalCost,
          currency: 'NGN',
          buyerId: userId,
          buyerEmail: req.body.userEmail || userData.email || '',
          sellerId: 'estralog-service',
          sellerName: 'ZENET Social Boost (Server 2)',
          status: 'in_progress',
          target: link,
          quantity,
          purchasedAt: orderData2.createdAt,
          createdAt: orderData2.createdAt
        });

        const txDocRef = doc(db, 'wallet_transactions', orderId);
        transaction.set(txDocRef, {
          id: orderId,
          userId,
          userEmail: req.body.userEmail || userData.email || '',
          amount: totalCost,
          type: 'purchase',
          category: 'social_boost',
          transactionCategory: 'social_boost',
          method: 'wallet',
          status: 'successful',
          description: `Social Boost (Server 2): ${req.body.serviceName || `Service #${serviceId}`} (${quantity.toLocaleString()} units)`,
          date: new Date().toISOString(),
          createdAt: new Date().toISOString()
        });
      });

      const placedDoc = await getDoc(doc(db, 'orders_social_boost_2', orderId));
      return res.json({
        success: true,
        provider: 'EstraLog Tools',
        message: 'Social Boost order submitted successfully.',
        orderId,
        providerOrderId: upstreamOrderId,
        order: placedDoc.exists() ? placedDoc.data() : { orderId }
      });
    }

    if (action === 'status') {
      const orderId = (req.query.orderId || req.body.orderId || '').toString();
      if (!orderId || !db) {
        return res.status(400).json({ success: false, error: 'Order ID required.' });
      }
      const orderRef = doc(db, 'orders_social_boost_2', orderId);
      const snap = await getDoc(orderRef);
      if (!snap.exists()) {
        return res.status(404).json({ success: false, error: 'Order not found.' });
      }
      const orderData = snap.data();
      const { apiKey } = getXtraLogsToolsConfig();
      if (orderData.providerOrderId && apiKey) {
        try {
          const upstreamStatus = await queryXtraLogsTools('smm_status', { order: orderData.providerOrderId });
          if (upstreamStatus && upstreamStatus.status === 'success' && upstreamStatus.state) {
            await updateDoc(orderRef, {
              status: upstreamStatus.state,
              remains: upstreamStatus.remains !== undefined ? upstreamStatus.remains : orderData.remains,
              updatedAt: new Date().toISOString()
            });
            orderData.status = upstreamStatus.state;
          }
        } catch (err: any) {
          console.warn('[EstraLog smm_status check notice]:', err.message);
        }
      }
      return res.json({ success: true, provider: 'EstraLog Tools', status: orderData.status, order: orderData });
    }

    if (action === 'orders') {
      const userId = (req.query.userId || req.body.userId || '').toString();
      const isAll = req.query.all === 'true';
      if (!db) {
        return res.json({ success: true, orders: [] });
      }
      const q = isAll ? query(collection(db, 'orders_social_boost_2')) : query(collection(db, 'orders_social_boost_2'), where('userId', '==', userId));
      const snaps = await getDocs(q);
      const list: any[] = [];
      snaps.forEach(d => list.push(d.data()));
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      return res.json({ success: true, provider: 'Provider 2', orders: list });
    }

    if (action === 'pricing-settings') {
      if (req.method === 'POST') {
        if (!db) return res.status(500).json({ success: false, error: 'DB unavailable' });
        await setDoc(doc(db, 'settings', 'social_boost_2_pricing'), {
          profitMarginPercent: Number(req.body.profitMarginPercent || 35),
          usdToNgnRate: Number(req.body.usdToNgnRate || 1550),
          fixedMarkupPerThousand: Number(req.body.fixedMarkupPerThousand || 200),
          updatedAt: new Date().toISOString()
        }, { merge: true });
        return res.json({ success: true, message: 'Provider 2 pricing updated.' });
      } else {
        let pricingSettings = { profitMarginPercent: 35, usdToNgnRate: 1550, fixedMarkupPerThousand: 200 };
        if (db) {
          const snap = await getDoc(doc(db, 'settings', 'social_boost_2_pricing'));
          if (snap.exists()) pricingSettings = { ...pricingSettings, ...snap.data() };
        }
        return res.json({ success: true, settings: pricingSettings });
      }
    }

    return res.json({ success: true, provider: 'Provider 2', message: 'Social Boost 2 Ready' });
  } catch (err: any) {
    console.error('[Provider 2 Social Boost error]:', err);
    return res.status(500).json({ success: false, error: err.message || 'Internal Provider 2 error' });
  }
};

app.all('/api/social-boost-2', (req, res) => handleSocialBoost2Request(req, res));
app.all('/api/social-boost-2/:action', (req, res) => handleSocialBoost2Request(req, res, req.params.action));

// Health check
app.get('/api/health', (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.json({ status: 'ok', service: 'ZENET Marketplace Payment Server' });
});

// Explicit 404 JSON response for any unhandled /api routes (prevents returning HTML to API callers)
app.all('/api/*', (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.status(404).json({
    success: false,
    error: `API endpoint ${req.method} ${req.path} not found.`
  });
});

// Global Safe Error Handler: Masks all internal exceptions and prevents stack trace leakage
app.use((err: any, req: any, res: any, _next: any) => {
  console.error(`[Server Error] Path: ${req?.path} Method: ${req?.method} Message:`, err?.message || err);
  if (res.headersSent) {
    return;
  }
  res.status(err?.status || 500).json({
    success: false,
    error: 'An unexpected server error occurred. Please try again later.'
  });
});

// 2. Vite Middleware & Production Static Serving integration
async function startServer() {
  const distPath = path.join(process.cwd(), 'dist');
  const distAssetsPath = path.join(distPath, 'assets');
  const distIndexExists = fs.existsSync(path.join(distPath, 'index.html'));

  if (process.env.NODE_ENV === 'production' && distIndexExists) {
    app.use(express.static(distPath, {
      maxAge: '1d',
      setHeaders: (res, filePath) => {
        if (filePath.endsWith('.js') || filePath.endsWith('.mjs')) {
          res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
        } else if (filePath.endsWith('.css')) {
          res.setHeader('Content-Type', 'text/css; charset=utf-8');
        }
      }
    }));
    // Return 404 text/plain for missing asset chunks so browsers don't receive index.html as a JS module
    app.get(['/assets/*', '/*.js', '/*.mjs', '/*.css'], (req, res) => {
      res.status(404).type('text/plain').send('Asset not found');
    });
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    // In dev mode, if dist/assets exists from compilation, serve them so cached asset requests succeed
    if (fs.existsSync(distAssetsPath)) {
      app.use('/assets', express.static(distAssetsPath, {
        setHeaders: (res, filePath) => {
          if (filePath.endsWith('.js') || filePath.endsWith('.mjs')) {
            res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
          } else if (filePath.endsWith('.css')) {
            res.setHeader('Content-Type', 'text/css; charset=utf-8');
          }
        }
      }));
    }

    // Explicitly return 404 text/plain for missing /assets/* or *.js files so Vite SPA fallback NEVER returns text/html for JS modules!
    app.get(['/assets/*', '/*.js', '/*.mjs'], (req, res, next) => {
      if (req.path.startsWith('/src') || req.path.startsWith('/@') || req.path.startsWith('/node_modules')) {
        return next();
      }
      res.status(404).type('text/plain').send('Asset not found');
    });

    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ZENET Server running on http://0.0.0.0:${PORT}`);
  });
}

if (!process.env.NETLIFY && !process.env.AWS_LAMBDA_FUNCTION_NAME && !process.env.LAMBDA_TASK_ROOT) {
  startServer();
}

export { app };
export default app;
